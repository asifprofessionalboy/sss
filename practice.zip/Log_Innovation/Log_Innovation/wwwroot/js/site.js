﻿
const $button = document.querySelector('#sidebar-toggle');
const $wrapper = document.querySelector('#wrapper');

$button.addEventListener('click', (e) => {
    e.preventDefault();
    $wrapper.classList.toggle('toggled');
});
//sidebar js

document.addEventListener('DOMContentLoaded', (event) => {
    const submenuLinks = document.querySelectorAll('.submenu a');

    
    document.querySelectorAll('.master-tab > a').forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            const submenu = link.nextElementSibling;
            if (submenu) {
                submenu.style.display = submenu.style.display === 'block' ? 'none' : 'block';
            }
        });
    });

    document.querySelectorAll('.submenu').forEach(submenu => {
        submenu.style.display = 'none'; 
        submenu.addEventListener('click', (event) => {
            event.stopPropagation();
        });
    });

   
    submenuLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            event.stopPropagation();
        });
    });
});



var formStatus = '';

function setSubmitFlag(status) {
    formStatus = status;
    document.getElementById('SubmitFlag').value = status;
}

document.getElementById('form').addEventListener('submit', function (event) {
    event.preventDefault(); 

    if (formStatus === 'Save as Draft') {
        
        Swal.fire({
            title: "Data Saved in Draft",
            width: 600,
            padding: "3em",
            color: "#28a745",
            background: "#fff",
            backdrop: `
                rgba(0,0,123,0.4)
            `,
            timer: 5000
        }).then(() => {
            // Submit the form after the SweetAlert is shown
            this.submit();
        });
        return;
    }

    var isValid = true;
    var elements = this.querySelectorAll('input, select, textarea,radio');
    var othersDiv = document.getElementById('Others');
    var otherBenefitsElement = document.getElementById('otherbenefits');

    elements.forEach(function (element) {
       
        if (element.id === 'ApprovalFile' || element.id === 'dropdown-template' || element.id === 'status' || element.id === 'remarks' || element.id === 'StatusField' || element.id === 'Parameterid' || element.id === 'Paracode' || element.id === 'created' || element.id === 'ScoreId' || element.id === 'scorecode' || element.id === 'actionType' || element.id ==='daretotry') {
            return;
        }

       
        var downloadLink = document.querySelector("a[href*='DownloadFile']");
        var attachInput = document.getElementById('fileInput');

        if (downloadLink && downloadLink.offsetParent !== null) {
           
            if (element.id === 'fileInput') {
                return;
            }
        } else if (attachInput && attachInput.offsetParent !== null) {
          
            if (element.tagName.toLowerCase() === 'a' && element.href.includes('DownloadFile')) {
                return;
            }
        }

   
        if (element.id === 'otherbenefits' && othersDiv.style.display === 'none') {
           
            return;
        }

        if (element.value.trim() === '') {
            isValid = false;
            element.classList.add('is-invalid');
            var errorSpan = element.nextElementSibling;
            if (errorSpan && errorSpan.tagName.toLowerCase() === 'span') {
               
            }
        } else {
            element.classList.remove('is-invalid');
            var errorSpan = element.nextElementSibling;
            if (errorSpan && errorSpan.tagName.toLowerCase() === 'span') {
                errorSpan.textContent = '';
            }
        }
    });


    if (isValid) {
        Swal.fire({
            title: "Data Saved Successfully",
            width: 600,
            padding: "3em",
            color: "#28a745",
            background: "#fff",
            backdrop: `
                rgba(0,0,123,0.4)
            `,
            timer: 5000
        }).then(() => {
           
            this.submit();
        });
    }
});


//file Name Js
document.getElementById('fileInput').addEventListener('change', function (event) {
    var fileInput = event.target;
    var fileNamesContainer = document.getElementById('fileNames');
    fileNamesContainer.innerHTML = ''; 

    var files = fileInput.files;
    var ul = document.createElement('ul'); 

    for (var i = 0; i < files.length; i++) {
        var li = document.createElement('li'); 
        li.textContent = files[i].name;
        ul.appendChild(li);
    }

    fileNamesContainer.appendChild(ul); 
});




    $(document).ready(function () {
        $('[data-toggle="tooltip"]').tooltip({
            placement: 'bottom'
        });
    });
