using Microsoft.EntityFrameworkCore;
 using Log_Innovation.Models;
using Log_Innovation.MailService;
using System.Security.Cryptography.Xml;
using Log_Innovation.PasswordEncryption;
using Microsoft.AspNetCore.Http.Features;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
var Provider = builder.Services.BuildServiceProvider();
var Config = Provider.GetRequiredService<IConfiguration>();
builder.Services.AddDbContext<INNOVATIONDBContext>(item => item.UseSqlServer(Config.GetConnectionString("DBCS")));
builder.Services.AddDbContext<UserLoginDBContext>(item => item.UseSqlServer(Config.GetConnectionString("UserDB")));
builder.Services.AddTransient<EmailService>();
builder.Services.AddTransient<ApprovalEmailService>();
builder.Services.Configure<EncryptionSettings>(builder.Configuration.GetSection("EncryptionSettings"));
builder.Services.AddSingleton<EncryptionMethods>();
builder.Services.AddTransient<PasswordHasher>();
builder.Services.AddHttpContextAccessor();
builder.Services.AddSession();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}


app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseSession();
app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=User}/{action=Homepage}/{id?}");

var UploadPath = builder.Configuration["FileUpload:Path"];
if (!Directory.Exists(UploadPath))
{
    Directory.CreateDirectory(UploadPath);
}

app.Run();
