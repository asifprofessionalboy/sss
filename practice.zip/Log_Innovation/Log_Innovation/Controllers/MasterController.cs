﻿using Log_Innovation.MailService;
using Log_Innovation.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using System.Reflection.Emit;
using System.Web;
using System.Xml.Linq;

namespace Log_Innovation.Controllers
{
	public class MasterController : Controller
	{

		private readonly INNOVATIONDBContext context;


		public MasterController(INNOVATIONDBContext context)
		{
			this.context = context;

		}
		public async Task<IActionResult> ParameterMaster(Guid? id, AppParameter parameter, int page = 1, string searchString = "", string pcode = "")
		{
			if (HttpContext.Session.GetString("Session") != null)
			{
				
				var user =  HttpContext.Session.GetString("Session");

				ViewBag.Data = user;


               

                int pageSize = 5;
                var query = context.AppParameters.AsQueryable();


                if (!string.IsNullOrEmpty(pcode))
                {
                    query = query.Where(p => p.ParameterCode.Contains(pcode));
                }

                var data = query.ToList(); 



               
                var sortedData = data.OrderBy(p =>
                    int.Parse(p.ParameterCode.Substring(6)) 
                ).ToList();

              
                var pagedData = sortedData.Skip((page - 1) * pageSize).Take(pageSize).ToList();
                var totalCount = sortedData.Count();

                ViewBag.SearchPcode = pcode;

                ViewBag.pList = pagedData;
                ViewBag.CurrentPage = page;
                ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
                ViewBag.SearchString = searchString;

                if (id.HasValue)
				{
					var model = await context.AppParameters.FindAsync(id.Value);
					if (model == null)
					{
						return NotFound();
					}

					return Json(new
					{
						id=model.Id,
						parameter = model.ParameterCode,
						weightage = model.Weightage,
						parameterDesc = model.ParameterDesc,
						CreatedBy = user,
						createdon =model.CreatedOn
					});
				}

				return View(new AppParameter());
			}
			else
			{
				return RedirectToAction("Login", "User");
			}
		}


        //Add & update

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ParameterMaster(AppParameter parameter, string actionType)
        {
            if (string.IsNullOrEmpty(actionType))
            {
                return BadRequest("No action specified.");
            }

            var existingParameter = await context.AppParameters.FindAsync(parameter.Id);

            if (actionType == "Submit")
            {
                if (ModelState.IsValid)
                {
                   
                    var totalWeightage = context.AppParameters
                        .Where(x => x.Id != parameter.Id)
                        .Sum(x => x.Weightage);

                    
                    if (totalWeightage + parameter.Weightage > 100)
                    {
                        TempData["Psum"] = "The sum of all Weightage must be less than or equal to 100.";
                        return RedirectToAction("ParameterMaster");
                    }

                    if (existingParameter != null)
                    {
                    
                        context.Entry(existingParameter).CurrentValues.SetValues(parameter);
                        await context.SaveChangesAsync();
                        TempData["Updatedmsg"] = "Parameter Updated Successfully!";
                        return RedirectToAction("ParameterMaster");
                    }
                    else
                    {
                      
                        parameter.CreatedOn = DateTime.Now;
                        await context.AppParameters.AddAsync(parameter);
                        await context.SaveChangesAsync();
                        TempData["msg"] = "Parameter Added Successfully! Kindly Add Evaluation Matrix Description for Successful Implementation.";
                        return RedirectToAction("MatrixMaster");
                    }
                }
            }
            else if (actionType == "Delete")
            {
                if (existingParameter != null)
                {
                    context.AppParameters.Remove(existingParameter);
                    await context.SaveChangesAsync();
                    TempData["Dltmsg"] = "Parameter Deleted Successfully!";
                }
            }

            return RedirectToAction("ParameterMaster");
        }


        //------------------------------------------------



        public async Task<IActionResult> MatrixMaster(Guid? id, AppMatrixMaster matrix, int page = 1, string searchString = "", string pcode = "")
        {
            if (HttpContext.Session.GetString("Session") != null)
            {
                var user = HttpContext.Session.GetString("Session");
                ViewBag.Data = user;

                int pageSize = 5;
                var query = context.AppMatrixMasters.AsQueryable();

              
                string searchValue = HttpContext.Request.Query["searchValue"];
                string searchType = HttpContext.Request.Query["searchType"];

               
                if (!string.IsNullOrEmpty(searchValue) && !string.IsNullOrEmpty(searchType))
                {
                    if (searchType == "ParameterCode")
                    {
                        query = query.Where(p => p.ParameterCode.Contains(searchValue));
                    }
                    else if (searchType == "ParameterDesc")
                    {
                        query = query.Where(p => p.MatrixDesc.Contains(searchValue));
                    }
                }

                var data = query.ToList();
                var sortedData = data.OrderBy(p =>
                    int.Parse(p.ParameterCode.Substring(6))
                ).ToList();

                var pagedData = sortedData.Skip((page - 1) * pageSize).Take(pageSize).ToList();
                var totalCount = sortedData.Count();

               
                ViewBag.SearchValue = searchValue;
                ViewBag.SearchType = searchType;

                ViewBag.pList = pagedData;
                ViewBag.CurrentPage = page;
                ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);

               
                var parameterList = context.AppParameters
                    .Select(x => new SelectListItem
                    {
                        Value = x.ParameterCode,
                        Text = x.ParameterDesc
                    }).ToList();

                ViewBag.ParameterDDList = parameterList;

                if (id.HasValue)
                {
                    var model = await context.AppMatrixMasters.FindAsync(id.Value);
                    if (model == null)
                    {
                        return NotFound();
                    }

                    return Json(new
                    {
                        id = model.Id,
                        parameter = model.ParameterCode,
                        score = model.ScoreCode,
                        matrixDesc = model.MatrixDesc,
                        CreatedBy = user,
                        createdon = model.CreatedOn
                    });
                }

                return View(new AppMatrixMaster());
            }
            else
            {
                return RedirectToAction("Login", "User");
            }


        }


        //Add & update

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MatrixMaster(AppMatrixMaster matrix, string actionType)
        {
            if (string.IsNullOrEmpty(actionType))
            {
                return BadRequest("No action specified.");
            }

        

            var existingMatrix = await context.AppMatrixMasters.FindAsync(matrix.Id);

            if (actionType == "Submit")
            {
             
                if (ModelState.IsValid)
                {


                    if (existingMatrix != null)
                    {
                        var Data = await context.AppMatrixMasters.Where(x => x.ParameterCode == matrix.ParameterCode && x.ScoreCode == matrix.ScoreCode).FirstOrDefaultAsync();

                        if (Data != null)
                        {
                            existingMatrix.MatrixDesc = matrix.MatrixDesc;
                            await context.SaveChangesAsync();
                            TempData["Errormsg"] = "Score Code ALready Exist";
                            return RedirectToAction("MatrixMaster");
                        }
                        else
                        {
                            
                            context.Entry(existingMatrix).CurrentValues.SetValues(matrix);
                            await context.SaveChangesAsync();
                            TempData["Updatedmsg"] = "Parameter Updated Successfully! ";
                            return RedirectToAction("MatrixMaster");
                        }

                       
                    }
                    else
                    {

                        var Data = await context.AppMatrixMasters.Where(x => x.ParameterCode == matrix.ParameterCode && x.ScoreCode == matrix.ScoreCode).FirstOrDefaultAsync();

                        if (Data != null)
                        {

                            TempData["Errormsg"] = "Score Code ALready Exist";
                            return RedirectToAction("MatrixMaster");
                        }

                        else
                        {
                           
                            matrix.CreatedOn = DateTime.Now;
                            await context.AppMatrixMasters.AddAsync(matrix);
                            await context.SaveChangesAsync();
                            TempData["Addedmsg"] = "Parameter Added Successfully!";
                            return RedirectToAction("MatrixMaster");
                        }
                        
                    }

                }
            }
          
            
            
            
            else if (actionType == "Delete")
            {
                

                if (existingMatrix != null)
                {
                    context.AppMatrixMasters.Remove(existingMatrix);
                    await context.SaveChangesAsync();
                   
                    TempData["Dltmsg"] = "Parameter Deleted Successfully! ";
                 
                }
            }

            return RedirectToAction("MatrixMaster");
        }





        //--------------------------------------------------------
        public async Task<IActionResult> ScoreMaster(Guid? id, int page = 1, string searchString = "")
		{

			if (HttpContext.Session.GetString("Session") != null)
			{
				ViewBag.ScoreList = await context.AppScores.ToListAsync();

				var user = HttpContext.Session.GetString("Session");

				ViewBag.Data = user;



				int pageSize = 5;
				var query = context.AppScores.AsQueryable();
				var pagedData = query.Skip((page - 1) * pageSize).Take(pageSize).ToList();
				var totalCount = query.Count();

				ViewBag.ScoreList = pagedData;
				ViewBag.CurrentPage = page;
				ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
				ViewBag.SearchString = searchString;


				if (id.HasValue)
				{
					var model = await context.AppScores.FindAsync(id.Value);
					if (model == null)
					{
						return NotFound();
					}

					return Json(new
					{
						id = model.Id,
						Scode = model.ScoreCode,
						desc = model.ScoreDesc,
						CreatedBy = user,
					
					});
				}

				return View(new AppScore());
			}
			return RedirectToActionPermanent("Login", "User");
			
			
		}


		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ScoreMaster(AppScore score, Guid Id)
		{


			if (ModelState.IsValid)
			{

				var existingScore = await context.AppScores.FindAsync(score.Id);

				if (existingScore != null)
				{

					context.Entry(existingScore).CurrentValues.SetValues(score);
				}
				else
				{
					//score.CreatedOn = DateTime.Now;
					await context.AppScores.AddAsync(score);
				}

				await context.SaveChangesAsync();

			}

			return RedirectToAction("ScoreMaster");
		}




		[HttpPost]
		public async Task<IActionResult> ScoreMasterDelete(Guid id)
		{
			if (HttpContext.Session.GetString("Session") != null)
			{
				var score = await context.AppScores.FindAsync(id);
				if (score == null)
				{
					return NotFound();
				}

				context.AppScores.Remove(score);
				await context.SaveChangesAsync();

				return RedirectToAction("ScoreMaster");
			}
			else
			{
				return RedirectToAction("Login", "User");
			}
		}

	}

}
