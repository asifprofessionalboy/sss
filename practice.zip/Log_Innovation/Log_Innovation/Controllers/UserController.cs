﻿using System.Net.Mail;
using System.Security.Cryptography.Xml;
using Log_Innovation.Models;
using Log_Innovation.PasswordEncryption;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Win32;

namespace Log_Innovation.Controllers
{
	public class UserController : Controller
	{
		private readonly INNOVATIONDBContext context;
		private readonly UserLoginDBContext context1;
		private readonly EmailService emailService;
        private readonly EncryptionMethods encryption;
        private readonly PasswordHasher _passwordHasher;

        public UserController(INNOVATIONDBContext context, UserLoginDBContext context1, EmailService emailService,EncryptionMethods encryption,PasswordHasher passwordHasher)
		{
			this.context = context;
			this.context1 = context1;
			this.emailService = emailService;
            this.encryption = encryption;
            _passwordHasher = passwordHasher;
        }

		public IActionResult Homepage()
		{

			return View();
		}
		public IActionResult Signup()
		{
			return View();
		}
        [HttpPost]
        public async Task<IActionResult> Signup(AppLogin appLogin)
        {
            var existingUser = await context.AppLogins
                .Where(x => x.UserId == appLogin.UserId)
                .FirstOrDefaultAsync();

            if (existingUser != null)
            {
                ViewBag.DupData = "UserId is already Exist";
                return View(appLogin);
            }
            else
            {
                var passwordHasher = new PasswordHasher();
                var (hashedPassword, salt) = _passwordHasher.HashPassword(appLogin.Password);

                appLogin.Password = hashedPassword;
                appLogin.PasswordSalt = salt;

                await context.AppLogins.AddAsync(appLogin);
                await context.SaveChangesAsync();

                ViewBag.Data = "Signup Successful";
                return RedirectToAction("Login");
            }
        }




        public IActionResult Login()
		{
			return View();
		}

        [HttpPost]
        public async Task<IActionResult> Login(AppLogin login, string returnUrl = null)
        {
            
            if (!string.IsNullOrEmpty(login.UserId) && string.IsNullOrEmpty(login.Password))
            {
                ViewBag.FailedMsg = "Login Failed: Password is required";
                return View(login);
            }

           
            var user = await context.AppLogins
                .Where(x => x.UserId == login.UserId)
                .FirstOrDefaultAsync();

            if (user != null)
            {
             
                bool isPasswordValid = _passwordHasher.VerifyPassword(login.Password, user.Password, user.PasswordSalt);

                if (isPasswordValid)
                {
                  
                    HttpContext.Session.SetString("Session", login.UserId);

                   
                    if (!string.IsNullOrEmpty(returnUrl))
                    {
                        return Redirect(returnUrl);
                    }
                    else
                    {
                        return RedirectToAction("Homepage", "Innovation");
                    }
                }
                else
                {
                    ViewBag.FailedMsg = "Login Failed: Incorrect password";
                }
            }
            else
            {
                ViewBag.FailedMsg = "Login Failed: User not found";
            }

            return View(login);
        }




        public IActionResult ForgetPassword()
		{
			return View();
		}
        [HttpPost]
        public async Task<IActionResult> ForgetPassword(AppLogin appLogin)
        {
            try
            {
                var user = await context.AppLogins
                    .FirstOrDefaultAsync(x => x.UserId == appLogin.UserId);

                if (user != null)
                {
                    string GenerateRandomString(int length)
                    {
                        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                        Random random = new Random();
                        return new string(Enumerable.Repeat(chars, length)
                            .Select(s => s[random.Next(s.Length)]).ToArray());
                    }

                    var randomPassword = "XiADz" + GenerateRandomString(3) + "Ks" + GenerateRandomString(2) + "d";

                    
                    var (hashedPassword, salt) = _passwordHasher.HashPassword(randomPassword);

                    user.Password = hashedPassword;
                    user.PasswordSalt = salt;

                    await context.SaveChangesAsync();

                    var emailId = user.Email;

                    var userData = await context1.AppEmployeeMasters
                        .Where(x => x.Pno == appLogin.UserId)
                        .Select(x => new
                        {
                            Name = x.Ename,
                            Dept = x.DepartmentName,
                        })
                        .FirstOrDefaultAsync();

                    if (userData != null)
                    {
                        string subject = $"{userData.Name} ({userData.Dept}): Your password has been changed";
                        string msg = $"<br/>Your password of Innovation portal has been changed to {randomPassword}<br/>" +
                                     "<br/>Kindly change the password after login.<br/>" +
                                     "Regards,<br/>" +
                                     "Tata Steel UISL<br/>";

                        await emailService.SendEmailAsync(emailId, "", "", subject, msg);

                        ViewBag.Msg = "Mail sent to: " + emailId;
                    }
                    else
                    {
                        Console.WriteLine("Email is null");
                    }
                }
            }
            catch (SmtpException smtpEx)
            {
                smtpEx.Message.ToString();
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

            return View(appLogin);
        }




        public IActionResult ChangePassword()
		{
			return View();
		}
        [HttpPost]
        public async Task<IActionResult> ChangePassword(AppLogin appLogin)
        {
            var pno = HttpContext.Session.GetString("Session");

            var user = await context.AppLogins
                .FirstOrDefaultAsync(x => x.UserId == pno);

            if (user != null)
            {
               
                bool isPasswordValid = _passwordHasher.VerifyPassword(appLogin.Password, user.Password, user.PasswordSalt);

                if (isPasswordValid)
                {
                    var (newHashedPassword, newSalt) = _passwordHasher.HashPassword(appLogin.NewPassword);

                    user.Password = newHashedPassword;
                    user.PasswordSalt = newSalt;

                    await context.SaveChangesAsync();

                    ViewBag.ChangePass = "Password Changed Successfully";
                }
                else
                {
                    ViewBag.FailedMsg = "Old Password Does Not Match!";
                }
            }
            else
            {
                ViewBag.FailedMsg = "Old Password Does Not Match!";
            }

            return View();
        }

    }
}
