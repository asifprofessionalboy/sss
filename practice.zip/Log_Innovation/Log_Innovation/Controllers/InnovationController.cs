﻿using System.Reflection.Emit;
using System.Web;
using System.Xml.Linq;
using Log_Innovation.MailService;
using Log_Innovation.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using Org.BouncyCastle.Crypto.Macs;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace Log_Innovation.Controllers
{
	public class InnovationController : Controller
	{
		private readonly INNOVATIONDBContext context;
		private readonly UserLoginDBContext context1;
		private readonly IConfiguration configuration;
		private readonly EmailService emailService;
		private readonly ApprovalEmailService approvalEmail;

		public InnovationController(INNOVATIONDBContext context, UserLoginDBContext context1, IConfiguration configuration, EmailService emailService, ApprovalEmailService approvalEmail)
		{
			this.context = context;
			this.context1 = context1;
			this.configuration = configuration;
			this.emailService = emailService;
			this.approvalEmail = approvalEmail;
		}

        public IActionResult Homepage()
        {
            if (HttpContext.Session.GetString("Session") != null)
            {
               
                var totalInnovations = context.AppInnovations.Where(x=>x.Status!="Draft").Count();

                
                var totalApprovedInnovations = context.AppInnovations
                    .Count(innovation => innovation.Status == "Approved");

               
                ViewBag.TotalInnovations = totalInnovations;
                ViewBag.TotalApprovedInnovations = totalApprovedInnovations;
            }
            else
            {
                return RedirectToAction("Login", "User");
            }

            return View();
        }

        public IActionResult Logout()
        {
			HttpContext.Session.Remove("Session");
			return RedirectToAction("Homepage", "User");

		}
        public IActionResult AccessDenied()
        {
			return View();

        }

        public IActionResult Innovation_Request()
		{
			if (HttpContext.Session.GetString("Session") != null)
			{
				var viewModel = new InnovationViewModel
				{
					appInnovationBenefits = new List<AppInnovationBenefit>(),
					appProjectTeams = new List<AppProjectTeam>(),
					Attach = new List<IFormFile>(),

				};

				var Data = context1.AppEmployeeMasters.ToList();
				ViewBag.data = Data;

				var Benefit = context.AppBenefitMasters.Select(x => x.Benefit).ToList();
				var Benefitdd = Benefit.Select(name => new SelectListItem
				{
					Value = name,
					Text = name
				}).ToList();
				ViewBag.DDList = Benefitdd;

				var InnovationStage = context.AppStageOfInnovationMasters.Select(x => new
				{
					StageOfInnovation = x.StageOfInnovation,
					SlNo = x.SlNo,
				}).ToList().OrderBy(x => x.SlNo);

				var InnovationStagedd = InnovationStage.Select(name => new SelectListItem
				{
					Value = name.StageOfInnovation,
					Text = name.StageOfInnovation
				}).ToList();
				ViewBag.InnovationDDList = InnovationStagedd;


				var pnoDetails = context1.AppEmployeeMasters
							 .Select(x => new
							 {
								 Pno = x.Pno,
								 Ename = x.Ename,
								 DepartmentName = x.DepartmentName,
								 EmailId = x.EmailId,
								 Phone = x.Phone,
								 Designation = x.Designation
							 }).ToList();

				ViewBag.PnoList = pnoDetails;

				var PnoEnameList = context1.AppEmployeeMasters
							 .Select(x => new
							 {
								 Pno = x.Pno,
								 Ename = x.Ename,
								 Contact = x.Phone
							 })
							 .ToList();

				ViewBag.PnoEnameList = PnoEnameList;

				var userId = HttpContext.Session.GetString("Session");

				var user = context1.AppEmployeeMasters.FirstOrDefault(x => x.Pno == userId);
				
					ViewBag.pno = user.Pno;
					ViewBag.Dept = user.DepartmentName;
					ViewBag.Ename = user.Ename;
					ViewBag.Contact = user.Phone;
					ViewBag.Email = user.EmailId;
					ViewBag.Desg = user.Designation;
					
				

				return View(viewModel);
			}
			else
			{
				return RedirectToAction("Login", "User");
			}
			

		}
        
        [HttpPost]
		[RequestSizeLimit(500 * 1024 * 1024)]
		[ValidateAntiForgeryToken]
        public async Task<IActionResult> Innovation_Request(InnovationViewModel InnViewModel, string action)
        {
            try
            {
                if (ModelState.IsValid)
                {
                 
                    if (InnViewModel.Attach != null && InnViewModel.Attach.Any())
                    {
                        var uploadPath = configuration["FileUpload:Path"];
                        foreach (var file in InnViewModel.Attach)
                        {
                            if (file.Length > 0)
                            {
                                var uniqueId = Guid.NewGuid().ToString();
                                var currentDateTime = DateTime.UtcNow.ToString("dd-MM-yyyy_HH-mm-ss");
                                var originalFileName = Path.GetFileNameWithoutExtension(file.FileName);
                                var fileExtension = Path.GetExtension(file.FileName);
                                var formattedFileName = $"{uniqueId}_{currentDateTime}_{originalFileName}{fileExtension}";
                                var fullPath = Path.Combine(uploadPath, formattedFileName);

                                using (var stream = new FileStream(fullPath, FileMode.Create))
                                {
                                    await file.CopyToAsync(stream);
                                }

                                InnViewModel.Attachment += $"{formattedFileName},";
                            }
                        }

                        if (!string.IsNullOrEmpty(InnViewModel.Attachment))
                        {
                            InnViewModel.Attachment = InnViewModel.Attachment.TrimEnd(',');
                        }
                    }

                    
                    if (!string.IsNullOrEmpty(InnViewModel.OtherBenefit))
                    {
                        var newBenefit = new AppBenefitMaster
                        {
                            Id = Guid.NewGuid(),
                            Benefit = InnViewModel.OtherBenefit
                        };
                        context.AppBenefitMasters.Add(newBenefit);
                    }

                   
                    var userId = HttpContext.Session.GetString("Session");
                   

                    var Innovation = new AppInnovation
                    {
                        Id = Guid.NewGuid(),
                        CreatedBy = userId,
                        PersonalNo = InnViewModel.PersonalNo,
                        Name = InnViewModel.Name,
                        Department = InnViewModel.Department,
                        Designation = InnViewModel.Designation,
                        EmailId = InnViewModel.EmailId,
                        Mobile = InnViewModel.Mobile,
                        Innovation = InnViewModel.Innovation,
                        Description = InnViewModel.Description,
                        StageOfInnovation = InnViewModel.StageOfInnovation,
                        Attachment = InnViewModel.Attachment,
                        Status = InnViewModel.Status,
                        RefNo = InnViewModel.RefNo,
                        SubmitFlag = InnViewModel.SubmitFlag,
                        SourceOfInnovation = InnViewModel.SourceOfInnovation,
                        OtherBenefit = InnViewModel.OtherBenefit,
                        CreatedOn = DateTime.Now,
						DareToTry  = InnViewModel.DareToTry
                    };

                    if (Innovation.SubmitFlag == "Submit")
                    {
                        Innovation.Status = "Pending for Approval";
                    }
                    else if (Innovation.SubmitFlag == "Save as Draft")
                    {
                        Innovation.Status = "Draft";
                        Innovation.SubmitFlag = "Submit";
                    }

                    context.AppInnovations.Add(Innovation);
                    await context.SaveChangesAsync();

                
                    foreach (var benefit in InnViewModel.appInnovationBenefits)
                    {
                        benefit.Id = Guid.NewGuid();
                        benefit.MasterId = Innovation.Id;
                        await context.AppInnovationBenefits.AddAsync(benefit);
                    }
                    await context.SaveChangesAsync();

                    foreach (var team in InnViewModel.appProjectTeams)
                    {
                        team.Id = Guid.NewGuid();
                        team.MasterId = Innovation.Id;
                        await context.AppProjectTeams.AddAsync(team);
                    }
                    await context.SaveChangesAsync();

               
                    var refNo = context.AppInnovations
                        .Where(x => x.Id == Innovation.Id)
                        .Select(x => new
                        {
                            Name = x.Name,
                            Dept = x.Department,
                            RefNo = x.RefNo,
                            Innovation = x.Innovation,
                            Status = x.Status,
                        }).FirstOrDefault();

                    var EmailId = await context.AppLogins.FirstOrDefaultAsync(x => x.UserId == InnViewModel.PersonalNo);

                    if (EmailId != null)
                    {
                        var requesterEmail = EmailId.Email;

                        if (refNo?.Status == "Pending for Approval")
                        {
                        
                            var baseUrl = $"{Request.Scheme}://{Request.Host}";
                            var innovationUrl = $"{baseUrl}/Innovation/Innovation/Approval_Form?Id={Innovation.Id}";
                            var returnUrl = $"{baseUrl}/Innovation/User/Login?returnUrl={HttpUtility.UrlEncode(innovationUrl)}";

                            string subject = $"{refNo.Name}: has logged an Innovation";
                            string msg = $@"
   <html>
        <body>
            <p>{refNo.Name} ({refNo.Dept}) has logged the following Innovation.</p>
            <p>Innovation Id: {refNo.RefNo}</p>
            <p>Innovation: {refNo.Innovation}</p>
            <p><a href='{returnUrl}'>Click here to view the Innovation</a></p>
            <p>Regards,<br>Sashi Kumar</p>
        </body>
    </html>";

							await emailService.SendEmailAsync(requesterEmail, "smarani.vuppala@tatasteel.com", "", subject, msg);

						}
                    }

                   
                }
            }
            catch (Exception ex)
            {
			ModelState.AddModelError("Error Occured", "Unable to save changes.");
			}

			return RedirectToAction("Homepage", "Innovation");
		}



        public async Task<IActionResult> Approval_Form(Guid? id, int page = 1, string searchString = "", string statusFilter = "")
		{
			if (HttpContext.Session.GetString("Session") != null)
			{
				var userPno = HttpContext.Session.GetString("Session");
	

				if (userPno != "842015" && userPno != "151514")
				{
					return View("AccessDenied");
				}

				int pageSize = 5;
				var query = context.AppInnovations.OrderByDescending(x=>x.RefNo).AsQueryable();

				
				if (!string.IsNullOrEmpty(statusFilter))
				{
					query = query.Where(x => x.Status == statusFilter);
					
				}
				else
				{
					
					query = query.Where(x => x.Status == "Pending for Approval");
				}

				
				if (!string.IsNullOrEmpty(searchString))
				{
					query = query.Where(a => a.RefNo.Contains(searchString));
				}

				var pagedData = query.Skip((page - 1) * pageSize).Take(pageSize).ToList();
				var totalCount = query.Count();

				ViewBag.ListData2 = pagedData;
				ViewBag.CurrentPage = page;
				ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
				ViewBag.SearchString = searchString;
				ViewBag.StatusFilter = statusFilter;

				if (id.HasValue)
				{
					var model = await context.AppInnovations.FindAsync(id.Value);
					if (model == null)
					{
						return NotFound();
					}

					var benefits = await context.AppInnovationBenefits
						.Where(b => b.MasterId == model.Id)
						.ToListAsync();

					var teams = await context.AppProjectTeams
						.Where(t => t.MasterId == model.Id)
						.ToListAsync();

					var viewModel = new InnovationViewModel
					{
						PersonalNo = model.PersonalNo,
						Name = model.Name,
						RefNo = model.RefNo,
						Status = model.Status,
						Department = model.Department,
						Designation = model.Designation,
						EmailId = model.EmailId,
						Mobile = model.Mobile,
						Innovation = model.Innovation,
						Description = model.Description,
						StageOfInnovation = model.StageOfInnovation,
						SourceOfInnovation = model.SourceOfInnovation,
						Attachment = model.Attachment,
						appInnovationBenefits = benefits,
						appProjectTeams = teams,
						ApproverRemarks = model.ApproverRemarks,
						ApproverAttach = model.ApproverAttach,
						OtherBenefit = model.OtherBenefit,
						DareToTry = model.DareToTry
					};

					ViewBag.Status = viewModel.Status;
					ViewBag.Refno = viewModel.RefNo;

					var InnovationStage = context.AppStageOfInnovationMasters.Select(x => new
					{
						StageOfInnovation = x.StageOfInnovation,
						SlNo = x.SlNo,
					}).ToList().OrderBy(x => x.SlNo);

					var InnovationStagedd = InnovationStage.Select(name => new SelectListItem
					{
						Value = name.StageOfInnovation,
						Text = name.StageOfInnovation
					}).ToList();
					ViewBag.InnovationDDList = InnovationStagedd;

					var Benefit = context.AppBenefitMasters.Select(x => x.Benefit).ToList();
					var Benefitdd = Benefit.Select(name => new SelectListItem
					{
						Value = name,
						Text = name
					}).ToList();
					ViewBag.DDList = Benefitdd;

					var PnoEnameList = context1.AppEmployeeMasters
							.Select(x => new
							{
								Pno = x.Pno,
								Ename = x.Ename,
								Contact = x.Phone
							})
							.ToList();

					ViewBag.PnoEnameList = PnoEnameList;
					ViewBag.ListData = context.AppInnovations.Where(x => x.Status == "Pending for Approval").ToList();
					return View(viewModel);
				}

				return View(new InnovationViewModel());
			}
			else
			{
				return RedirectToAction("Login", "User");
			}
		}





		[HttpPost]
        [RequestSizeLimit(500 * 1024 * 1024)]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Approval_Form(InnovationViewModel InnViewModel)
		{
			if (ModelState.IsValid)
			{
				
				if (InnViewModel.Attach != null && InnViewModel.Attach.Any())
				{
					var uploadPath = configuration["FileUpload:Path"];
					foreach (var file in InnViewModel.Attach)
					{
						if (file.Length > 0)
						{
							var uniqueId = Guid.NewGuid().ToString();
							var currentDateTime = DateTime.UtcNow.ToString("dd-MM-yyyy");
							var originalFileName = Path.GetFileNameWithoutExtension(file.FileName);
							var fileExtension = Path.GetExtension(file.FileName);
							var formattedFileName = $"{uniqueId}_{currentDateTime}_{originalFileName}{fileExtension}";
							var fullPath = Path.Combine(uploadPath, formattedFileName);
							using (var stream = new FileStream(fullPath, FileMode.Create))
							{
								await file.CopyToAsync(stream);
							}
							InnViewModel.Attachment += $"{formattedFileName},";
						}
					}
					if (!string.IsNullOrEmpty(InnViewModel.Attachment))
					{
						InnViewModel.Attachment = InnViewModel.Attachment.TrimEnd(',');
					}
				}
				else if (InnViewModel.Id.HasValue)
				{
				
					var existingInnovation2 = await context.AppInnovations.FindAsync(InnViewModel.Id.Value);
					if (existingInnovation2 != null)
					{
						InnViewModel.Attachment = existingInnovation2.Attachment;
					}
				}

				var Status = Request.Form["Champion"];

				if (!InnViewModel.Id.HasValue)
				{
					ModelState.AddModelError("", "Invalid operation. The innovation Id is required.");
					return View(InnViewModel);
				}

				var existingInnovation = await context.AppInnovations.FindAsync(InnViewModel.Id.Value);

				if (existingInnovation == null)
				{
					return NotFound();
				}

				var user = HttpContext.Session.GetString("Session");

				if (Status == "Approved")
				{
					existingInnovation.ApprovedOn = DateTime.Now;
				}
				else 
				{
					existingInnovation.ApprovedOn = null;
					existingInnovation.ApprovedBy = null;
				}


				existingInnovation.PersonalNo = InnViewModel.PersonalNo;
				existingInnovation.Name = InnViewModel.Name;
				existingInnovation.Department = InnViewModel.Department;
				existingInnovation.Designation = InnViewModel.Designation;
				existingInnovation.EmailId = InnViewModel.EmailId;
				existingInnovation.Mobile = InnViewModel.Mobile;
				existingInnovation.Innovation = InnViewModel.Innovation;
				existingInnovation.Description = InnViewModel.Description;
				existingInnovation.StageOfInnovation = InnViewModel.StageOfInnovation;
				existingInnovation.Attachment = InnViewModel.Attachment;
				existingInnovation.Status = Status;
				existingInnovation.ApproverRemarks = InnViewModel.ApproverRemarks;
				existingInnovation.SubmitFlag = "Submit";
				existingInnovation.ApprovedOn = existingInnovation.ApprovedOn;
				existingInnovation.ApprovedBy =user;
				existingInnovation.SourceOfInnovation = InnViewModel.SourceOfInnovation;
				existingInnovation.OtherBenefit = InnViewModel.OtherBenefit;
				existingInnovation.DareToTry = InnViewModel.DareToTry;


				if (!string.IsNullOrEmpty(InnViewModel.OtherBenefit))
				{
					var existingBenefit = context.AppBenefitMasters.FirstOrDefault(b => b.Benefit == InnViewModel.OtherBenefit);
					if (existingBenefit == null)
					{
						var newBenefit = new AppBenefitMaster
						{
							Id = Guid.NewGuid(),
							Benefit = InnViewModel.OtherBenefit
						};
						context.AppBenefitMasters.Add(newBenefit);
					}
					else
					{
						existingBenefit.Benefit = InnViewModel.OtherBenefit;
						context.AppBenefitMasters.Update(existingBenefit);
					}
				}

				try
				{
					context.Entry(existingInnovation).State = EntityState.Modified;
					await context.SaveChangesAsync();
				}
				catch (DbUpdateConcurrencyException ex)
				{
					ModelState.AddModelError("", "Unable to save changes. The innovation was updated or deleted by another user.");
					return View(InnViewModel);
				}
               
     
                foreach (var benefit in InnViewModel.appInnovationBenefits)
				{
					if (benefit.Id == Guid.Empty)
					{
						benefit.Id = Guid.NewGuid();
						benefit.MasterId = existingInnovation.Id;
						await context.AppInnovationBenefits.AddAsync(benefit);
					}
					else
					{
						benefit.MasterId = existingInnovation.Id;
						context.Entry(benefit).State = EntityState.Modified;
					}
				}
				await context.SaveChangesAsync();

			
				foreach (var team in InnViewModel.appProjectTeams)
					{
					if (team.Id == Guid.Empty)
					{
						team.Id = Guid.NewGuid();
						team.MasterId = existingInnovation.Id;
						await context.AppProjectTeams.AddAsync(team);
					}
					else
					{
						team.MasterId = existingInnovation.Id;
						context.Entry(team).State = EntityState.Modified;
					}
				}
				await context.SaveChangesAsync();

				var refNo = await context.AppInnovations
					.Where(x => x.Id == existingInnovation.Id)
					.Select(x => x.RefNo)
					.FirstOrDefaultAsync();

				var status = await context.AppInnovations
					.Where(x => x.Id == existingInnovation.Id)
					.Select(x => x.Status)
					.FirstOrDefaultAsync();

                var emailList = await context.AppMailEmployeeMasters
    .FromSqlRaw(@"SELECT DISTINCT EmailID 
                  FROM App_MailEmployee_Master 
                  WHERE EmailID IS NOT NULL")
    .Select(e => e.EmailId) 
    .ToListAsync();


                if (status == "Approved")
                {
					var Det = HttpContext.Session.GetString("Session");
					var data = context1.AppEmployeeMasters.FirstOrDefault(x => x.Pno == InnViewModel.Pno);

				
					var EmailId = await context.AppLogins.FirstOrDefaultAsync(x => x.UserId == InnViewModel.PersonalNo);

					if (EmailId != null)
                    {
                        var RequesterEmail = EmailId.Email;

                        string statusText = status switch
                        {
                            "Approved" => "Approved",
                            "Pending With Requester" => "Returned",
                            "Rejected" => "Rejected",
                            _ => "Unknown"
                        };
                        var baseUrl = $"{Request.Scheme}://{Request.Host}";
                        var innovationUrl = $"{baseUrl}/Innovation/Innovation/AllAction?Id={existingInnovation.Id}";
                        var returnUrl = $"{baseUrl}/Innovation/User/Login?returnUrl={HttpUtility.UrlEncode(innovationUrl)}";

                        string subject = "New Innovation Project - Explore Now!";
                        string msg = $@"
            <html>
                <body>
					<p> Dear Team,</p>
                    <p><b>New Innovation : ' {existingInnovation.Innovation} ' has been launched on our portal.</b></p>
                   <p>To learn more about the project, please visit the following link : <a href='{returnUrl}'>Click here</a></br></p>
                   </BR><p> EXPLORE . INNOVATE . ELEVATE</p>
                   </BR><p> Regards,</p>
                    <b>Smarani Vuppala</br>
                    Innovation Champion</br>
                    Assistant Manager, Technical Services</b></br>
 <p><b>Tata Steel Utilities & Infrastructure Services Limited</b></br>
 (Formerly Jamshedpur Utilities & Services Company Limited)</br>
Sakchi Boulevard, Northern Town, Bistupur | Jamshedpur 831 001</br>
 Mobile +91-6287396293</br>
</br>smarani.vuppala@tatasteel.com | http://www.tatasteeluisl.com
</br><b style=color:#3a7cda;>TATA STEEL UTILITIES AND INFRASTRUCTURE SERVICES LIMITED</b>
                </body>
            </html>";


						var firstBatch = emailList.Skip(0).Take(300).ToList();
						await approvalEmail.SendEmailAsync(firstBatch, "smarani.vuppala@tatasteel.com", "", subject, msg);

						var secondBatch = emailList.Skip(300).Take(300).ToList();
						await approvalEmail.SendEmailAsync(secondBatch, "smarani.vuppala@tatasteel.com", "", subject, msg);

						var thirdBatch = emailList.Skip(600).Take(307).ToList();
						await approvalEmail.SendEmailAsync(thirdBatch, "smarani.vuppala@tatasteel.com", "", subject, msg);

					}
				}
                else
                {
                    var EmailId = await context.AppLogins.FirstOrDefaultAsync(x => x.UserId == InnViewModel.PersonalNo);
                    if (EmailId != null)
                    {
                        var RequesterEmail = EmailId.Email;

                        string statusText = status switch
                        {
                            "Approved" => "Approved",
                            "Pending With Requester" => "Returned",
                            "Rejected" => "Rejected",
                            _ => "Unknown"
                        };
                        var baseUrl = $"{Request.Scheme}://{Request.Host}";
                        var innovationUrl = $"{baseUrl}/Innovation/Innovation/AllRequest?Id={existingInnovation.Id}";
                        var returnUrl = $"{baseUrl}/Innovation/User/Login?returnUrl={HttpUtility.UrlEncode(innovationUrl)}";
                        string subject = $"Innovation Log: Innovation Id {refNo}";
                        string msg = $@"
            <html>
                <body>
                    <p><b>Innovation is {statusText} with Innovation Id: {refNo}</b></p>
                   <p><a href='{returnUrl}'>Click here to view the Innovation</a></br></p>
                   <p> Regards,</p>
                    <b>Smarani Vuppala</br>
                    Innovation Champion</br>
                    Assistant Manager, Technical Services</b></br>
 <p><b>Tata Steel Utilities & Infrastructure Services Limited</b></br>
 (Formerly Jamshedpur Utilities & Services Company Limited)</br>
Sakchi Boulevard, Northern Town, Bistupur | Jamshedpur 831 001</br>
 Mobile +91-6287396293</br>
</br>smarani.vuppala@tatasteel.com | http://www.tatasteeluisl.com
</br><b style=color:#3a7cda;>TATA STEEL UTILITIES AND INFRASTRUCTURE SERVICES LIMITED</b>
                </body>
            </html>";

						await emailService.SendEmailAsync(RequesterEmail, "smarani.vuppala@tatasteel.com", "", subject, msg);
					}
                }
                
			}

			return RedirectToAction("Homepage","Innovation");
		}


		public async Task<IActionResult> AllRequest(Guid? id, int page = 1, string searchString = "")
		{

			if (HttpContext.Session.GetString("Session") != null)
			{

				var user = HttpContext.Session.GetString("Session");

				int pageSize = 5;
			
				var query = context.AppInnovations
	.Where(x => x.PersonalNo==user)
	.Select(x => new InnovationViewModel
	{
		Id = x.Id,
		RefNo = x.RefNo,
		Innovation = x.Innovation,
		Status = x.Status,
		Views = x.Views,
		TotalLikes = context.AppLikes
						.Where(l => l.InnovationId == x.RefNo && l.Likes == true)
						.Count()
	})
	.OrderByDescending(x => x.RefNo).AsQueryable();
				if (!string.IsNullOrEmpty(searchString))
				{
					query = query.Where(a => a.RefNo.Contains(searchString));
				}
				var PagedData = query.Skip((page - 1) * pageSize).Take(pageSize).ToList();
				var TotalCount = query.Count();
				ViewBag.ListData2 = PagedData;
				ViewBag.CurrentPage = page;
				ViewBag.TotalPages = (int)Math.Ceiling(TotalCount / (double)pageSize);
				ViewBag.SearchString = searchString;

				var viewModel = new InnovationViewModel
				{
					appInnovationBenefits = new List<AppInnovationBenefit>(),
					appProjectTeams = new List<AppProjectTeam>(),
					Attach = new List<IFormFile>(),
					Attachment = string.Empty,
					
				};

				if (id.HasValue)
				{
					var model = await context.AppInnovations.FindAsync(id.Value);
					if (model == null)
					{
						return NotFound();
					}

					
					var benefits = await context.AppInnovationBenefits
						.Where(b => b.MasterId == model.Id)
						.ToListAsync();

                    var teams = await context.AppProjectTeams
                        .Where(t => t.MasterId == model.Id)
                        .ToListAsync();


                    var totalLikes = await context.AppLikes
	.Where(t => t.InnovationId == model.RefNo && t.Likes == true)
	.CountAsync();
					ViewBag.TotalLikes = totalLikes;

					viewModel = new InnovationViewModel
					{
						PersonalNo = model.PersonalNo,
						Name = model.Name,
						Department = model.Department,
						Designation = model.Designation,
						EmailId = model.EmailId,
						Mobile = model.Mobile,
						Innovation = model.Innovation,
						Description = model.Description,
						StageOfInnovation = model.StageOfInnovation,
						SourceOfInnovation = model.SourceOfInnovation,
						Attachment = model.Attachment,
						appInnovationBenefits = benefits,
						appProjectTeams = teams,
						ApproverRemarks = model.ApproverRemarks,
						ApproverAttach = model.ApproverAttach,
						OtherBenefit = model.OtherBenefit,
						Status = model.Status,
						RefNo = model.RefNo,
						Views = model.Views,
						DareToTry = model.DareToTry
					};

						ViewBag.Status = viewModel.Status;
					ViewBag.Remarks = viewModel.ApproverRemarks;
					ViewBag.Refno = viewModel.RefNo;



					var comments = await context.AppComments
				.Where(c => c.MasterId == id && c.InnovationId == viewModel.RefNo)
				.OrderByDescending(c => c.CommentOn)
				.ToListAsync();
					ViewBag.Comments = comments;

					var totalComments = await context.AppComments
		.CountAsync(c => c.InnovationId == viewModel.RefNo && !string.IsNullOrEmpty(c.Comments));

					// Pass the total comment count to the View
					ViewBag.TotalComments = totalComments;
					var employeeNames = new Dictionary<string, string>();

					foreach (var comment in comments)
					{
						var employee = await context1.AppEmployeeMasters
							.Where(e => e.Pno == comment.CommentBy)
							.FirstOrDefaultAsync();

						if (employee != null)
						{
							employeeNames[comment.CommentBy] = employee.Ename;
						}
						else
						{
							employeeNames[comment.CommentBy] = "Unknown";
						}
					}

					ViewBag.Comments = comments;
					ViewBag.EmployeeNames = employeeNames;


					var InnovationStage = context.AppStageOfInnovationMasters.Select(x => new
					{
						StageOfInnovation = x.StageOfInnovation,
						SlNo = x.SlNo,
					}).ToList().OrderBy(x => x.SlNo);

					var InnovationStagedd = InnovationStage.Select(name => new SelectListItem
					{
						Value = name.StageOfInnovation,
						Text = name.StageOfInnovation
					}).ToList();
					ViewBag.InnovationDDList = InnovationStagedd;

					var Benefit = context.AppBenefitMasters.Select(x => x.Benefit).ToList();
					var Benefitdd = Benefit.Select(name => new SelectListItem
					{
						Value = name,
						Text = name
					}).ToList();
					ViewBag.DDList = Benefitdd;

					var pnoDetails = context1.AppEmployeeMasters
							 .Select(x => new
							 {
								 Pno = x.Pno,
								 Ename = x.Ename,
								 DepartmentName = x.DepartmentName,
								 EmailId = x.EmailId,
								 Phone = x.Phone,
								 Designation = x.Designation
							 }).ToList();

					ViewBag.PnoList = pnoDetails;

					var PnoEnameList = context1.AppEmployeeMasters
						 .Select(x => new
						 {
							 Pno = x.Pno,
							 Ename = x.Ename,
							 Contact = x.Phone
						 })
						 .ToList();

					ViewBag.PnoEnameList = PnoEnameList;

					ViewBag.ListData = context.AppInnovations.ToList();
					return View(viewModel);
				}

				
				return View(new InnovationViewModel());
			}
			else
			{
				return RedirectToAction("Login", "User");
			}
		}

		[HttpPost]
        [RequestSizeLimit(500 * 1024 * 1024)]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AllRequest(InnovationViewModel InnViewModel)
		{

			if (ModelState.IsValid)
			{
		
				if (InnViewModel.Attach != null && InnViewModel.Attach.Any())
				{
					var uploadPath = configuration["FileUpload:Path"];
					foreach (var file in InnViewModel.Attach)
					{
						if (file.Length > 0)
						{
							var uniqueId = Guid.NewGuid().ToString();
							var currentDateTime = DateTime.UtcNow.ToString("dd-MM-yyyy");
							var originalFileName = Path.GetFileNameWithoutExtension(file.FileName);
							var fileExtension = Path.GetExtension(file.FileName);
							var formattedFileName = $"{uniqueId}_{currentDateTime}_{originalFileName}{fileExtension}";
							var fullPath = Path.Combine(uploadPath, formattedFileName);
							using (var stream = new FileStream(fullPath, FileMode.Create))
							{
								await file.CopyToAsync(stream);
							}
							InnViewModel.Attachment += $"{formattedFileName},";
						}
					}
					if (!string.IsNullOrEmpty(InnViewModel.Attachment))
					{
						InnViewModel.Attachment = InnViewModel.Attachment.TrimEnd(',');
					}
				}
				else if (InnViewModel.Id.HasValue)
				{
				
					var existingInnovation2 = await context.AppInnovations.FindAsync(InnViewModel.Id.Value);
					if (existingInnovation2 != null)
					{
						InnViewModel.Attachment = existingInnovation2.Attachment;
					}
				}


				if (!InnViewModel.Id.HasValue)
				{
					ModelState.AddModelError("", "Invalid operation. The innovation Id is required.");
					return View(InnViewModel);
				}

				var existingInnovation = await context.AppInnovations.FindAsync(InnViewModel.Id.Value);

				if (existingInnovation == null)
				{
					return NotFound();
				}

			
				existingInnovation.PersonalNo = InnViewModel.PersonalNo;
				existingInnovation.Name = InnViewModel.Name;
				existingInnovation.Department = InnViewModel.Department;
				existingInnovation.Designation = InnViewModel.Designation;
				existingInnovation.EmailId = InnViewModel.EmailId;
				existingInnovation.Mobile = InnViewModel.Mobile;
				existingInnovation.Innovation = InnViewModel.Innovation;
				existingInnovation.Description = InnViewModel.Description;
				existingInnovation.StageOfInnovation = InnViewModel.StageOfInnovation;
				existingInnovation.Attachment = InnViewModel.Attachment;
				existingInnovation.Status = "Pending for Approval";
				existingInnovation.ApproverRemarks = InnViewModel.ApproverRemarks;
				existingInnovation.SubmitFlag = "Submit";
				existingInnovation.SourceOfInnovation = InnViewModel.SourceOfInnovation;
				existingInnovation.OtherBenefit = InnViewModel.OtherBenefit;
				existingInnovation.DareToTry = InnViewModel.DareToTry;


			
				if (!string.IsNullOrEmpty(InnViewModel.OtherBenefit))
				{
					var existingBenefit = context.AppBenefitMasters.FirstOrDefault(b => b.Benefit == InnViewModel.OtherBenefit);
					if (existingBenefit == null)
					{
						var newBenefit = new AppBenefitMaster
						{
							Id = Guid.NewGuid(),
							Benefit = InnViewModel.OtherBenefit
						};
						context.AppBenefitMasters.Add(newBenefit);
					}
					else
					{
						existingBenefit.Benefit = InnViewModel.OtherBenefit;
						context.AppBenefitMasters.Update(existingBenefit);
					}
				}

			

				try
				{
					context.Entry(existingInnovation).State = EntityState.Modified;
					await context.SaveChangesAsync();
				}
				catch (DbUpdateConcurrencyException ex)
				{
					ModelState.AddModelError("", "Unable to save changes.");
					return View(InnViewModel);
				}

			
				foreach (var benefit in InnViewModel.appInnovationBenefits)
				{
					if (benefit.Id == Guid.Empty)
					{
						benefit.Id = Guid.NewGuid();
						benefit.MasterId = existingInnovation.Id;
						await context.AppInnovationBenefits.AddAsync(benefit);
					}
					else
					{
						benefit.MasterId = existingInnovation.Id;
						context.Entry(benefit).State = EntityState.Modified;
					}
				}
				await context.SaveChangesAsync();

			
				foreach (var team in InnViewModel.appProjectTeams)
				{
					if (team.Id == Guid.Empty)
					{
						team.Id = Guid.NewGuid();
						team.MasterId = existingInnovation.Id;
						await context.AppProjectTeams.AddAsync(team);
					}
					else
					{
						team.MasterId = existingInnovation.Id;
						context.Entry(team).State = EntityState.Modified;
					}
				}
				await context.SaveChangesAsync();

				var refNo = await context.AppInnovations
					.Where(x => x.Id == existingInnovation.Id)
					.Select(x => x.RefNo)
					.FirstOrDefaultAsync();

				var status = await context.AppInnovations
					.Where(x => x.Id == existingInnovation.Id)
					.Select(x => x.Status)
					.FirstOrDefaultAsync();

                var EmailId = await context.AppLogins.FirstOrDefaultAsync(x => x.UserId == InnViewModel.PersonalNo);

				if (EmailId != null)
				{
					var RequesterEmail = EmailId.Email;


					if (status == "Pending for Approval")
					{

                        var baseUrl = $"{Request.Scheme}://{Request.Host}";
                        var innovationUrl = $"{baseUrl}/Innovation/Innovation/Approval_Form?Id={existingInnovation.Id}";
                        var returnUrl = $"{baseUrl}/Innovation/User/Login?returnUrl={HttpUtility.UrlEncode(innovationUrl)}";

                        string subject = $"Innovation Log: Innovation Id {refNo}";
                        string msg = $@"
            <html>
                <body>
                    <p><b>Innovation is {status} with Innovation Id: {refNo}</b></p>
                    <p><a href='{returnUrl}'>Click here to view the Innovation</a></p>
                    <p>Thanks & Regards</p>
                </body>
            </html>";

						await emailService.SendEmailAsync("smarani.vuppala@tatasteel.com", RequesterEmail, "", subject, msg);
					}
				}
			}

			return RedirectToAction("Homepage", "Innovation");
		}
		
		public async Task<IActionResult> AllAction(Guid? id, int page = 1, string searchString = "")
		{
			if (HttpContext.Session.GetString("Session") != null)
			{
				string searchValue = HttpContext.Request.Query["searchValue"];
				string searchType = HttpContext.Request.Query["searchType"];

				int pageSize = 4;

				var query = context.AppInnovations
	.Where(x => x.Status == "Approved")
	.Select(x => new InnovationViewModel
	{
		Id = x.Id,
		RefNo = x.RefNo,
		Innovation = x.Innovation,
		Views = x.Views,
		TotalLikes = context.AppLikes
						.Where(l => l.InnovationId == x.RefNo && l.Likes == true)
						.Count(),
		StageOfInnovation = x.StageOfInnovation, 
		SourceOfInnovation = x.SourceOfInnovation 
	})
	.OrderByDescending(x => x.RefNo)
	.AsQueryable();

				if (!string.IsNullOrEmpty(searchValue) && !string.IsNullOrEmpty(searchType))
				{
					if (searchType == "Innovation")
					{
						query = query.Where(p => p.Innovation.Contains(searchValue));
					}
					else if (searchType == "RefNo")
					{
						query = query.AsEnumerable() // Client-side evaluation
									 .Where(p => p.RefNo.ToString().Contains(searchValue))
									 .AsQueryable();
					}
					else if (searchType == "StageOfInnovation")
					{
						query = query.Where(p => p.StageOfInnovation.Contains(searchValue));
					}
					else if (searchType == "SourceOfInnovation")
					{
						query = query.Where(p => p.SourceOfInnovation.Contains(searchValue));
					}
				}


				// Perform pagination
				var PagedData = query.Skip((page - 1) * pageSize).Take(pageSize).ToList();
				var TotalCount = query.Count();

				ViewBag.ListData2 = PagedData;
				ViewBag.CurrentPage = page;
				ViewBag.TotalPages = (int)Math.Ceiling(TotalCount / (double)pageSize);

				ViewBag.SearchValue = searchValue;
				ViewBag.SearchType = searchType;

				var viewModel = new InnovationViewModel
				{
					appInnovationBenefits = new List<AppInnovationBenefit>(),
					appProjectTeams = new List<AppProjectTeam>(),
					Attach = new List<IFormFile>(),
					Attachment = string.Empty,
				};

				if (id.HasValue)
				{
					
					var model = await context.AppInnovations.FindAsync(id.Value);
					if (model == null)
					{
						return NotFound();
					}
					if (model.Views == null)
					{
						model.Views = 0;

					}
					ViewBag.TotalViews = model.Views;
					model.Views += 1;

					context.AppInnovations.Update(model);
					await context.SaveChangesAsync();
					
				
					var benefits = await context.AppInnovationBenefits
						.Where(b => b.MasterId == model.Id)
						.ToListAsync();

					var teams = await context.AppProjectTeams
						.Where(t => t.MasterId == model.Id)
						.ToListAsync();


					

					var totalLikes = await context.AppLikes
	.Where(t => t.InnovationId == model.RefNo && t.Likes == true)
	.CountAsync();

					viewModel = new InnovationViewModel
					{
						Id = model.Id,
						PersonalNo = model.PersonalNo,
						Name = model.Name,
						Department = model.Department,
						Designation = model.Designation,
						EmailId = model.EmailId,
						Mobile = model.Mobile,
						Innovation = model.Innovation,
						Description = model.Description,
						StageOfInnovation = model.StageOfInnovation,
						SourceOfInnovation = model.SourceOfInnovation,
						Attachment = model.Attachment,
						appInnovationBenefits = benefits,
						appProjectTeams = teams,
						ApproverRemarks = model.ApproverRemarks,
						ApproverAttach = model.ApproverAttach,
						OtherBenefit = model.OtherBenefit,
						Status = model.Status,
						RefNo = model.RefNo,
						Views = model.Views,
						DareToTry = model.DareToTry
						
					};

					ViewBag.Status = viewModel.Status;
					ViewBag.Remarks = viewModel.ApproverRemarks;
					ViewBag.Refno = viewModel.RefNo;

					ViewBag.TotalLikes = totalLikes;

					var comments = await context.AppComments
					.Where(c => c.MasterId == id && c.InnovationId == viewModel.RefNo)
					.OrderByDescending(c => c.CommentOn)
					.ToListAsync();

					ViewBag.Comments = comments;

					var totalComments = await context.AppComments
		.CountAsync(c => c.InnovationId == viewModel.RefNo && !string.IsNullOrEmpty(c.Comments));

					// Pass the total comment count to the View
					ViewBag.TotalComments = totalComments;
					var employeeNames = new Dictionary<string, string>();

					foreach (var comment in comments)
					{
						var employee = await context1.AppEmployeeMasters
							.Where(e => e.Pno == comment.CommentBy)
							.FirstOrDefaultAsync();

						if (employee != null)
						{
							employeeNames[comment.CommentBy] = employee.Ename;
						}
						else
						{
							employeeNames[comment.CommentBy] = "Unknown";
						}
					}
					ViewBag.EmployeeNames = employeeNames;
					var InnovationStage = context.AppStageOfInnovationMasters.Select(x => new
					{
						StageOfInnovation = x.StageOfInnovation,
						SlNo = x.SlNo,
					}).ToList().OrderBy(x => x.SlNo);

					var InnovationStagedd = InnovationStage.Select(name => new SelectListItem
					{
						Value = name.StageOfInnovation,
						Text = name.StageOfInnovation
					}).ToList();
					ViewBag.InnovationDDList = InnovationStagedd;

					var Benefit = context.AppBenefitMasters.Select(x => x.Benefit).ToList();
					var Benefitdd = Benefit.Select(name => new SelectListItem
					{
						Value = name,
						Text = name
					}).ToList();
					ViewBag.DDList = Benefitdd;

					var pnoDetails = context1.AppEmployeeMasters
						 .Select(x => new
						 {
							 Pno = x.Pno,
							 Ename = x.Ename,
							 DepartmentName = x.DepartmentName,
							 EmailId = x.EmailId,
							 Phone = x.Phone,
							 Designation = x.Designation
						 }).ToList();

					ViewBag.PnoList = pnoDetails;

					var PnoEnameList = context1.AppEmployeeMasters
						 .Select(x => new
						 {
							 Pno = x.Pno,
							 Ename = x.Ename,
							 Contact = x.Phone
						 })
						 .ToList();

					ViewBag.PnoEnameList = PnoEnameList;

					ViewBag.ListData = context.AppInnovations.ToList();
					return View(viewModel);
				}

				return View(new InnovationViewModel());
			}
			else
			{
				return RedirectToAction("Login", "User");
			}
		}



		[HttpPost]
		public async Task<IActionResult> AllAction(Guid Id, InnovationViewModel InnViewModel, string RefNo, string Comment, string actionType)
		{
			var pno = HttpContext.Session.GetString("Session");

			if (string.IsNullOrEmpty(pno))
			{
				return Json(new { success = false, message = "User not logged in." });
			}

			if (actionType == "Like")
			{
				var likeRecord = await context.AppLikes
					.FirstOrDefaultAsync(l => l.MasterId == Id && l.Pno == pno && l.InnovationId == RefNo);

				if (likeRecord != null)
				{
					return Json(new { success = true, message = "You have already liked this innovation." });
				}
				else
				{
					likeRecord = new AppLike
					{
						MasterId = Id,
						Pno = pno,
						InnovationId = RefNo,
						Likes = true
					};
					await context.AppLikes.AddAsync(likeRecord);
				}

				var innovationRecord = await context.AppInnovations.FirstOrDefaultAsync(i => i.Id == Id);
				if (innovationRecord != null)
				{
					innovationRecord.Views = (innovationRecord.Views > 0) ? innovationRecord.Views - 1 : 0;
					context.AppInnovations.Update(innovationRecord);
				}

				await context.SaveChangesAsync();

				var totalLikes = await context.AppLikes.CountAsync(l => l.InnovationId == RefNo);

				return Json(new { success = true, message = "Thank you for Liking the innovation", totalLikes = totalLikes });
			}

			if (actionType == "Comment" && !string.IsNullOrEmpty(Comment))
			{
				var commentRecord = new AppComment
				{
					MasterId = Id,
					CommentBy = pno,
					InnovationId = RefNo,
					Comments = Comment,
					CommentOn = DateTime.Now
				};

				await context.AppComments.AddAsync(commentRecord);
				await context.SaveChangesAsync();

			
				var employee = await context1.AppEmployeeMasters
	 .FirstOrDefaultAsync(e => e.Pno == commentRecord.CommentBy);

				var employeeName = employee?.Ename ?? "Unknown";

				
				return Json(new
				{
					success = true,
					message = "Comment posted successfully",
					comment = new
					{
						CommentBy = commentRecord.CommentBy,
						EmployeeName = employeeName, 
						CommentOn = commentRecord.CommentOn,
						Comments = commentRecord.Comments
					}
				});

			}
		

			return Json(new { success = false, message = "Invalid action type." });
		}




		public async Task<IActionResult> Innovation_Evaluation(Guid? id, int page = 1, string searchString = "", string FinYear = "", string HalfYear = "")
		{
			if (HttpContext.Session.GetString("Session") != null)
			{

				var viewModel2 = new InnovationViewModel
				{
					appInnovationBenefits = new List<AppInnovationBenefit>(),
					appProjectTeams = new List<AppProjectTeam>(),
					Attach = new List<IFormFile>(),
					Attachment = string.Empty,
					appEvaluations = new List<AppEvaluationDetail>()
				};


				var userPno = HttpContext.Session.GetString("Session");

				if (userPno != "842015" && userPno != "151514")
				{
					return View("AccessDenied");
				}

				int pageSize = 5;


				var query = context.AppInnovations
					.Where(x => x.Status == "Approved")
					.Select(x => new InnovationViewModel
					{
						Id = x.Id,
						RefNo = x.RefNo,
						Innovation = x.Innovation,
						Pno = x.PersonalNo,
						CreatedOn = x.CreatedOn,
						ApprovedOn = x.ApprovedOn
					})
					.OrderByDescending(x => x.RefNo)
					.AsQueryable();

				if (!string.IsNullOrEmpty(searchString))
				{
					query = query.Where(a => a.RefNo.Contains(searchString));
				}

				if (!string.IsNullOrEmpty(FinYear) && FinYear != "Select Fin Year")
				{
					DateTime startDate = DateTime.MinValue;
					DateTime endDate = DateTime.MaxValue;

				
					if (FinYear == "24-25")
					{
						startDate = new DateTime(2024, 4, 1);
						endDate = new DateTime(2025, 3, 31); 
					}
					else if (FinYear == "25-26")
					{
						startDate = new DateTime(2025, 4, 1);
						endDate = new DateTime(2026, 3, 31);
					}
					else if (FinYear == "26-27")
					{
						startDate = new DateTime(2026, 4, 1);
						endDate = new DateTime(2027, 3, 31);
					}
					else if (FinYear == "27-28")
					{
						startDate = new DateTime(2027, 4, 1);
						endDate = new DateTime(2028, 3, 31);
					}
					else if (FinYear == "28-29")
					{
						startDate = new DateTime(2028, 4, 1);
						endDate = new DateTime(2029, 3, 31);
					}
					else if (FinYear == "29-30")
					{
						startDate = new DateTime(2029, 4, 1);
						endDate = new DateTime(2030, 3, 31);
					}

					
					query = query.Where(a => a.CreatedOn >= startDate && a.CreatedOn <= endDate);

				
					if (!string.IsNullOrEmpty(HalfYear) && HalfYear != "Select Half")
					{
						if (HalfYear == "H1")
						{
							query = query.Where(a => a.CreatedOn >= startDate && a.CreatedOn <= new DateTime(startDate.Year, 9, 30));
						}
						else if (HalfYear == "H2")
						{
							query = query.Where(a => a.CreatedOn >= new DateTime(startDate.Year, 10, 1) && a.CreatedOn <= endDate);
						}
					}
				}


				var pagedData = query.Skip((page - 1) * pageSize).Take(pageSize).ToList();

			
				pagedData.ForEach(x =>
				{
					x.TotalLikes = context.AppLikes
						.Where(l => l.InnovationId == x.RefNo && l.Likes == true)
						.Count();

					x.Score = context.AppEvaluationDetails
						.Where(e => e.MasterId == x.Id)
						.Sum(e => (decimal?)e.Score) ?? 0m;
				});

				var totalCount = query.Count();

				ViewBag.ListData2 = pagedData;
				ViewBag.CurrentPage = page;
				ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
				ViewBag.SearchString = searchString;
				ViewBag.FinYear = FinYear;
				ViewBag.HalfYear = HalfYear;

				if (id.HasValue)
				{
					var model = await context.AppInnovations.FindAsync(id.Value);
					if (model == null)
					{
						return NotFound();
					}

					var benefits = await context.AppInnovationBenefits
						.Where(b => b.MasterId == model.Id)
						.ToListAsync();

					var teams = await context.AppProjectTeams
						.Where(t => t.MasterId == model.Id)
						.ToListAsync();

					var Evaluation = await context.AppEvaluationDetails.FromSqlRaw("select * from App_Evaluation_Details where MasterId ='" + id + "'").ToListAsync();

				
					var Parameters = await context.AppParameters.
					FromSqlRaw(@"select *  from App_Parameters order by cast (SUBSTRING(Parameter_Code,7,LEN(Parameter_Code)) as int)").ToListAsync();
					             ViewBag.Parameters = Parameters;

					var viewModel = new InnovationViewModel
					{
						PersonalNo = model.PersonalNo,
						Name = model.Name,
						RefNo = model.RefNo,
						Status = model.Status,
						Department = model.Department,
						Designation = model.Designation,
						EmailId = model.EmailId,
						Mobile = model.Mobile,
						Innovation = model.Innovation,
						Description = model.Description,
						StageOfInnovation = model.StageOfInnovation,
						SourceOfInnovation = model.SourceOfInnovation,
						Attachment = model.Attachment,
						appInnovationBenefits = benefits,
						appProjectTeams = teams,
						ApproverRemarks = model.ApproverRemarks,
						ApproverAttach = model.ApproverAttach,
						OtherBenefit = model.OtherBenefit,
						appEvaluations = Evaluation,
						DareToTry = model.DareToTry
					};

					ViewBag.Status = viewModel.Status;
					ViewBag.Refno = viewModel.RefNo;

					var InnovationStage = context.AppStageOfInnovationMasters.Select(x => new
					{
						StageOfInnovation = x.StageOfInnovation,
						SlNo = x.SlNo,
					}).ToList().OrderBy(x => x.SlNo);

					var InnovationStagedd = InnovationStage.Select(name => new SelectListItem
					{
						Value = name.StageOfInnovation,
						Text = name.StageOfInnovation
					}).ToList();
					ViewBag.InnovationDDList = InnovationStagedd;

					var Benefit = context.AppBenefitMasters.Select(x => x.Benefit).ToList();
					var Benefitdd = Benefit.Select(name => new SelectListItem
					{
						Value = name,
						Text = name
					}).ToList();
					ViewBag.DDList = Benefitdd;

					var PnoEnameList = context1.AppEmployeeMasters
							.Select(x => new
							{
								Pno = x.Pno,
								Ename = x.Ename,
								Contact = x.Phone
							})
							.ToList();

					ViewBag.PnoEnameList = PnoEnameList;
					ViewBag.ListData = context.AppInnovations.Where(x => x.Status == "Pending for Approval").ToList();



					var matrixMasterList = await context.AppMatrixMasters.ToListAsync();

				
					var existingEvaluations = await context.AppEvaluationDetails
						.Where(e => e.MasterId == id.Value)
						.ToListAsync();

					var parameterDescriptions = new Dictionary<string, Dictionary<int, string>>();
					var existingEvaluationMap = new Dictionary<string, HashSet<int>>();

					foreach (var matrix in matrixMasterList)
					{
						if (!string.IsNullOrEmpty(matrix.ParameterCode) && matrix.ScoreCode.HasValue && !string.IsNullOrEmpty(matrix.MatrixDesc))
						{
							int scoreCode = matrix.ScoreCode.Value;

							if (!parameterDescriptions.ContainsKey(matrix.ParameterCode))
							{
								parameterDescriptions[matrix.ParameterCode] = new Dictionary<int, string>();
							}

							parameterDescriptions[matrix.ParameterCode][scoreCode] = matrix.MatrixDesc;
						}
					}

				
					foreach (var evaluation in existingEvaluations)
					{
						if (!existingEvaluationMap.ContainsKey(evaluation.ParameterCode))
						{
							existingEvaluationMap[evaluation.ParameterCode] = new HashSet<int>();
						}

					
						existingEvaluationMap[evaluation.ParameterCode].Add(evaluation.Sc2.GetValueOrDefault());
						existingEvaluationMap[evaluation.ParameterCode].Add(evaluation.Sc4.GetValueOrDefault());
						existingEvaluationMap[evaluation.ParameterCode].Add(evaluation.Sc6.GetValueOrDefault());
						existingEvaluationMap[evaluation.ParameterCode].Add(evaluation.Sc8.GetValueOrDefault());
						existingEvaluationMap[evaluation.ParameterCode].Add(evaluation.Sc10.GetValueOrDefault());

					}

					ViewBag.ParameterDescriptions = parameterDescriptions;
					ViewBag.ExistingEvaluationMap = existingEvaluationMap;
					return View(viewModel);
				}





				return View(new InnovationViewModel());
			}
			else
			{
				return RedirectToAction("Login", "User");
			}
		}

		[HttpPost]
		public async Task<IActionResult> Innovation_Evaluation(IFormCollection form, Guid? id)
		{
			if (HttpContext.Session.GetString("Session") == null)
			{
				return RedirectToAction("Login", "User");
			}

			var userPno = HttpContext.Session.GetString("Session");
			if (userPno != "842015" && userPno != "151514")
			{
				return View("AccessDenied");
			}

			if (!id.HasValue)
			{
				return BadRequest("ID is required");
			}

		
			var existingEvaluations = await context.AppEvaluationDetails
				.Where(e => e.MasterId == id.Value)
				.ToListAsync();

		
			var parameters = await context.AppParameters
				.FromSqlRaw("Select * From App_Parameters")
				.ToListAsync();

			
			foreach (var param in parameters)
			{
				var ParameterCode = param.ParameterCode;
				var selectedValue = form["HiddenScore_" + ParameterCode];
					

			
				if (!string.IsNullOrEmpty(selectedValue) && decimal.TryParse(selectedValue, out decimal selectedScore))
				{
					
					decimal weightage = param.Weightage ?? 0;
					decimal CalculatedScore = (selectedScore * weightage) / 100;

					
					var existingEvaluation = existingEvaluations
						.FirstOrDefault(e => e.ParameterCode == ParameterCode);

					if (existingEvaluation != null)
					{
						
						existingEvaluation.CreatedOn = DateTime.Now;
						existingEvaluation.CreatedBy = userPno;

						existingEvaluation.Sc2 = 0;
						existingEvaluation.Sc4 = 0;
						existingEvaluation.Sc6 = 0;
						existingEvaluation.Sc8 = 0;
						existingEvaluation.Sc10 = 0;

				
						switch (selectedScore)
						{
							case 20: existingEvaluation.Sc2 = 20; break;
							case 40: existingEvaluation.Sc4 = 40; break;
							case 60: existingEvaluation.Sc6 = 60; break;
							case 80: existingEvaluation.Sc8 = 80; break;
							case 100: existingEvaluation.Sc10 = 100; break;
						}

						existingEvaluation.Score = CalculatedScore;
					}
					else
					{
						
						bool isDuplicate = await context.AppEvaluationDetails
							.AnyAsync(e => e.ParameterCode == ParameterCode && e.MasterId == id.Value);

						if (!isDuplicate)
						{
							
							var newEvaluation = new AppEvaluationDetail
							{
								Id = Guid.NewGuid(),
								ParameterCode = ParameterCode,
								MasterId = id.Value,
								CreatedOn = DateTime.Now,
								CreatedBy = userPno,
								Score = CalculatedScore
							};

							switch (selectedScore)
							{
								case 20: newEvaluation.Sc2 = 20; break;
								case 40: newEvaluation.Sc4 = 40; break;
								case 60: newEvaluation.Sc6 = 60; break;
								case 80: newEvaluation.Sc8 = 80; break;
								case 100: newEvaluation.Sc10 = 100; break;
							}

							await context.AppEvaluationDetails.AddAsync(newEvaluation);
						}
					}
				}
			}

			await context.SaveChangesAsync();

			return RedirectToAction("Homepage", "Innovation");
		}





		public IActionResult DownloadFile(string fileName)
		{
			var uploadPath = configuration["FileUpload:Path"];
			var filePath = Path.Combine(uploadPath, fileName);

			if (!System.IO.File.Exists(filePath))
			{
				return NotFound();
			}

			var memory = new MemoryStream();
			using (var stream = new FileStream(filePath, FileMode.Open))
			{
				stream.CopyTo(memory);
			}
			memory.Position = 0;

			return File(memory, GetContentType(filePath), Path.GetFileName(filePath));
		}

		private string GetContentType(string path)
		{
			var types = GetMimeTypes();
			var ext = Path.GetExtension(path).ToLowerInvariant();
			return types[ext];
		}

		private Dictionary<string, string> GetMimeTypes()
		{
			return new Dictionary<string, string>
	{
		{ ".txt", "text/plain" },
		{ ".pdf", "application/pdf" },
		{ ".doc", "application/vnd.ms-word" },
		{ ".docx", "application/vnd.ms-word" },
		{ ".xls", "application/vnd.ms-excel" },
		{ ".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" },
		{ ".png", "image/png" },
		{ ".jpg", "image/jpeg" },
		{ ".jpeg", "image/jpeg" },
		{ ".gif", "image/gif" },
		{ ".mp4", "video/mp4" },
		{ ".mpkg", "application/vnd.apple.installer+xml" },
		{ ".mov", "video/quicktime" },
		{ ".bmp", "image/x-MS-bmp" },
		{ ".csv", "text/csv" },
		{ ".ppt", "application/vnd.ms-powerpoint" }, 
        { ".pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation" } 
    };
		}
		public IActionResult Signout()
		{
			HttpContext.Session.Remove("Session");
			return RedirectToAction("Login", "User");

		}
	}
	
}
