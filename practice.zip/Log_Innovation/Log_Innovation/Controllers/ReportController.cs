﻿using Microsoft.AspNetCore.Mvc;

namespace Log_Innovation.Controllers
{
	public class ReportController : Controller
	{
		public IActionResult InnovationReport()
		{
            if (HttpContext.Session.GetString("Session") != null)
            {

            }
			else
			{
				return RedirectToAction("Login", "User");
			}
            return View();
		}
	}
}
