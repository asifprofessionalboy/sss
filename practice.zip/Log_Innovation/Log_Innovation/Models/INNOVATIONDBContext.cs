﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Log_Innovation.Models
{
    public partial class INNOVATIONDBContext : DbContext
    {
        public INNOVATIONDBContext()
        {
        }

        public INNOVATIONDBContext(DbContextOptions<INNOVATIONDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AppBenefitMaster> AppBenefitMasters { get; set; } = null!;
        public virtual DbSet<AppComment> AppComments { get; set; } = null!;
        public virtual DbSet<AppEvaluationDetail> AppEvaluationDetails { get; set; } = null!;
        public virtual DbSet<AppFeedback> AppFeedbacks { get; set; } = null!;
        public virtual DbSet<AppInnovation> AppInnovations { get; set; } = null!;
        public virtual DbSet<AppInnovationBenefit> AppInnovationBenefits { get; set; } = null!;
        public virtual DbSet<AppLike> AppLikes { get; set; } = null!;
        public virtual DbSet<AppLogin> AppLogins { get; set; } = null!;
        public virtual DbSet<AppMailEmployeeMaster> AppMailEmployeeMasters { get; set; } = null!;
        public virtual DbSet<AppMatrixMaster> AppMatrixMasters { get; set; } = null!;
        public virtual DbSet<AppParameter> AppParameters { get; set; } = null!;
        public virtual DbSet<AppProjectTeam> AppProjectTeams { get; set; } = null!;
        public virtual DbSet<AppScore> AppScores { get; set; } = null!;
        public virtual DbSet<AppStageOfInnovationMaster> AppStageOfInnovationMasters { get; set; } = null!;
        public virtual DbSet<AppSysAutoNumber> AppSysAutoNumbers { get; set; } = null!;
        public virtual DbSet<Table> Tables { get; set; } = null!;
        public virtual DbSet<TestTbl> TestTbls { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {

            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AppBenefitMaster>(entity =>
            {
                entity.ToTable("App_Benefit_Master");

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

                entity.Property(e => e.Benefit).IsUnicode(false);
            });

            modelBuilder.Entity<AppComment>(entity =>
            {
                entity.ToTable("App_Comments");

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

                entity.Property(e => e.CommentBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CommentOn).HasColumnType("datetime");

                entity.Property(e => e.Comments).IsUnicode(false);

                entity.Property(e => e.InnovationId)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<AppEvaluationDetail>(entity =>
            {
                entity.ToTable("App_Evaluation_Details");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.ParameterCode)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("Parameter_Code");

                entity.Property(e => e.Sc10)
                    .HasColumnName("Sc_10")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Sc2)
                    .HasColumnName("Sc_2")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Sc4)
                    .HasColumnName("Sc_4")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Sc6)
                    .HasColumnName("Sc_6")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Sc8)
                    .HasColumnName("Sc_8")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Score).HasColumnType("decimal(18, 2)");
            });

            modelBuilder.Entity<AppFeedback>(entity =>
            {
                entity.ToTable("App_Feedback");

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

                entity.Property(e => e.Comments).IsUnicode(false);

                entity.Property(e => e.Views).IsUnicode(false);
            });

            modelBuilder.Entity<AppInnovation>(entity =>
            {
                entity.ToTable("App_Innovation");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.ApprovedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ApprovedOn).HasColumnType("datetime");

                entity.Property(e => e.ApproverAttach)
                    .IsUnicode(false)
                    .HasColumnName("Approver_Attach");

                entity.Property(e => e.ApproverRemarks)
                    .IsUnicode(false)
                    .HasColumnName("Approver_Remarks");

                entity.Property(e => e.Attachment).IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.DareToTry)
                    .IsUnicode(false)
                    .HasColumnName("Dare_To_Try");

                entity.Property(e => e.Department)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Description).IsUnicode(false);

                entity.Property(e => e.Designation)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EmailId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Email_Id");

                entity.Property(e => e.Innovation)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OtherBenefit).IsUnicode(false);

                entity.Property(e => e.PersonalNo)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("Personal_No");

                entity.Property(e => e.RefNo)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("Ref_No");

                entity.Property(e => e.SourceOfInnovation)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Source_of_Innovation");

                entity.Property(e => e.StageOfInnovation)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Stage_of_Innovation");

                entity.Property(e => e.Status)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.SubmitFlag)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Submit_Flag");
            });

            modelBuilder.Entity<AppInnovationBenefit>(entity =>
            {
                entity.ToTable("App_Innovation_Benefits");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("ID");

                entity.Property(e => e.Benefits)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.MasterId).HasColumnName("Master_ID");
            });

            modelBuilder.Entity<AppLike>(entity =>
            {
                entity.ToTable("App_Like");

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

                entity.Property(e => e.InnovationId)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Pno)
                    .HasMaxLength(6)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<AppLogin>(entity =>
            {
                entity.ToTable("App_Login");

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

                entity.Property(e => e.Comment).HasColumnType("ntext");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.Email).HasMaxLength(256);

                entity.Property(e => e.FailedPasswordAnswerAttemptWindowStart).HasColumnType("datetime");

                entity.Property(e => e.FailedPasswordAttemptWindowStart).HasColumnType("datetime");

                entity.Property(e => e.LastLockoutDate).HasColumnType("datetime");

                entity.Property(e => e.LastLoginDate).HasColumnType("datetime");

                entity.Property(e => e.LastPasswordChangedDate).HasColumnType("datetime");

                entity.Property(e => e.LoweredEmail).HasMaxLength(256);

                entity.Property(e => e.MobilePin)
                    .HasMaxLength(16)
                    .HasColumnName("MobilePIN");

                entity.Property(e => e.Password).HasMaxLength(128);

                entity.Property(e => e.PasswordAnswer).HasMaxLength(128);

                entity.Property(e => e.PasswordQuestion).HasMaxLength(256);

                entity.Property(e => e.PasswordSalt).HasMaxLength(128);

                entity.Property(e => e.UserId)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<AppMailEmployeeMaster>(entity =>
            {
                entity.ToTable("App_MailEmployee_Master");

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Ename)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("EName");

                entity.Property(e => e.Grade)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Pno)
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.Type)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<AppMatrixMaster>(entity =>
            {
                entity.ToTable("App_Matrix_Master");

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MatrixDesc)
                    .IsUnicode(false)
                    .HasColumnName("Matrix_Desc");

                entity.Property(e => e.ParameterCode)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("Parameter_Code");

                entity.Property(e => e.ScoreCode).HasColumnName("Score_Code");
            });

            modelBuilder.Entity<AppParameter>(entity =>
            {
                entity.ToTable("App_Parameters");

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ParameterCode)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("Parameter_Code");

                entity.Property(e => e.ParameterDesc)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("Parameter_Desc");
            });

            modelBuilder.Entity<AppProjectTeam>(entity =>
            {
                entity.ToTable("App_Project_Team");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("ID");

                entity.Property(e => e.EmployeeName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MasterId).HasColumnName("MasterID");

                entity.Property(e => e.Pno)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<AppScore>(entity =>
            {
                entity.ToTable("App_Score");

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

                entity.Property(e => e.ScoreCode)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("Score_Code");

                entity.Property(e => e.ScoreDesc)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Score_Desc");
            });

            modelBuilder.Entity<AppStageOfInnovationMaster>(entity =>
            {
                entity.ToTable("App_StageOfInnovation_Master");

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

                entity.Property(e => e.StageOfInnovation)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<AppSysAutoNumber>(entity =>
            {
                entity.HasKey(e => e.ObjName);

                entity.ToTable("App_Sys_AutoNumber");

                entity.Property(e => e.ObjName)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Leftpadding)
                    .HasColumnName("leftpadding")
                    .HasDefaultValueSql("((5))");

                entity.Property(e => e.Number).HasColumnName("number");

                entity.Property(e => e.Postfix)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Prefix)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Table>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("Table");

                entity.Property(e => e.Address)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("name");
            });

            modelBuilder.Entity<TestTbl>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("TestTbl");

                entity.Property(e => e.Address)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Id).HasDefaultValueSql("(newid())");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("name");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
