﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class AppFeedback
    {
        public Guid Id { get; set; }
        public int? Likes { get; set; }
        public string? Comments { get; set; }
        public string? Views { get; set; }
    }
}
