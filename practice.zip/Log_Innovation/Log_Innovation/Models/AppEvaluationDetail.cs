﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class AppEvaluationDetail
    {
        public Guid Id { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public Guid MasterId { get; set; }
        public string? ParameterCode { get; set; }
        public int? Sc2 { get; set; }
        public int? Sc4 { get; set; }
        public int? Sc6 { get; set; }
        public int? Sc8 { get; set; }
        public int? Sc10 { get; set; }
        public decimal? Score { get; set; }
    }
}
