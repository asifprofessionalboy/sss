﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class AppInnovation
    {
        public Guid Id { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string? PersonalNo { get; set; }
        public string? Name { get; set; }
        public string? Department { get; set; }
        public string? Designation { get; set; }
        public string? EmailId { get; set; }
        public long? Mobile { get; set; }
        public string? Innovation { get; set; }
        public string? Description { get; set; }
        public string? DareToTry { get; set; }
        public string? OtherBenefit { get; set; }
        public string? StageOfInnovation { get; set; }
        public string? SourceOfInnovation { get; set; }
        public string? Attachment { get; set; }
        public string? Status { get; set; }
        public string? RefNo { get; set; }
        public string? ApproverRemarks { get; set; }
        public string? ApproverAttach { get; set; }
        public string? ApprovedBy { get; set; }
        public DateTime? ApprovedOn { get; set; }
        public string? SubmitFlag { get; set; }
        public int? Views { get; set; }
    }
}
