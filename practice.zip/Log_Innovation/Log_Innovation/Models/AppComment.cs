﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class AppComment
    {
        public Guid Id { get; set; }
        public Guid MasterId { get; set; }
        public string? InnovationId { get; set; }
        public string? Comments { get; set; }
        public string? CommentBy { get; set; }
        public DateTime? CommentOn { get; set; }
    }
}
