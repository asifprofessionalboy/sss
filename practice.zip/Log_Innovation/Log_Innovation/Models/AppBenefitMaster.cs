﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class AppBenefitMaster
    {
        public Guid Id { get; set; }
        public string? Benefit { get; set; }
    }
}
