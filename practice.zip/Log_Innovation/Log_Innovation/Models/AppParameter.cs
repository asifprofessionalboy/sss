﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class AppParameter
    {
        public Guid Id { get; set; }
        public string? ParameterCode { get; set; }
        public string? ParameterDesc { get; set; }
        public int? Weightage { get; set; }
        public DateTime? CreatedOn { get; set; }
    }
}
