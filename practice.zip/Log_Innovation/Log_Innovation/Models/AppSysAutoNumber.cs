﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class AppSysAutoNumber
    {
        public string ObjName { get; set; } = null!;
        public string? Prefix { get; set; }
        public string? Postfix { get; set; }
        public int? Number { get; set; }
        public int Leftpadding { get; set; }
        public bool? IsActive { get; set; }
        public DateTime CreateDate { get; set; }
    }
}
