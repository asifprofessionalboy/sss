﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class AppMailEmployeeMaster
    {
        public Guid Id { get; set; }
        public string? Pno { get; set; }
        public string? Ename { get; set; }
        public string? EmailId { get; set; }
        public string? Grade { get; set; }
        public string? Type { get; set; }
    }
}
