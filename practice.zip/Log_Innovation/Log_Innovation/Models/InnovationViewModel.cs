﻿namespace Log_Innovation.Models
{
    public class InnovationViewModel
    {
        public InnovationViewModel() 
        {
            appInnovationBenefits = new List<AppInnovationBenefit>();
            AppInnovation = new AppInnovation();    
            appProjectTeams= new List<AppProjectTeam>();
            appLikes= new List<AppLike>();
            appEvaluations = new List<AppEvaluationDetail>();
            AppParameters = new List<AppParameter>();
        }

        public List<AppInnovationBenefit> appInnovationBenefits { get; set; }

        public AppInnovation AppInnovation { get; set; }    

        public List<AppProjectTeam> appProjectTeams { get; set; }
		public List<AppLike> appLikes { get; set; }

        public List<AppParameter> AppParameters { get; set; }

		public Guid? Id { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string? PersonalNo { get; set; }
        public string? Name { get; set; }
        public string? Department { get; set; }
        public string? Designation { get; set; }
        public string? EmailId { get; set; }
        public long? Mobile { get; set; }
        public string? Innovation { get; set; }
        public string? Description { get; set; }
		public string? OtherBenefit { get; set; }
		public string? StageOfInnovation { get; set; }
		public string? SourceOfInnovation { get; set; }
		public string? Attachment { get; set; }
		public int? Views { get; set; }

		public string? DareToTry { get; set; }
		public IEnumerable<IFormFile>? Attach { get; set; }
        public string? Status { get; set; }
        public string? RefNo { get; set; }
        public string? ApproverRemarks { get; set; }
        public string? ApproverAttach { get; set; }
		public IEnumerable<IFormFile>? ApproverAttachment { get; set; }
		public string? ApprovedBy { get; set; }
        public DateTime? ApprovedOn { get; set; }
        public string? SubmitFlag { get; set; }

        //Innovation Benefits

        public Guid BenefitId { get; set; }
        public Guid MasterId { get; set; }
        public string? Benefits { get; set; }
        //team
        public Guid TeamId { get; set; }
        public Guid TeamMasterId { get; set; }
        public string? Pno { get; set; }
		public string? EmployeeName { get; set; }
		public long? Contact { get; set; }

        //Like
		public string? LikePno { get; set; }
		public string? InnovationId { get; set; }
		public int? TotalLikes { get; set; }

		//comment
		public string? Comments { get; set; }
		public string? CommentBy { get; set; }

        //Evaluation Details
        public string? ParameterCode { get; set; }
        public int? Sc2 { get; set; }
        public int? Sc4 { get; set; }
        public int? Sc6 { get; set; }
        public int? Sc8 { get; set; }
        public int? Sc10 { get; set; }
		public decimal? Score { get; set; }
		public List<AppEvaluationDetail> appEvaluations { get; set; }


		
		public string? ParameterDesc { get; set; }
		public int? Weightage { get; set; }

	}
}
