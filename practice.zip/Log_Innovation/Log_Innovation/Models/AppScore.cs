﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class AppScore
    {
        public Guid Id { get; set; }
        public string? ScoreCode { get; set; }
        public string? ScoreDesc { get; set; }
    }
}
