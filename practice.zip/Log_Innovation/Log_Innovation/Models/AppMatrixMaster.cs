﻿using System;
using System.Collections.Generic;

namespace Log_Innovation.Models
{
    public partial class AppMatrixMaster
    {
        public Guid Id { get; set; }
        public string? ParameterCode { get; set; }
        public int? ScoreCode { get; set; }
        public string? MatrixDesc { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
    }
}
