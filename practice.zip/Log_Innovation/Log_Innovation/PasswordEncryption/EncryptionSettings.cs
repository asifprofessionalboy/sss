﻿namespace Log_Innovation.PasswordEncryption
{
    public class EncryptionSettings
    {
        public string EncryptionKey { get; set; }
    }
}
