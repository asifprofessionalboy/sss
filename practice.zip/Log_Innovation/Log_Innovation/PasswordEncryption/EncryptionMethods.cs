﻿using Microsoft.Extensions.Options;
using System.Security.Cryptography;
using System.Text;

namespace Log_Innovation.PasswordEncryption
{

    public class EncryptionMethods
    {
        private readonly string _encryptionKey;

        public EncryptionMethods(IOptions<EncryptionSettings> encryptionSettings)
        {
            _encryptionKey = encryptionSettings.Value.EncryptionKey;
        }

        public string EncryptPassword(string password)
        {
            using (var aes = Aes.Create())
            {
                var key = Convert.FromBase64String(_encryptionKey);
                aes.Key = key;
                aes.IV = new byte[aes.BlockSize / 8]; // Initialization vector

                using (var encryptor = aes.CreateEncryptor())
                {
                    var bytes = Encoding.UTF8.GetBytes(password);
                    return Convert.ToBase64String(encryptor.TransformFinalBlock(bytes, 0, bytes.Length));
                }
            }
        }

        public string DecryptPassword(string encryptedPassword)
        {
            using (var aes = Aes.Create())
            {
                var key = Convert.FromBase64String(_encryptionKey);
                aes.Key = key;
                aes.IV = new byte[aes.BlockSize / 8]; // Initialization vector

                using (var decryptor = aes.CreateDecryptor())
                {
                    var bytes = Convert.FromBase64String(encryptedPassword);
                    return Encoding.UTF8.GetString(decryptor.TransformFinalBlock(bytes, 0, bytes.Length));
                }
            }
        }

    }
}
    
