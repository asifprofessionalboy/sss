﻿using System.Security.Cryptography;

namespace Log_Innovation.PasswordEncryption
{
    public class EncryptionKeyGenerator
    {
        public static string GenerateEncryptionKey(int keySize = 32) // 32 bytes = 256 bits
        {
            using (var rng = new RNGCryptoServiceProvider())
            {
                var key = new byte[keySize];
                rng.GetBytes(key);
                return Convert.ToBase64String(key);
            }
        }

    }
}
