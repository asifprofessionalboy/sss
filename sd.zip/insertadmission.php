<?php
$conn = mysqli_connect("localhost","a1689dbo_kttc_user","user@321#$", "a1689dbo_kttc");

// Check connection
if ($conn === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
}


if (isset($_POST['submit'])) {
    // Check if any of the fields are empty
    if (empty($_POST['name']) || empty($_POST['fname']) || empty($_POST['mname']) || empty($_POST['dob']) || empty($_POST['gender']) || empty($_POST['present_address']) || empty($_POST['permanent_address']) || empty($_POST['religion']) || empty($_POST['nationality']) || empty($_POST['mob']) || empty($_POST['email']) || empty($_POST['nid']) || empty($_POST['blood']) || empty($_POST['occupation']) || empty($_POST['status']) || empty($_POST['course'])) {
        echo '<script>alert("Error: All fields are required."); window.location.href="Admission.php"</script>';
    } else {
        // Validate mobile number
        $mob = mysqli_real_escape_string($conn, $_POST['mob']);
        if (!preg_match("/^\d{10}$/", $mob)) {
            echo '<script>alert("Error: Mobile number must be 10 digits."); window.location.href="Admission.php"</script>';
            exit;
        }

        // Check if mobile number already exists
        $query = "SELECT * FROM admission WHERE mob = '$mob'";
        $result = mysqli_query($conn, $query);
        if (mysqli_num_rows($result) > 0) {
            echo '<script>alert("Error: Mobile number already registered."); window.location.href="Admission.php"</script>';
            exit;
        }

        // Handle photo upload
        $filename = $_FILES['photo']['name'];
        $filepath = $_FILES['photo']['tmp_name'];
        $fileerror = $_FILES['photo']['error'];

        if ($fileerror === 0) {
            $destination = 'student/' . $filename;
            if (move_uploaded_file($filepath, $destination)) {
                // Taking all values from the form data(input)
                $name = mysqli_real_escape_string($conn, $_POST['name']);
                $fname = mysqli_real_escape_string($conn, $_POST['fname']);
                $mname = mysqli_real_escape_string($conn, $_POST['mname']);
                $dob = mysqli_real_escape_string($conn, $_POST['dob']);
                $gender = mysqli_real_escape_string($conn, $_POST['gender']);
                $present_address = mysqli_real_escape_string($conn, $_POST['present_address']);
                $permanent_address = mysqli_real_escape_string($conn, $_POST['permanent_address']);
                $religion = mysqli_real_escape_string($conn, $_POST['religion']);
                $nationality = mysqli_real_escape_string($conn, $_POST['nationality']);
                $email = mysqli_real_escape_string($conn, $_POST['email']);
                $nid = mysqli_real_escape_string($conn, $_POST['nid']);
                $blood = mysqli_real_escape_string($conn, $_POST['blood']);
                $occupation = mysqli_real_escape_string($conn, $_POST['occupation']);
                $status = mysqli_real_escape_string($conn, $_POST['status']);
                $course = mysqli_real_escape_string($conn, $_POST['course']);

                // Insert data into the database
                $sql = "INSERT INTO admission(name, fname, mname, dob, gender, present_address, permanent_address, religion, nationality, mob, email, nid, blood, occupation, status, course, pic) VALUES ('$name','$fname','$mname','$dob','$gender','$present_address','$permanent_address','$religion','$nationality','$mob','$email','$nid','$blood','$occupation','$status','$course','$destination')";
                if (mysqli_query($conn, $sql)) {
                    echo '<script>alert("Form submitted successfully."); window.location.href="Admission.php"</script>';
                } else {
                    echo '<script>alert("Unable to submit form."); window.location.href="Admission.php"</script>';
                }
            } else {
                echo '<script>alert("Error uploading photo."); window.location.href="Admission.php"</script>';
            }
        } else {
            echo '<script>alert("Error in file upload."); window.location.href="Admission.php"</script>';
        }
    }
}


// Close connection
mysqli_close($conn);
?>