
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
   
    <meta name="robots" content="noindex, follow" />
   <title>Testimonials | 09334617411 | Rashtrita Technical Institute Jamshedpur, India</title>
    <meta name="description" content="Testimonials of Rashtrita Technical Institute Jamshedpur, India, Some of Valuable feedback of RTIJSR Students" />
    <meta name="keywords" content="Testimonials Rashtrita Technical Institute Jamshedpur, India, Some of Valuable feedback of RTIJSR Students" />
   
    <link rel="canonical" href="https://rtijsr.in/testimonial.php" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">

    <!-- CSS
    ============================================ -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/slick.css">
    <link rel="stylesheet" href="assets/css/vendor/slick-theme.css">
    <link rel="stylesheet" href="assets/css/plugins/sal.css">
    <link rel="stylesheet" href="assets/css/plugins/feather.css">
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/plugins/euclid-circulara.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper.css">
    <link rel="stylesheet" href="assets/css/plugins/odometer.css">
    <link rel="stylesheet" href="assets/css/plugins/animation.css">
    <link rel="stylesheet" href="assets/css/plugins/bootstrap-select.min.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/plugins/magnigy-popup.min.css">
    <link rel="stylesheet" href="assets/css/plugins/plyr.css">
    <link rel="stylesheet" href="assets/css/plugins/jodit.min.css" />

    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body class="rbt-header-sticky active-light-mode">

<?php include 'header.php' ?>




   <!-- Start testimonial  -->
    <div class="rbt-testimonial-area bg-color-white  rbt-section-gap">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 mb--60">
                    <div class="section-title text-center">
                        <h2 class="title">Student's Feedback</h2>
                        <p class="description mt--20">Some Valuable Reviews from our Students.</p>
                    </div>
                </div>
            </div>
            <div
                class="testimonial-item-3-activation swiper rbt-arrow-between gutter-swiper-30 swiper-initialized swiper-horizontal swiper-pointer-events swiper-backface-hidden">
                <div class="swiper-wrapper" id="swiper-wrapper-10a33b3de5a5d6958" aria-live="polite"
                    style="transform: translate3d(0px, 0px, 0px); transition-duration: 0ms;">

                    <!-- Start Single Testimonial  -->
                    <div class="swiper-slide swiper-slide-active" style="width: 445px;" role="group" aria-label="1 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title"> Abdul Majid Ansari</h5>
                                            <span>Bhubaneshwar, Odisha</span>
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                 
                                        A great experience with the institute and great placement and full support of teachers and all stuff.
                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->
                    <!-- Start Single Testimonial  -->
                    <div class="swiper-slide swiper-slide-next" style="width: 445px;" role="group" aria-label="2 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Shaz ibrahim</h5>
                                            <span> <i> Raipur, Chhatisgarh</i></span>
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                                      The instructors at Rashtriya Institute went above and beyond to ensure we understood the concepts and could apply them.
                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->
                    <!-- Start Single Testimonial  -->
                    <div class="swiper-slide" style="width: 445px;" role="group" aria-label="3 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Shahbaz Haque</h5>
                                            <span>Gorakhpur, Uttar Pradesh</span>
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                                        Institute having good infrastructure... faculties are having good pratical exposure..
                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->
                    <!-- Start Single Testimonial  -->
                    <div class="swiper-slide" style="width: 445px;" role="group" aria-label="4 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Danish Ahmed</h5>
                                            <span> Varanasi, Uttar Pradesh</span>
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                                        Best techinical institute i have come across so far over all perfection in training, highly qualified trainer and well built infrastructure, proud student of rti..
                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide" style="width: 445px;" role="group" aria-label="4 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">GULAB RASUL</h5>
                                            <span> Bihar</span>
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                                        I completed MCO training from RTI and I suggest everyone to join RTI for this training.


                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide" style="width: 445px;" role="group" aria-label="4 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">MOHAMMAD SAHID RAJA</h5>
                                            <span>Chennai</span>
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                                        I enjoyed this training journey in every fiel like classes, practical, office staff. 👍.
                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide" style="width: 445px;" role="group" aria-label="4 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Danish Ahmed</h5>
                                            
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                                        Rashtriya Technical Institute's operating course provided me with the skills I needed to excel in my job. 
                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide" style="width: 445px;" role="group" aria-label="4 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Shaz ibrahim</h5>
                                            
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                                        I highly recommend the operating course at Rashtriya Technical Institute.
                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                  
                    <!-- End Single Testimonial  -->
                  
                </div>

                <div class="rbt-swiper-arrow rbt-arrow-left" tabindex="0" role="button" aria-label="Next slide"
                    aria-controls="swiper-wrapper-10a33b3de5a5d6958" aria-disabled="false">
                    <div class="custom-overfolow">
                        <i class="rbt-icon feather-arrow-left"></i>
                        <i class="rbt-icon-top feather-arrow-left"></i>
                    </div>
                </div>

                <div class="rbt-swiper-arrow rbt-arrow-right swiper-button-disabled" tabindex="-1" role="button"
                    aria-label="Previous slide" aria-controls="swiper-wrapper-10a33b3de5a5d6958" aria-disabled="true">
                    <div class="custom-overfolow">
                        <i class="rbt-icon feather-arrow-right"></i>
                        <i class="rbt-icon-top feather-arrow-right"></i>
                    </div>
                </div>
                <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
            </div>
        </div>
        <br />
    </div>

    <!-- End testimonial  -->



    <?php include 'footer.php' ?>
    <!-- JS
    ============================================ -->
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr.min.js"></script>
    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.min.js"></script>
    <!-- sal.js -->
    <script src="assets/js/vendor/sal.js"></script>
    <!-- Dark Mode Switcher -->
    <script src="assets/js/vendor/js.cookie.js"></script>
    <script src="assets/js/vendor/jquery.style.switcher.js"></script>
    <script src="assets/js/vendor/swiper.js"></script>
    <script src="assets/js/vendor/jquery-appear.js"></script>
    <script src="assets/js/vendor/odometer.js"></script>
    <script src="assets/js/vendor/backtotop.js"></script>
    <script src="assets/js/vendor/isotop.js"></script>
    <script src="assets/js/vendor/imageloaded.js"></script>

    <script src="assets/js/vendor/wow.js"></script>
    <script src="assets/js/vendor/waypoint.min.js"></script>
    <script src="assets/js/vendor/easypie.js"></script>
    <script src="assets/js/vendor/text-type.js"></script>
    <script src="assets/js/vendor/jquery-one-page-nav.js"></script>
    <script src="assets/js/vendor/bootstrap-select.min.js"></script>
    <script src="assets/js/vendor/jquery-ui.js"></script>
    <script src="assets/js/vendor/magnify-popup.min.js"></script>
    <script src="assets/js/vendor/paralax-scroll.js"></script>
    <script src="assets/js/vendor/paralax.min.js"></script>
    <script src="assets/js/vendor/countdown.js"></script>
    <script src="assets/js/vendor/plyr.js"></script>
    <script src="assets/js/vendor/jodit.min.js"></script>
    <script src="assets/js/vendor/Sortable.min.js"></script>



    <!-- Main JS -->
    <script src="assets/js/main.js"></script>



</body>

</html>