
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Placement  Testimonial</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">

    <!-- CSS
    ============================================ -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/slick.css">
    <link rel="stylesheet" href="assets/css/vendor/slick-theme.css">
    <link rel="stylesheet" href="assets/css/plugins/sal.css">
    <link rel="stylesheet" href="assets/css/plugins/feather.css">
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/plugins/euclid-circulara.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper.css">
    <link rel="stylesheet" href="assets/css/plugins/odometer.css">
    <link rel="stylesheet" href="assets/css/plugins/animation.css">
    <link rel="stylesheet" href="assets/css/plugins/bootstrap-select.min.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/plugins/magnigy-popup.min.css">
    <link rel="stylesheet" href="assets/css/plugins/plyr.css">
    <link rel="stylesheet" href="assets/css/plugins/jodit.min.css" />

    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body class="rbt-header-sticky">

<?php include 'header.php' ?>







    <div class="rbt-gallery container">

            <div class="row">
                <div class="col-lg-12 mt--30">
                    <div class="section-title text-center">
                        <h1 class="title">Placement  Testimonial </h1>
                        <p class="description mt--20 mb--30">View Our Institute Placement Testimonial </p>
                    </div>
                </div>
            </div>
     
            <div class="row parent-gallery-container">

<a href="https://www.youtube.com/embed/cJsM85IjwYc?si=ZhKUSRWXBWzghABo"
        class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
        <div class="rbt-gallery">
            <iframe src="https://www.youtube.com/embed/cJsM85IjwYc?si=ZhKUSRWXBWzghABo" title="YouTube video player"
                style="width:100%!important; height:270px!important"></iframe>
        </div>
    </a>

    <a href="https://www.youtube.com/embed/nP17g0i1q_o?si=TWtzZaxBQ5Z6DBrq"
        class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
        <div class="rbt-gallery">
            <iframe src="https://www.youtube.com/embed/nP17g0i1q_o?si=TWtzZaxBQ5Z6DBrq" title="YouTube video player"
                style="width:100%!important; height:270px!important"></iframe>
        </div>
    </a>
   

    <a href="https://www.youtube.com/embed/Cz6unga0Qec?si=4hPOtOTu_5F-g8DS"
        class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
        <div class="rbt-gallery">
            <iframe src="https://www.youtube.com/embed/Cz6unga0Qec?si=4hPOtOTu_5F-g8DS" title="YouTube video player"
                style="width:100%!important; height:270px!important"></iframe>
        </div>
    </a>
    <a href="https://www.youtube.com/embed/nHJMM62xA6s?si=FVAQNM55SH_zg8Ap"
        class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
        <div class="rbt-gallery">
            <iframe src="https://www.youtube.com/embed/nHJMM62xA6s?si=FVAQNM55SH_zg8Ap" title="YouTube video player"
                style="width:100%!important; height:270px!important"></iframe>
        </div>
    </a>


</div>
<div class="row parent-gallery-container">

<a href="https://www.youtube.com/embed/yZ5eMrZkIF4?si=HzovyY8UeClDc3Uq"
class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
<div class="rbt-gallery">
    <iframe src="https://www.youtube.com/embed/yZ5eMrZkIF4?si=HzovyY8UeClDc3Uq" title="YouTube video player"
        style="width:100%!important; height:270px!important"></iframe>
</div>
</a>

<a href="https://www.youtube.com/embed/MJht30fRcQ0?si=YnUBUMVbPJ10T_Py"
class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
<div class="rbt-gallery">
    <iframe src="https://www.youtube.com/embed/MJht30fRcQ0?si=YnUBUMVbPJ10T_Py" title="YouTube video player"
        style="width:100%!important; height:270px!important"></iframe>
</div>
</a>


<a href="https://www.youtube.com/embed/_4uGDuGWb9g?si=BLwd5FbWFIKltPZD"
class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
<div class="rbt-gallery">
    <iframe src="https://www.youtube.com/embed/_4uGDuGWb9g?si=BLwd5FbWFIKltPZD" title="YouTube video player"
        style="width:100%!important; height:270px!important"></iframe>
</div>
</a>
<a href="https://www.youtube.com/embed/9_xJyj9n5Aw?si=5BLszcZt0Eg3K_4v"
class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
<div class="rbt-gallery">
    <iframe src="https://www.youtube.com/embed/9_xJyj9n5Aw?si=5BLszcZt0Eg3K_4v" title="YouTube video player"
        style="width:100%!important; height:270px!important"></iframe>
</div>
</a>


</div>


        <br />

   
    </div>



    <?php include 'footer.php' ?>


    <!-- JS
    ============================================ -->
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr.min.js"></script>
    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.min.js"></script>
    <!-- sal.js -->
    <script src="assets/js/vendor/sal.js"></script>
    <!-- Dark Mode Switcher -->
    <script src="assets/js/vendor/js.cookie.js"></script>
    <script src="assets/js/vendor/jquery.style.switcher.js"></script>
    <script src="assets/js/vendor/swiper.js"></script>
    <script src="assets/js/vendor/jquery-appear.js"></script>
    <script src="assets/js/vendor/odometer.js"></script>
    <script src="assets/js/vendor/backtotop.js"></script>
    <script src="assets/js/vendor/isotop.js"></script>
    <script src="assets/js/vendor/imageloaded.js"></script>

    <script src="assets/js/vendor/wow.js"></script>
    <script src="assets/js/vendor/waypoint.min.js"></script>
    <script src="assets/js/vendor/easypie.js"></script>
    <script src="assets/js/vendor/text-type.js"></script>
    <script src="assets/js/vendor/jquery-one-page-nav.js"></script>
    <script src="assets/js/vendor/bootstrap-select.min.js"></script>
    <script src="assets/js/vendor/jquery-ui.js"></script>
    <script src="assets/js/vendor/magnify-popup.min.js"></script>
    <script src="assets/js/vendor/paralax-scroll.js"></script>
    <script src="assets/js/vendor/paralax.min.js"></script>
    <script src="assets/js/vendor/countdown.js"></script>
    <script src="assets/js/vendor/plyr.js"></script>
    <script src="assets/js/vendor/jodit.min.js"></script>
    <script src="assets/js/vendor/Sortable.min.js"></script>



    <!-- Main JS -->
    <script src="assets/js/main.js"></script>
</body>

</html>