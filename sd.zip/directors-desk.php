
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Director's Desk'</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">

    <!-- CSS
	============================================ -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/slick.css">
    <link rel="stylesheet" href="assets/css/vendor/slick-theme.css">
    <link rel="stylesheet" href="assets/css/plugins/sal.css">
    <link rel="stylesheet" href="assets/css/plugins/feather.css">
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/plugins/euclid-circulara.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper.css">
    <link rel="stylesheet" href="assets/css/plugins/odometer.css">
    <link rel="stylesheet" href="assets/css/plugins/animation.css">
    <link rel="stylesheet" href="assets/css/plugins/bootstrap-select.min.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/plugins/magnigy-popup.min.css">
    <link rel="stylesheet" href="assets/css/plugins/plyr.css">
    <link rel="stylesheet" href="assets/css/plugins/jodit.min.css" />

    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body class="rbt-header-sticky">


  <?php include 'header.php' ?>



    <div class="rbt-team-area bg-color-white rbt-section-gapBottom">
        <div class="container">
            <div class="row mb--60">
                <div class="col-lg-12">
                    <div class="section-title text-center">


                    </div>
                </div>
            </div>
            <div class="row g-5">

                <div class="col-lg-12">
                    <!-- Start Tab Content  -->
                    <div class="rbt-team-tab-content tab-content" id="myTabContent">
                        <div class="tab-pane fade active show" id="team-tab1" role="tabpanel" aria-labelledby="team-tab1-tab">
                            <div class="inner">
                                <div class="rbt-team-thumbnail">
                                    <div class="thumb">
                                        <img src="assets/images/team/director.jpeg" alt="Testimonial Images">
                                    </div>
                                </div>
                                <div class="rbt-team-details">
                                    <div class="author-info">
                                        <h4 class="title">SHAKIL ASLAM</h4>
                                        <span class="designation theme-gradient">Director</span>
                                        <span class="team-form">
                                            <i class="feather-map-pin"></i>
                                            <span class="location">Rastriya Technical Institute</span>
                                        </span>
                                    </div>
                                    <p>My honourable father Late Shamim Aslam used to say until and unless the general mass of India is educated with the technical knowhow, the talk of Developed India dream will remain unfulfilled. The country's development is directly proportional to the technology introduced or invented and that will come through only by its devoted people. The world is on the way of phenomenal metamorphosis in all the technological aspects. India too as a nation feeling the same. But despite of producing one of the largest technical manpower in the world, all the personnel are not able to get the job due to lack of practical knowledge. So these people need a job oriented course.</p>
                                    <p>Rashtriya Technical Institute (RTI) has taken up the challenge for the development of the skilled workforce in an era of rapid economic and technological changes by imparting the intensive training in various branches of technical courses. RTI has designed various job oriented short-term courses keeping in mind the qualification and ability of students. So that they can consume the opportunity in the industrializing global market.</p>

                                </div>
                            </div>
                        </div>



                        <div class="top-circle-shape"></div>
                    </div>
                    <!-- End Tab Content  -->
                </div>

            </div>
        </div>
    </div>






    <!-- <div class="rbt-team-area bg-color-white rbt-section-gapBottom">
        <div class="container">
            <div class="row mb--60">
                <div class="col-lg-12">
                    <div class="section-title text-center">

                    </div>
                </div>
            </div>
            <div class="row ">

                <div class="col-lg-12 col-md-9 col-12 mt--30">
                    <div class="rbt-team team-style-default rbt-hover-02">
                        <div class="inner">
                            <div class="thumbnail">
                                <img src="assets/images/team/director.jpeg" alt="Corporate Template">
                            </div>
                            <div class="content">
                                <h2 class="title">SHAKIL ASLAM</h2>
                                <h6 class="subtitle theme-gradient">Director</h6>
                                <span class="team-form">
                                    <i class="feather-map-pin"></i>
                                    <span class="location">Rastriya Technical Institute</span>
                                </span>



                                <p class="description">
                                    My honourable father Late Shamim Aslam used to say until and unless
                                    the general mass of India is educated with the technical knowhow, the talk of Developed India
                                    dream will remain unfulfilled. The country's development is directly proportional to the technology introduced or
                                    invented and that will come through only by its devoted people. The world is on the way of phenomenal metamorphosis in
                                    all the technological aspects. India too as a nation feeling the same. But despite of producing one of
                                    the largest technical manpower in the world, all the personnel are not able to get the job due to lack of practical
                                    knowledge. So these people need a job oriented course.<br />
                                    Rashtriya Technical Institute (RTI) has taken up the challenge for the development of the skilled workforce in an era of rapid economic and technological changes by imparting the intensive training in various branches of technical courses. RTI has designed various job oriented short-term courses keeping in mind the qualification and ability of students. So that they can consume the opportunity in the industrializing global market
                                </p>

                                <ul class="social-icon social-default icon-naked mt--20">
                                    <li>
                                        <a href="https://www.facebook.com/">
                                            <i class="feather-facebook"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.twitter.com">
                                            <i class="feather-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.instagram.com/">
                                            <i class="feather-instagram"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div> -->





    <?php include 'footer.php' ?>

    <!-- JS
    ============================================ -->
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr.min.js"></script>
    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.min.js"></script>
    <!-- sal.js -->
    <script src="assets/js/vendor/sal.js"></script>
    <!-- Dark Mode Switcher -->
    <script src="assets/js/vendor/js.cookie.js"></script>
    <script src="assets/js/vendor/jquery.style.switcher.js"></script>
    <script src="assets/js/vendor/swiper.js"></script>
    <script src="assets/js/vendor/jquery-appear.js"></script>
    <script src="assets/js/vendor/odometer.js"></script>
    <script src="assets/js/vendor/backtotop.js"></script>
    <script src="assets/js/vendor/isotop.js"></script>
    <script src="assets/js/vendor/imageloaded.js"></script>

    <script src="assets/js/vendor/wow.js"></script>
    <script src="assets/js/vendor/waypoint.min.js"></script>
    <script src="assets/js/vendor/easypie.js"></script>
    <script src="assets/js/vendor/text-type.js"></script>
    <script src="assets/js/vendor/jquery-one-page-nav.js"></script>
    <script src="assets/js/vendor/bootstrap-select.min.js"></script>
    <script src="assets/js/vendor/jquery-ui.js"></script>
    <script src="assets/js/vendor/magnify-popup.min.js"></script>
    <script src="assets/js/vendor/paralax-scroll.js"></script>
    <script src="assets/js/vendor/paralax.min.js"></script>
    <script src="assets/js/vendor/countdown.js"></script>
    <script src="assets/js/vendor/plyr.js"></script>
    <script src="assets/js/vendor/jodit.min.js"></script>
    <script src="assets/js/vendor/Sortable.min.js"></script>



    <!-- Main JS -->
    <script src="assets/js/main.js"></script>
</body>

</html>