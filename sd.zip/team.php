<div class="rbt-team-area rbt-section-gap">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-12 mb--60">
                    <div class="section-title text-center">

                        <h2 class="title">Our Team</h2>

                    </div>
                </div>
            </div>

            <div class="row row--15 mt_dec--30 justify-content-center">

                <div class="col-lg-3 col-md-3 col-6">
                    <div class="rbt-team team-style-default style-two rbt-hover">
                        <div class="inner">
                            <div class="thumbnail"><img src="assets/images/team/1.jfif"
                                    alt="Corporate Template"></div>
                            <div class="content">
                                <h5>Md Akhtar Asdaqui</h5>
                                <h6 class="subtitle theme-gradient">Marketing Head</h6>
                                <span class="team-form">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-6">
                    <div class="rbt-team team-style-default style-two rbt-hover">
                        <div class="inner">
                            <div class="thumbnail"><img src="assets/images/team/2.jfif"
                                    alt="Corporate Template"></div>
                            <div class="content">
                                <h5>Zulfiqar Akhtar</h>
                                <h6 class="subtitle theme-gradient">Operation Manager</h6>
                                <span class="team-form">
                            </div>
                        </div>
                    </div>
                </div>
           

            </div>
        </div>
        <div class="about-btn mt--40 text-center">
            <a class="rbt-btn btn-gradient hover-icon-reverse" href="student-gallery.php">
                <span class="icon-reverse-wrapper">
                    <span class="btn-text">View All</span>
                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                </span>
            </a>
        </div>


      
        <br>
    </div>