<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
   <title>Material management course training | CALL 9334617411 | Jamshedpur Jharkhand, Patna, Bihar, India</title>
    <meta name="description" content="Material management course training institute, Diploma certificate course in Jamshedpur Jharkhand, Bihar, Uttar Pradesh, Odisha, West Bangal, India" />
    <meta name="keywords" content="Material management course training institute school, Diploma certificate course in  Jamshedpur Jharkhand, Bihar, Uttar Pradesh, Odisha, West Bangal, India" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <link rel="canonical" href="https://rtijsr.in/material-management-training.course.php" />
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">

    <!-- CSS
    ============================================ -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/slick.css">
    <link rel="stylesheet" href="assets/css/vendor/slick-theme.css">
    <link rel="stylesheet" href="assets/css/plugins/sal.css">
    <link rel="stylesheet" href="assets/css/plugins/feather.css">
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/plugins/euclid-circulara.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper.css">
    <link rel="stylesheet" href="assets/css/plugins/odometer.css">
    <link rel="stylesheet" href="assets/css/plugins/animation.css">
    <link rel="stylesheet" href="assets/css/plugins/bootstrap-select.min.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/plugins/magnigy-popup.min.css">
    <link rel="stylesheet" href="assets/css/plugins/plyr.css">
    <link rel="stylesheet" href="assets/css/plugins/jodit.min.css" />

    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        @media only screen and (max-width: 767px) {
            ul.testimonial-thumb-wrapper li {
                flex-basis: 47.33%;
                margin-bottom: 14px;
                padding-left: 7px;
                padding-right: 7px;
            }
        }
    </style>

</head>

<body class="active-light-mode">

    <?php include 'header.php' ?>




    <a class="close_side_menu" href="javascript:void(0);"></a>

    <!-- Start breadcrumb Area -->
    <div class="rbt-breadcrumb-default rbt-breadcrumb-style-3">
        <div class="breadcrumb-inner breadcrumb-dark">
            <img src="assets/images/bg/bg-image-10.jpg" alt="Education Images">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="content text-start">

                        <h1 class="title">Material Management Training Course!</h1>
                        <p class="description">
                           <strong>Material Management Course</strong>, मटेरियल मैनेजमेंट का काम सीखे और देश विदेश में नौकरी करे, Learn How to Maintaining and reviewing records of inventory and more. Admission Open.  <strong>मात्र 3 महीने में काम सिखे।</strong>
                        </p>




                        <ul class="plan-offer-list rbt-list-primary-opacity mb-4">
                            <li>
                                <i class="feather-check"></i> 100% Job Assistance
                            </li>
                            <li>
                                <i class="feather-check"></i> नौकरी पाने का सुनहरा अवसर
                            </li>
                            <li>
                                <i class="feather-check"></i> Mess and Hostel Facility
                            </li>


                        </ul>



                        <div class="d-flex align-items-center  flex-wrap rbt-course-details-feature">

                            <div class="feature-sin best-seller-badge">
                                <span class="rbt-badge-2">
                                    <span class="image"><img src="assets/images/course/card-icon-1.png"
                                            alt="Best Seller Icon"></span>100% Placement
                                </span>
                            </div>


                            <div class="feature-sin total-rating">
                                <a class="rbt-badge-4" href="#"><i class="feather-award"></i>Certified Course</a>
                            </div>

                            <div class="feature-sin total-rating">
                                <a class="rbt-badge-4" href="#"><i class="feather-"></i>100% Practical Training</a>
                            </div>

                            <div class="feature-sin rating">
                                <a href="#">4.9</a>
                                <a href="#"><i class="fa fa-star"></i></a>
                                <a href="#"><i class="fa fa-star"></i></a>
                                <a href="#"><i class="fa fa-star"></i></a>
                                <a href="#"><i class="fa fa-star"></i></a>
                                <a href="#"><i class="fa fa-star"></i></a>
                            </div>


                        </div>



                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb Area -->

    <div class="rbt-course-details-area ptb--60">
        <div class="container">
            <div class="row g-5">

                <div class="col-lg-8">
                    <div class="course-details-content">
                        <div class="rbt-course-feature-box rbt-shadow-box thuumbnail">
                        
                        <div class="section-title">
                                    <h4 class="rbt-title-style-3">View Video for Material Management Course !</h4>
                                </div>
                        <iframe class="w-100 h-200" width="100%" height="400" src="https://www.youtube.com/embed/2TS5bqhSXic?si=O18s-OX8hyn3njv1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                        </div>

                        <div class="rbt-inner-onepage-navigation sticky-top mt--30">
                            <nav class="mainmenu-nav onepagenav">
                                <ul class="mainmenu">
                                    <li class="current">
                                        <a href="#overview">Overview</a>
                                    </li>
                                    <li>
                                        <a href="#faq">FAQs</a>
                                    </li>

                                    <li>
                                        <a href="#review">Reviews</a>
                                    </li>

                                    <li>
                                        <a href="#recruiters">Recruiters</a>
                                    </li>

                                </ul>
                            </nav>
                        </div>

                        <!-- Start Overview-->
                        <div class="rbt-course-feature-box overview-wrapper rbt-shadow-box mt--30 has-show-more"
                            id="overview">
                            <div class="rbt-course-feature-inner has-show-more-inner-content">
                                <div class="section-title">
                                    <h4 class="rbt-title-style-3">Material Management Training</h4>
                                </div>
<p>
                                

                                <p>
                                The Material Management Course Training at Rashtriya Institute is designed for individuals seeking to develop the essential skills and knowledge required to effectively manage materials and inventory in various industries. This course provides a comprehensive understanding of material handling, supply chain logistics, procurement, and inventory management, all vital for optimizing operations in today’s fast-paced business environment
                                </p>

                               



                            



                                <div class="section-title">
                                    <h4 class="rbt-title-style-3">Course Objectives</h4>
                                </div>

                                <p>
                                    <font style="color:#3eb75e">▶</font> <b> Introduction to Material Management:</b> 1.Understand the fundamentals of material management, including its importance in the supply chain and its impact on operational efficiency..
                                </p>

                                <p>
                                    <font style="color:#3eb75e">▶</font> <b> Inventory Management Techniques :</b>
                                   Learn various inventory management techniques, such as Just-in-Time (JIT), Economic Order Quantity (EOQ), and ABC analysis to optimize stock levels and reduce carrying costs
                                </p>
                                <p>
                                    <font style="color:#3eb75e">▶</font> <b> Procurement and Supply Chain Management:</b>
                                   3.Explore the procurement process, supplier selection, negotiation techniques, and how to manage supplier relationships effectively.
                                </p>
                                <p>
                                    <font style="color:#3eb75e">▶</font> <b>Material Handling and Storage:</b>
                                   4.Gain insights into efficient material handling practices, storage solutions, and the use of technology in warehouse management.
                                </p>

                                <div class="section-title">
                                    <h4 class="rbt-title-style-3">What Will You Learn<br>
                                        <span class="mt-4" style="font-size:16px"> By the end of this course,
                                            participants will be able to:</span>
                                    </h4>
                                </div>

                                <div class="mb--30" style="margin-left:10px">

                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-12">
                                            <ul class="plan-offer-list">
                                                <li>
                                                    <i class="feather-check"></i> Industry Based
                                                </li>
                                                <li>
                                                    <i class="feather-check"></i> Basic maintenance and daily
                                                    operational checks.
                                                </li>
                                                <li>
                                                    <i class="feather-check"></i>Practical Training
                                                </li>

                                            </ul>
                                        </div>
                                    </div>
                                </div>


                            </div>
                            <div class="rbt-show-more-btn">Show More</div>
                        </div>
                        <!-- End Overview  -->




                        <!-- Start Course FAQ -->
                        <div class="course-content rbt-shadow-box coursecontent-wrapper mt--30" id="faq">
                            <div class="rbt-course-feature-inner">
                                <div class="section-title">
                                    <h4 class="rbt-title-style-3">Our Certification</h4>
                                </div>
                          <p> <font style="color:#3eb75e">➤</font> RTI is registered by<b> Govt of India</b> and An <b>ISO 9001:2015</b> Certified Institute</p>
                            </div>
                        </div>
                        <!-- End Course FAQ  -->



                        <!-- Start Course FAQ -->
                        <div class="course-content rbt-shadow-box coursecontent-wrapper mt--30" id="faq">
                            <div class="rbt-course-feature-inner">
                                <div class="section-title">
                                    <h4 class="rbt-title-style-3">Frequently Asked Questions?</h4>
                                </div>
                                <div class="rbt-accordion-style rbt-accordion-01  accordion">
                                    <div class="accordion" id="accordionExamplea1">

                                        <div class="accordion-item card">
                                            <h2 class="accordion-header card-header" id="headingOne">
                                                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                                    data-bs-target="#collapseOne" aria-expanded="true"
                                                    aria-controls="collapseOne">
                                                   What is the Material Management Course Training at Rashtriya Institute?

                                                </button>
                                            </h2>
                                            <div id="collapseOne" class="accordion-collapse collapse show"
                                                aria-labelledby="headingOne" data-bs-parent="#accordionExamplea1"
                                                style="">
                                                <div class="accordion-body card-body">
                                                    The Material Management Course Training is a specialized program designed to equip participants with the skills and knowledge needed to effectively manage materials and inventory within various industries. The course covers key topics such as supply chain logistics, procurement, inventory management, and cost control.
                                                </div>
                                            </div>
                                        </div>

                                        <div class="accordion-item card">
                                            <h2 class="accordion-header card-header" id="headingTwo">
                                                <button class="accordion-button collapsed" type="button"
                                                    data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                                    aria-expanded="false" aria-controls="collapseTwo">
                                                    What is Material Management course duration?

                                                </button>
                                            </h2>
                                            <div id="collapseTwo" class="accordion-collapse collapse"
                                                aria-labelledby="headingTwo" data-bs-parent="#accordionExamplea1">
                                                <div class="accordion-body card-body">

                                                   The Material management course duration is 3 to 6 Months with flexible scheduling options including weekday and weekend classes to accommodate participants' needs.

                                                </div>
                                            </div>
                                        </div>

                                        <div class="accordion-item card">
                                            <h2 class="accordion-header card-header" id="headingThree">
                                                <button class="accordion-button collapsed" type="button"
                                                    data-bs-toggle="collapse" data-bs-target="#collapseThree"
                                                    aria-expanded="false" aria-controls="collapseThree">
                                                  What career opportunities are available after completing this course?

                                                </button>
                                            </h2>
                                            <div id="collapseThree" class="accordion-collapse collapse"
                                                aria-labelledby="headingThree" data-bs-parent="#accordionExamplea1">
                                                <div class="accordion-body card-body">

                                                    Graduates can pursue various roles, including Material Manager, Inventory Control Specialist, Supply Chain Analyst, and Logistics Coordinator, among others.

                                                </div>
                                            </div>
                                        </div>

                                        <div class="accordion-item card">
                                            <h2 class="accordion-header card-header" id="headingFour">
                                                <button class="accordion-button collapsed" type="button"
                                                    data-bs-toggle="collapse" data-bs-target="#collapseFour"
                                                    aria-expanded="false" aria-controls="collapseFour">
                                                   How can I enroll in the Material Management Course?

                                                </button>
                                            </h2>
                                            <div id="collapseFour" class="accordion-collapse collapse"
                                                aria-labelledby="headingFour" data-bs-parent="#accordionExamplea1"
                                                style="">
                                                <div class="accordion-body card-body">

                                                    Enrollment can be done through the Rashtriya Institute website, by contacting our admissions office, or by visiting our campus. We offer multiple batch options to fit your schedule.

                                                </div>
                                            </div>
                                        </div>



                                        <div class="accordion-item card">
                                            <h2 class="accordion-header card-header" id="headingFive">
                                                <button class="accordion-button collapsed" type="button"
                                                    data-bs-toggle="collapse" data-bs-target="#collapseFive"
                                                    aria-expanded="false" aria-controls="collapseFive">
                                                 What topics are covered in the course?

                                                </button>
                                            </h2>
                                            <div id="collapseFive" class="accordion-collapse collapse"
                                                aria-labelledby="headingFive" data-bs-parent="#accordionExamplea1"
                                                style="">
                                                <div class="accordion-body card-body">

                                                    <ul class="plan-offer-list">
                                                        <li>
                                                            <i class="feather-check"></i> Fundamentals of material management
                                                        </li>
                                                        <li>
                                                            <i class="feather-check"></i> Inventory management techniques
                                                        </li>
                                                        <li>
                                                            <i class="feather-check"></i> Procurement processes and supplier management

                                                        </li>


                                                        <li>
                                                            <i class="feather-check"></i> Material handling and storage solutions

                                                        </li>


                                                        <li>
                                                            <i class="feather-check"></i> Cost control and budgeting strategies

                                                        </li>

                                                    </ul>

                                                </div>
                                            </div>
                                        </div>



                                     








                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Course FAQ  -->





                     
                        <!-- Start review  -->
                        <div class="about-author-list rbt-shadow-box featured-wrapper mt--30 has-show-more" id="review">
                            <div class="section-title">
                                <h4 class="rbt-title-style-3">Our Students Reviews</h4>
                            </div>
                            <div class="has-show-more-inner-content rbt-featured-review-list-wrapper">
                                <div class="rbt-course-review about-author">
                                    <div class="media">
                                        <div class="thumbnail">
                                            <a href="#">
                                                <img src="assets/images/testimonial/user.png" alt="Author Images">
                                            </a>
                                        </div>
                                        <div class="media-body">
                                            <div class="author-info">
                                                <h5 class="title">
                                                    <a class="hover-flip-item-wrapper" href="#">
                                                    Kamlesh Sharma
                                                    </a>
                                                </h5>
                                                <div class="rating">
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                </div>
                                            </div>
                                            <div class="content">
                                                <p class="description">
                                                The Material Management Course at Rashtriya Institute was a game-changer for my career. The hands-on training and real-world case studies gave me practical skills that I could apply immediately at my job. The instructors were incredibly knowledgeable and supportive, making the learning experience both engaging and valuable. I feel much more confident in my abilities to manage materials and inventory effectively!
                                                </p>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                              

                            </div>



                            <div class="has-show-more-inner-content rbt-featured-review-list-wrapper mt-4">
                                <div class="rbt-course-review about-author">
                                    <div class="media">
                                        <div class="thumbnail">
                                            <a href="#">
                                                <img src="assets/images/testimonial/user.png" alt="Author Images">
                                            </a>
                                        </div>
                                        <div class="media-body">
                                            <div class="author-info">
                                                <h5 class="title">
                                                    <a class="hover-flip-item-wrapper" href="#">
                                                    Amit Desai
                                                    </a>
                                                </h5>
                                                <div class="rating">
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                </div>
                                            </div>
                                            <div class="content">
                                                <p class="description">
                                             The training I received at Rashtriya Institute was exceptional. The instructors were industry experts who shared valuable insights and best practices. The course not only equipped me with theoretical knowledge but also emphasized practical application, which is crucial in material management. I highly recommend this course to anyone looking to strengthen their skills in supply chain and logistics!
                                                </p>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                              

                            </div>

                           


                            <div class="has-show-more-inner-content rbt-featured-review-list-wrapper mt-4">
                                <div class="rbt-course-review about-author">
                                    <div class="media">
                                        <div class="thumbnail">
                                            <a href="#">
                                                <img src="assets/images/testimonial/user.png" alt="Author Images">
                                            </a>
                                        </div>
                                        <div class="media-body">
                                            <div class="author-info">
                                                <h5 class="title">
                                                    <a class="hover-flip-item-wrapper" href="#">
                                                    Atul Patel
                                                    </a>
                                                </h5>
                                                <div class="rating">
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                </div>
                                            </div>
                                            <div class="content">
                                                <p class="description">
                                              As someone new to the field, I found the Material Management Course to be incredibly informative and empowering. The course covered everything from inventory management techniques to quality control practices. The supportive environment fostered by the instructors encouraged me to ask questions and engage actively in discussions. I am now better prepared to enter the workforce with confidence.


                                                </p>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                              

                            </div>



                            <div class="has-show-more-inner-content rbt-featured-review-list-wrapper mt-4">
                                <div class="rbt-course-review about-author">
                                    <div class="media">
                                        <div class="thumbnail">
                                            <a href="#">
                                                <img src="assets/images/testimonial/user.png" alt="Author Images">
                                            </a>
                                        </div>
                                        <div class="media-body">
                                            <div class="author-info">
                                                <h5 class="title">
                                                    <a class="hover-flip-item-wrapper" href="#">
                                                    Vikram Sinha
                                                    </a>
                                                </h5>
                                                <div class="rating">
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                </div>
                                            </div>
                                            <div class="content">
                                                <p class="description">
                                             Rashtriya Institute's Material Management Course exceeded my expectations. The blend of theory and hands-on training was perfect for understanding complex concepts. I particularly appreciated the focus on cost control and budgeting, which are crucial skills in my role. Thanks to this course, I've been able to implement new strategies that have improved our procurement processes significantly.


                                                </p>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                              

                            </div>


                            <div class="has-show-more-inner-content rbt-featured-review-list-wrapper mt-4">
                                <div class="rbt-course-review about-author">
                                    <div class="media">
                                        <div class="thumbnail">
                                            <a href="#">
                                                <img src="assets/images/testimonial/user.png" alt="Author Images">
                                            </a>
                                        </div>
                                        <div class="media-body">
                                            <div class="author-info">
                                                <h5 class="title">
                                                    <a class="hover-flip-item-wrapper" href="#">
                                                    Sandeep Singh
                                                    </a>
                                                </h5>
                                                <div class="rating">
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                </div>
                                            </div>
                                            <div class="content">
                                                <p class="description">
"I took the Material Management Course as part of my professional development. The content was up-to-date and relevant, and the instructors were always willing to share their experiences and knowledge. The course has given me the tools I need to succeed in the logistics field, and I am excited to apply what I've learned in my future career




                                                </p>

                                            </div>
                                        </div>
                                    </div>
                                </div>
           
                            </div>
                      


                            


                                               
                            <div class="about-btn mt--40 text-center">
            <a class="rbt-btn btn-gradient hover-icon-reverse" href="testimonial.php">
                <span class="icon-reverse-wrapper">
                    <span class="btn-text">View All</span>
                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                </span>
            </a>
        </div>
                        </div>
                        <!-- End review -->




                        <!-- Start recruit  -->
                        <div class="about-author-list rbt-shadow-box featured-wrapper mt--30 has-show-more"
                            id="recruiters">
                            <div class="section-title">
                                <h4 class="rbt-title-style-3">Our Recruiters</h4>
                            </div>
                            <div class="col-lg-12 mt_md--30 mt_sm--30">
                                <!-- Start Tab Nav  -->
                                <ul class="testimonial-thumb-wrapper nav nav-tabs" id="myTab" role="tablist">
                                    <li>
                                        <a id="testimonial-tab1-tab" data-bs-toggle="tab"
                                            data-bs-target="#testimonial-tab1" role="tab"
                                            aria-controls="testimonial-tab1" aria-selected="false" class="active">
                                            <div class="testimonial-thumbnai">
                                                <div class="thumb">
                                                    <img src="assets/images/partners/aditya.png"
                                                        alt="Testimonial Images">
                                                </div>
                                            </div>
                                        </a>
                                    </li>





                                    <li>
                                        <a id="testimonial-tab2-tab" data-bs-toggle="tab"
                                            data-bs-target="#testimonial-tab2" role="tab"
                                            aria-controls="testimonial-tab2" aria-selected="false" class="active">
                                            <div class="testimonial-thumbnai">
                                                <div class="thumb">
                                                    <img src="assets/images/partners/tata.jpg" alt="Testimonial Images">
                                                </div>
                                            </div>
                                        </a>
                                    </li>

                                    <li>
                                        <a id="testimonial-tab3-tab" data-bs-toggle="tab"
                                            data-bs-target="#testimonial-tab3" role="tab"
                                            aria-controls="testimonial-tab3" aria-selected="false" class="active">
                                            <div class="testimonial-thumbnai">
                                                <div class="thumb">
                                                    <img src="assets/images/partners/lt.png" alt="Testimonial Images">
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a id="testimonial-tab4-tab" data-bs-toggle="tab"
                                            data-bs-target="#testimonial-tab4" role="tab"
                                            aria-controls="testimonial-tab4" aria-selected="true" class="active">
                                            <div class="testimonial-thumbnai">
                                                <div class="thumb">
                                                    <img src="assets/images/partners/voltas.png"
                                                        alt="Testimonial Images">
                                                </div>
                                            </div>
                                        </a>
                                    </li>

                                    <li>
                                        <a id="testimonial-tab5-tab" data-bs-toggle="tab"
                                            data-bs-target="#testimonial-tab5" role="tab"
                                            aria-controls="testimonial-tab5" aria-selected="false" class="active">
                                            <div class="testimonial-thumbnai">
                                                <div class="thumb">
                                                    <img src="assets/images/partners/qatar.png"
                                                        alt="Testimonial Images">
                                                </div>
                                            </div>
                                        </a>
                                    </li>

                                    <li>
                                        <a id="testimonial-tab6-tab" data-bs-toggle="tab"
                                            data-bs-target="#testimonial-tab6" role="tab"
                                            aria-controls="testimonial-tab6" aria-selected="false" class="active">
                                            <div class="testimonial-thumbnai">
                                                <div class="thumb">
                                                    <img src="assets/images/partners/tata2.jpg"
                                                        alt="Testimonial Images">
                                                </div>
                                            </div>
                                        </a>
                                    </li>

                                    <li>
                                        <a id="testimonial-tab7-tab" data-bs-toggle="tab"
                                            data-bs-target="#testimonial-tab7" role="tab"
                                            aria-controls="testimonial-tab7" aria-selected="false" class="active">
                                            <div class="testimonial-thumbnai">
                                                <div class="thumb">
                                                    <img src="assets/images/partners/usha.jpg" alt="Testimonial Images">
                                                </div>
                                            </div>
                                        </a>
                                    </li>

                                    <li>
                                        <a id="testimonial-tab8-tab" data-bs-toggle="tab"
                                            data-bs-target="#testimonial-tab8" role="tab"
                                            aria-controls="testimonial-tab8" aria-selected="false" class="active">
                                            <div class="testimonial-thumbnai">
                                                <div class="thumb">
                                                    <img src="assets/images/partners/laf.png" alt="Testimonial Images">
                                                </div>
                                            </div>
                                        </a>
                                    </li>


                                    <li>
                                        <a id="testimonial-tab8-tab" data-bs-toggle="tab"
                                            data-bs-target="#testimonial-tab8" role="tab"
                                            aria-controls="testimonial-tab8" aria-selected="false" class="active">
                                            <div class="testimonial-thumbnai">
                                                <div class="thumb">
                                                    <img src="assets/images/partners/iic.jpg" alt="Testimonial Images">
                                                </div>
                                            </div>
                                        </a>
                                    </li>


                                    <li>
                                        <a id="testimonial-tab8-tab" data-bs-toggle="tab"
                                            data-bs-target="#testimonial-tab8" role="tab"
                                            aria-controls="testimonial-tab8" aria-selected="false" class="active">
                                            <div class="testimonial-thumbnai">
                                                <div class="thumb">
                                                    <img src="assets/images/partners/kk.jpg" alt="Testimonial Images">
                                                </div>
                                            </div>
                                        </a>
                                    </li>


                                    <li>
                                        <a id="testimonial-tab8-tab" data-bs-toggle="tab"
                                            data-bs-target="#testimonial-tab8" role="tab"
                                            aria-controls="testimonial-tab8" aria-selected="false" class="active">
                                            <div class="testimonial-thumbnai">
                                                <div class="thumb">
                                                    <img src="assets/images/partners/redis.png"
                                                        alt="Testimonial Images">
                                                </div>
                                            </div>
                                        </a>
                                    </li>


                                    <li>
                                        <a id="testimonial-tab8-tab" data-bs-toggle="tab"
                                            data-bs-target="#testimonial-tab8" role="tab"
                                            aria-controls="testimonial-tab8" aria-selected="false" class="active">
                                            <div class="testimonial-thumbnai">
                                                <div class="thumb">
                                                    <img src="assets/images/partners/simplex.png"
                                                        alt="Testimonial Images">
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                                <!-- End Tab Content  -->
                            </div>

                        </div>
                        <!-- End recruit -->



                    </div>

                </div>

                <div class="col-lg-4">
                    <div class="course-sidebar sticky-top rbt-shadow-box course-sidebar-top rbt-gradient-border">
                        <div class="inner">

                            <!-- Start Viedo Wrapper  -->
                            <a class="video-popup-with-text video-popup-wrapper text-center popup-video sidebar-video-hidden mb--15"
                                href="https://www.youtube.com/watch?v=2aWNkWLFsHI">
                                <div class="video-content">
                                    <img class="w-100 rbt-radius" src="assets/images/course/mobile-crane.jpg"
                                        alt="Material Management">
                                    <div class="position-to-top">
                                        <span class="rbt-btn rounded-player-2 with-animation">
                                            <span class="play-icon"></span>
                                        </span>
                                    </div>
                               
                                </div>
                            </a>
                            <!-- End Viedo Wrapper  -->

                            <div class="content-item-content">
                                <div
                                    class="rbt-price-wrapper d-flex flex-wrap align-items-center justify-content-between">
                                    <div class="rbt-price">
                                    <span class="current-price">₹23,000</span>
                                    <span class="off-price">₹33,000</span>
                                    </div>
                                    <div class="discount-time">
                                        <span class="rbt-badge color-danger bg-color-danger-opacity"><i
                                                class="feather-clock"></i> 40% Off</span>
                                    </div>
                                </div>



                                <div class="buy-now-btn mt--15">
                                    <a class="rbt-btn btn-border icon-hover w-100 d-block text-center"
                                        data-bs-toggle="modal" data-bs-target="#exampleModal">
                                        <span class="btn-text">Apply Now</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </a>
                                </div>

                                <span class="subtitle">
                                    <i class="feather-rotate-ccw"></i> 100% Job Guarantee
                                </span>


                                <div class="rbt-widget-details has-show-more">
                                    <ul class="has-show-more-inner-content rbt-course-details-list-wrapper">
                                        <li>
                                            <span>Duration</span><span class="rbt-feature-value rbt-badge-5">
                                                2 Months
                                            </span>
                                        </li>

                                        <li>
                                            <span>Language</span><span class="rbt-feature-value rbt-badge-5">Hindi /
                                                English</span>
                                        </li>
                                        <li><span>Certificate</span><span
                                                class="rbt-feature-value rbt-badge-5">Yes</span></li>


                                </div>

                                <div class="social-share-wrapper mt--30 text-center">
                                    <div class="rbt-post-share d-flex align-items-center justify-content-center">
                                        <ul
                                            class="social-icon social-default transparent-with-border justify-content-center">
                                            <li>
                                                <a href="https://www.facebook.com/">
                                                    <i class="feather-facebook"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="https://www.twitter.com">
                                                    <i class="feather-twitter"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="https://www.instagram.com/">
                                                    <i class="feather-instagram"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="https://www.linkdin.com/">
                                                    <i class="feather-linkedin"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                    <hr class="mt--20">
                                    <div class="contact-with-us text-center">
                                        <p>For details about the course</p>
                                        <p class="rbt-badge-2 mt--10 justify-content-center w-100">
                                            <i class="feather-phone mr--5"></i> Call Us: <a href="tel:+919334617411">
                                                <strong>
                                                    +91-9334617411
                                                </strong>
                                            </a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>










    <div class="rbt-related-course-area bg-color-extra2">
        <div class="container">


            <div class="row">
                <div class="col-lg-12 mb--60">
                    <div class="section-title text-center">
                        <br>
                        <h2 class="title">Placed Students</h2>
                        <p class="description mt--20">

                            Admission open, Limited Seats.
                        </p>
                    </div>
                </div>
            </div>


            <div class="row ">




                <div class="rbt-dashboard-table table-responsive mobile-table-750">
                    <table class="rbt-table table table-borderless">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Name</th>
                                <th>Company</th>
                                <th>Trade</th>
                                <th>Place</th>


                            </tr>
                        </thead>
                        <tbody>
                            <tr>

                                <td>
                                    <img src="assets/images/placement/shubhum.png" class="" alt="Product"
                                        style="height:80px;width:80px">
                                </td>
                                <td class="pro-title">
                                    <p class="b3">Shubham</p>
                                </td>
                                <td>
                                    <p class="b3">Daga Power Group pvt ltd</p>
                                </td>
                                <td>
                                    <p class="b3">Safety</p>
                                </td>
                                <td>
                                    <p class="b3"> Indore</p>
                                </td>
                            </tr>

                            <tr>

                                <td>
                                    <img src="assets/images/placement/shahnwazAlam.png" class="" alt="Product"
                                        style="height:80px;width:80px">
                                </td>
                                <td class="pro-title">
                                    <p class="b3">Shahnwaz Alam</p>
                                </td>
                                <td>
                                    <p class="b3">Hajee A.P Bava &amp; Const.</p>
                                </td>
                                <td>
                                    <p class="b3">Safety</p>
                                </td>
                                <td>
                                    <p class="b3"> Hydrabad</p>
                                </td>
                            </tr>
                        </tbody>

                    </table>
                </div>

            </div>
        </div>
        <!-- End placement  -->
        <div class="about-btn mt--40 text-center">
            <a class="rbt-btn btn-gradient hover-icon-reverse" href="placement.php">
                <span class="icon-reverse-wrapper">
                    <span class="btn-text">View All</span>
                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                </span>
            </a>
        </div>
        <br>
    </div>



  
    <?php include 'team.php' ?>


    <?php include 'other-related-courses.php' ?>


    <br>


    <br><br>

    <!-- start image  -->

    <div class="rbt-gallery-area">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-12 mb--60">
                    <div class="section-title text-center">

                        <h2 class="title">Our Gallery</h2>
                        <p class="description mt--20">

                            View Our Institute Gallery and Students Activities
                        </p>
                    </div>
                </div>
            </div>

            <div class="row parent-gallery-container">






                <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="assets/images/gallery/13.jpg" alt="Gallery Images">
                    </div>
                </a>

                <a href="assets/images/gallery/8.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="assets/images/gallery/8.jpg" alt="Gallery Images">
                    </div>
                </a>




                <a href="assets/images/gallery/11.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="assets/images/gallery/11.jpg" alt="Gallery Images">
                    </div>
                </a>

                <a href="assets/images/gallery/15.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="assets/images/gallery/15.jpg" alt="Gallery Images">
                    </div>
                </a>


            </div>

            <div class="about-btn mt--40 text-center">
                <a class="rbt-btn btn-gradient hover-icon-reverse" href="student-gallery.php">
                    <span class="icon-reverse-wrapper">
                        <span class="btn-text">View All</span>
                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                    </span>
                </a>
            </div>


            <br />


        </div>
    </div>
    <!-- end image  -->
    <br>
    <!-- start video  -->
    <div class="rbt-gallery-area bg-color-white">

        <div class="container">
            <div class="row g-5">
                <div class="col-lg-12 mb--60">
                    <div class="section-title text-center">

                        <h2 class="title">Our Videos</h2>
                        <p class="description mt--20">

                        Explore our videos to see how our specialized training programs can transform your career
                        </p>
                    </div>
                </div>
            </div>


            <div class="row parent-gallery-container">

        <a href="https://www.youtube.com/embed/EjubHZAYocI?si=5BMU_omA9DY3xDtQ"
                class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
                <div class="rbt-gallery">
                    <iframe src="https://www.youtube.com/embed/EjubHZAYocI?si=5BMU_omA9DY3xDtQ" title="YouTube video player"
                        style="width:100%!important; height:270px!important"></iframe>
                </div>
            </a>

            <a href="https://www.youtube.com/embed/lnf5VUVWuhc?si=CF1pDWgHnMjXvUfx"
                class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
                <div class="rbt-gallery">
                    <iframe src="https://www.youtube.com/embed/lnf5VUVWuhc?si=CF1pDWgHnMjXvUfx" title="YouTube video player"
                        style="width:100%!important; height:270px!important"></iframe>
                </div>
            </a>
           

            <a href="https://www.youtube.com/embed/UgrxVMhnwh8?si=tTEF51z8vVLZ1Jn9"
                class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
                <div class="rbt-gallery">
                    <iframe src="https://www.youtube.com/embed/UgrxVMhnwh8?si=tTEF51z8vVLZ1Jn9" title="YouTube video player"
                        style="width:100%!important; height:270px!important"></iframe>
                </div>
            </a>
            <a href="https://www.youtube.com/embed/U5XH60ZWBmU?si=QEmsM7toeJJcdSWP"
                class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
                <div class="rbt-gallery">
                    <iframe src="https://www.youtube.com/embed/U5XH60ZWBmU?si=QEmsM7toeJJcdSWP" title="YouTube video player"
                        style="width:100%!important; height:270px!important"></iframe>
                </div>
            </a>
        

        </div>
     



            <div class="about-btn mt--40 text-center">
                <a class="rbt-btn btn-gradient hover-icon-reverse" href="video-gallery.php">
                    <span class="icon-reverse-wrapper">
                        <span class="btn-text">View All</span>
                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                    </span>
                </a>
            </div>



            <br />


        </div>
    </div>
    <!-- end video  -->





    <?php include 'footer.php' ?>





    <!-- JS
    ============================================ -->
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr.min.js"></script>
    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.min.js"></script>
    <!-- sal.js -->
    <script src="assets/js/vendor/sal.js"></script>
    <!-- Dark Mode Switcher -->
    <script src="assets/js/vendor/js.cookie.js"></script>
    <script src="assets/js/vendor/jquery.style.switcher.js"></script>
    <script src="assets/js/vendor/swiper.js"></script>
    <script src="assets/js/vendor/jquery-appear.js"></script>
    <script src="assets/js/vendor/odometer.js"></script>
    <script src="assets/js/vendor/backtotop.js"></script>
    <script src="assets/js/vendor/isotop.js"></script>
    <script src="assets/js/vendor/imageloaded.js"></script>

    <script src="assets/js/vendor/wow.js"></script>
    <script src="assets/js/vendor/waypoint.min.js"></script>
    <script src="assets/js/vendor/easypie.js"></script>
    <script src="assets/js/vendor/text-type.js"></script>
    <script src="assets/js/vendor/jquery-one-page-nav.js"></script>
    <script src="assets/js/vendor/bootstrap-select.min.js"></script>
    <script src="assets/js/vendor/jquery-ui.js"></script>
    <script src="assets/js/vendor/magnify-popup.min.js"></script>
    <script src="assets/js/vendor/paralax-scroll.js"></script>
    <script src="assets/js/vendor/paralax.min.js"></script>
    <script src="assets/js/vendor/countdown.js"></script>
    <script src="assets/js/vendor/plyr.js"></script>
    <script src="assets/js/vendor/jodit.min.js"></script>
    <script src="assets/js/vendor/Sortable.min.js"></script>



    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>

</html>