<div class="rbt-related-course-area bg-color-white mt--40">
        <div class="container">

            <div class="row g-5">
                <div class="col-lg-12 mb--60">
                    <div class="section-title text-center">

                        <h2 class="title">Related Courses</h2>
                        <p class="description mt--20">

                            Rashtriya Technical Institute provides a lot of facilities for all, also provide Mess and
                            Hostel facilities for all the students.
                        </p>
                    </div>
                </div>
            </div>

            <div class="row g-5">
                <!-- Start Single Card  -->
                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="course-details.php">
                                <img src="assets/images/course/pipe.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="pipe-fitter-fabricator-training-course.php">Pipe Fitter Course</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> <b>Duration</b> : 3 Months</li>
                                <li><i class="feather-award"></i> <b>Certified</b> : Yes</li>

                            </ul>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="pipe-fitter-fabricator-training-course.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>



                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="millwright-fitter-training-course.php">
                                <img src="assets/images/course/mill.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="millwright-fitter-training-course.php">Millwright Course</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> <b>Duration</b> : 3 Months</li>
                                <li><i class="feather-award"></i> <b>Certified</b> : Yes</li>

                            </ul>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="millwright-fitter-training-course.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>



                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="material-management-training-course.php">
                                <img src="assets/images/course/material.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="material-management-training-course.php"> Material
                                Management Course</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> <b>Duration</b> : 3 Months</li>
                                <li><i class="feather-award"></i> <b>Certified</b> : Yes</li>

                            </ul>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="material-management-training-course.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>





                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="mechanical-technician-training-course.php">
                                <img src="assets/images/course/mechanical.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="mechanical-technician-training-course.php">Mechanical
                                Technician Course</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> <b>Duration</b> : 3 Months</li>
                                <li><i class="feather-award"></i> <b>Certified</b> : Yes</li>

                            </ul>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="mechanical-technician-training-course.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>





                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="quantity-surveyor-training-course.php">
                                <img src="assets/images/course/quantity.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="quantity-surveyor-training-course.php"> Quantity
                                Surveyor Course</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> <b>Duration</b> : 3 Months</li>
                                <li><i class="feather-award"></i> <b>Certified</b> : Yes</li>

                            </ul>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="quantity-surveyor-training-course.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>




                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="auto-cad-training-course.php">
                                <img src="assets/images/course/auto-cad.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="auto-cad-training-course.php">Auto Draftsman Course</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> <b>Duration</b> : 3 Months</li>
                                <li><i class="feather-award"></i> <b>Certified</b> : Yes</li>

                            </ul>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="auto-cad-training-course.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>





                <!-- End Card Area -->
            </div>

        </div><br>
    </div>