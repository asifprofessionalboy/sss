

<div class="rbt-banner-area rbt-banner-8 variation-02 with-shape" style="background:linear-gradient(270deg, #3b8344 0%, #4367f0 100%)">
        <div class="container">
            <div class="row g-5 align-items-center">
                <div class="col-lg-10 offset-lg-1">
                    <div class="content">
                        <div class="inner text-center">
                         
                            <h2 class="title text-white">Contact us on
                                <span class="header-caption">
                                    <span class="cd-headline clip is-full-width">
                                        <span class="cd-words-wrapper" style="width: 27.2939px; overflow: hidden;">
                                            <b style=" background: linear-gradient(90deg, #f198cd, #c7cbff);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: rgba(255, 255, 255, 0.001);" class="is-visible">WhatsApp</b>
                                            <b style=" background: linear-gradient(90deg, #f198cd, #c7cbff);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: rgba(255, 255, 255, 0.001);" class="is-hidden">Call</b>
                                         
                                        </span>
                                </span>
                                </span>
                            </h2>
                            <p class="description has-medium-font-size mt--20" style="color:#fff">We'll help you to grow your career and growth!
                         
                            </p>
                            <div class="slider-btn rbt-button-group justify-content-center">
                                <a class="rbt-btn btn-gradient hover-icon-reverse" href="tel:+919334617411">
                                    <span class="icon-reverse-wrapper">
                                        <span class="btn-text">Call Us</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                                <a class="rbt-btn hover-icon-reverse btn-white" href="https://api.whatsapp.com/send/?phone=9334617411&text&type=phone_number&app_absent=0" target="_blank">
                                    <span class="icon-reverse-wrapper">
                                        <span class="btn-text">WhatsApp</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="shape-image">
                <img src="assets/images/icons/tree-shape.svg" alt="Shape">
            </div>
        </div>
    </div>
   
   
   
   
   <!-- Start Footer aera -->
    <footer class="rbt-footer footer-style-1 bg-color-white overflow-hidden" style="background-image: url(assets/images/bg/bg-g1.webp); border-top: 1px solid #f1f1f1;">
        <div class="footer-top">
            <div class="container">
                <div class="row g-5">
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="footer-widget">
                            <h5 class="ft-title">Operating Courses</h5>
                            <ul class="ft-link">
                                <li>
                                    <a href="mobile-crane-operator-course.php"> Mobile Crane Operator Course</a>
                                </li>
                                <li>
                                    <a href="jcb-operator-course.php">JCB Operator Course</a>
                                </li>
                                <li>
                                    <a href="excavator-operator-course.php"> Excavator Operator Course</a>
                                </li>
                                <li>
                                    <a href="forklift-operator-course.php">Forklift Operator Course</a>
                                </li>
                                <li>
                                    <a href="tower-crane-operator-course.php">Tower Crane Course</a>
                                </li>

                            </ul>
                        </div>
                    </div>

















                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="footer-widget">
                            <h5 class="ft-title">Welding Courses</h5>
                            <ul class="ft-link">
                            
                            <li><a href="arc-welding-course.php"> Arc Welding Course</a></li>
                                                    <li><a href="argon-welding-course.php"> Argon Welding Course</a>
                                                    </li>
                                                    <li><a href="arc-argon-welding-course.php"> Arc & Argon Welding
                                                            Course</a></li>
                                                    <li><a href="mig-welding-course.php"> Mig Welding Course</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="footer-widget">
                            <h5 class="ft-title">Technical Courses</h5>
                            <ul class="ft-link">
                            <li><a href="hvac-technician-course.php">HVAC Technician Course</a>
                                                    </li>
                                                    <li><a href="instrument-technician-course.php">Instrument Technician
                                                            Course</a></li>
                                                    <li><a href="electrician-course.php">Electrician Course</a></li>
                                                    <li><a href="quality-controller-course.php">Quality Controller
                                                            Course</a></li>
                                                    <li><a href="ndt-level-2-course.php">NDT Level 2 Course</a></li>
                                                  
                                                    <li><a href="land-surveyor-course.php">Land Surveyor Course</a></li>
                                         

                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="footer-widget">
                            <h5 class="ft-title">Other Courses</h5>
                            <ul class="ft-link">
                            <li><a href="pipe-fitter-fabricator-training-course.php"> Pipe Fitter Course</a>
                                        </li>
                                        <li><a href="millwright-fitter-training-course.php"> Millwright Fitter
                                                Course</a></li>
                                        <li><a href="material-management-training-course.php"> Material Management
                                                Course</a></li>
                                        <li><a href="mechanical-technician-training-course.php"> Mechanical Technician
                                                Course</a></li>
                                        <li><a href="quantity-surveyor-training-course.php"> Quantity Surveyor
                                                Course</a></li>
                                        <li><a href="auto-cad-training-course.php"> Auto Draftsman Course</a></li>

                            </ul>

                            <form class="newsletter-form mt--20" action="#">
                                <h6 class="w-600"><a href="tel:+919334617411">Call Us +91-9334617411</a></h6>
                            




                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="rbt-separator-mid">
            <div class="container">
                <hr class="rbt-separator m-0">
            </div>
        </div>
        <!-- Start Copyright Area  -->
        <div class="copyright-area copyright-style-1 ptb--20">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xxl-8 col-xl-8 col-lg-8 col-md-12 col-12">
                        <p class="rbt-link-hover text-center text-lg-start">Copyright © 2024 Rashtriya Technical Institute | All Rights Reserved | Developed By <a href="https://rainbowthemes.net">Anaxco</a></p>
                    </div>
                    <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-12 col-12">
                        <ul class="copyright-link rbt-link-hover justify-content-center justify-content-lg-end mt_sm--10 mt_md--10">
                            <li><a href="privacy-policy.php">Privacy policy</a></li>
                            <li><a href="#">FAQ</a></li>


                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Copyright Area  -->
    </footer>
    <!-- End Footer aera -->



    



    <div class="rbt-progress-parent">
        <svg class="rbt-back-circle svg-inner" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>




    <!-- Apply Now -->
    <div class="rbt-course-action-bottom d-block d-lg-none">
        <div class="container">
            <div class="row align-items-center">

                <div class="col-lg-6 col-md-6 col-6">
                    <div class="course-action-bottom-right rbt-single-group">

                        <div class="rbt-single-list action-btn">


                            <a class="rbt-btn btn-border radius-round-10" data-bs-toggle="modal" data-bs-target="#exampleModal">Enquire Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-6">
                    <div class="course-action-bottom-right rbt-single-group">

                        <div class="rbt-single-list action-btn">
                            <a class="rbt-btn radius-round-10" href="contact.php">Contact Us</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End -->
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header mb-4">
                    <h5 class="modal-title ms-auto" id="exampleModalLabel">Enquire Form</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <div class="account-details-form">
                        <form action="insertcontact.php" method="post">
                            <div class="row g-5">
                                <div class="col-lg-6 col-12">
                                    <input id="namee" name="name" placeholder="Enter Name" type="text">
                                </div>

                                <div class="col-lg-6 col-12">
                                    <input id="mob" name="mob" placeholder="Enter Mobile No." type="text">
                                </div>

                                <div class="col-lg-12 col-12">
                                    <input id="course" name="course" placeholder="Enter Course Name" type="text">
                                </div>


                                <div class="col-lg-12 col-12">
                                    <textarea class="" name="msg" placeholder="Write Message"></textarea>
                                </div>




                                <div class="col-lg-12 col-12">
                                    <button class="rbt-btn btn-gradient icon-hover w-100" name="submit" type="submit">
                                        <span class="btn-text">Submit</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </button>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
