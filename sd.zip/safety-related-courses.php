<div class="rbt-related-course-area bg-color-white mt--40">
        <div class="container">

            <div class="row g-5">
                <div class="col-lg-12 mb--60">
                    <div class="section-title text-center">

                        <h2 class="title">Related Courses</h2>
                        <p class="description mt--20">

                            Rashtriya Technical Institute provides a lot of facilities for all, also provide Mess and
                            Hostel facilities for all the students.
                        </p>
                    </div>
                </div>
            </div>

            <div class="row g-5 justify-content-center">
                <!-- Start Single Card  -->
                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up" data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="course-details.php">
                                <img src="assets/images/course/safety2.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="mobile-crane-operator-course.php">Industrial Safety Course</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> <b>Duration</b> : 3 Months</li>
                                <li><i class="feather-award"></i> <b>Certified</b> : Yes</li>

                            </ul>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="mobile-crane-operator-course.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>






                <!-- End Card Area -->
            </div>

        </div><br>
    </div>