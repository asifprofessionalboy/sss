
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
     <title>Facilities | CALL 9334617411 | Rashtrita Technical Institute Jamshedpur, India</title>
    <meta name="description" content="Facilities Rashtriya Technicial Institute, Best Technical Education Jamshedpur, Jharkhand, India" />
    <meta name="keywords" content="Facilities Rashtriya Technicial Institute, Best Technical Education Jamshedpur, Jharkhand, India" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <link rel="canonical" href="https://rtijsr.in/facilities.php" />
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">

    <!-- CSS
	============================================ -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/slick.css">
    <link rel="stylesheet" href="assets/css/vendor/slick-theme.css">
    <link rel="stylesheet" href="assets/css/plugins/sal.css">
    <link rel="stylesheet" href="assets/css/plugins/feather.css">
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/plugins/euclid-circulara.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper.css">
    <link rel="stylesheet" href="assets/css/plugins/odometer.css">
    <link rel="stylesheet" href="assets/css/plugins/animation.css">
    <link rel="stylesheet" href="assets/css/plugins/bootstrap-select.min.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/plugins/magnigy-popup.min.css">
    <link rel="stylesheet" href="assets/css/plugins/plyr.css">
    <link rel="stylesheet" href="assets/css/plugins/jodit.min.css" />

    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        .plan-offer-list li {
    font-size: 15px;
    margin: 5px;
    text-align: justify;
}
    </style>
</head>

<body class="rbt-header-sticky">

  <?php include 'header.php' ?>

 



    <!-- Start facility  -->

    <div class="rbt-team-area rbt-section-gapBottom">
        <div class="container">
        <div class="row">
                <div class="col-lg-12 mt--30">
                    <div class="section-title text-center">
                        <h1 class="title">Our Facilities</h1>
                        <p class="description mt--20 mb--30">Learning communicate to global world and build a bright future and career development, increase your skill with our histudy.</p>
                    </div>
                </div>
            </div>

            <div class="row g-5 justify-content-center">


<div class="col-lg-3 col-12">
    <div class="rbt-team team-style-default style-three rbt-hover">
        <div class="inner">
            <div class="thumbnail">
                <img src="assets/images/service/lab.jpg" alt="Corporate Template">
            </div>
            <div class="content">

                <h6 class="subtitle theme-gradient"><b>Practical Lab</b> </h6>
                <span class="team-form">

                    <span class="location">

                      <ul class="plan-offer-list rbt-list-primary-opacity">
                        <li><i class="feather-check"></i>HVAC& AC Lab</li>
                        <li><i class="feather-check"></i> Instrument Lab</li>
                        <li><i class="feather-check"></i> 	Welding Lab</li>
                        <li><i class="feather-check"></i> NDT Lab</li>
                        <li><i class="feather-check"></i> 	CAD Lab</li>
                        <li><i class="feather-check"></i> Mechanical Lab</li>
                        <li><i class="feather-check"></i> Electrical Lab</li>
                        <li><i class="feather-check"></i> QC & QA Lab</li>
                        <li><i class="feather-check"></i> PLC & SCADA Lab</li>
                      </ul>
                    </span>
                </span>
            </div>
        </div>
    </div>
</div>


<div class="col-lg-3 col-12">
    <div class="rbt-team team-style-default style-three rbt-hover">
        <div class="inner">
            <div class="thumbnail">
                <img src="assets/images/service/hostel.jpg" alt="Corporate Template">
            </div>
            <div class="content">

                <h6 class="subtitle theme-gradient"><b>Well Infrastructure</b></h6>
                <span class="team-form">

                    <span class="location">
                    <ul class="plan-offer-list rbt-list-primary-opacity">
                        <li><i class="feather-check"></i>	AC Classroom</li>
                        <li><i class="feather-check"></i> Digital Classroom</li>
                        <li><i class="feather-check"></i> 	Own Vehicle</li>
                        <li><i class="feather-check"></i> All Equipment</li>
                        <li><i class="feather-check"></i> 	CAD Lab</li>
                        <li><i class="feather-check"></i> Own Transportation</li>
                        <li><i class="feather-check"></i> Medicals</li>
                     
                      </ul>
                    </span>
                </span>
            </div>
        </div>
    </div>
</div>



<div class="col-lg-3 col-12">
    <div class="rbt-team team-style-default style-three rbt-hover">
        <div class="inner">
            <div class="thumbnail">
                <img src="assets/images/service/career.jpg" alt="Corporate Template">
            </div>
            <div class="content">

                <h6 class="subtitle theme-gradient"><b>Career Development</b></h6>
                <span class="team-form">

                    <span class="location">

                    <ul class="plan-offer-list rbt-list-primary-opacity">
                        <li><i class="feather-check"></i>	Personality Development</li>
                        <li><i class="feather-check"></i> 	Group Discussion
                             </li>
                        <li><i class="feather-check"></i> Interview	Preparation</li>
                        <li><i class="feather-check"></i> Spoken English</li>
                        <li><i class="feather-check"></i> 	Sports functions</li>
                        <li><i class="feather-check"></i> Educational Games</li>
                        <li><i class="feather-check"></i> Industrial Visits</li>
                     
                      </ul>
                    </span>
                </span>
            </div>
        </div>
    </div>
</div>




<div class="col-lg-3 col-12">
    <div class="rbt-team team-style-default style-three rbt-hover">
        <div class="inner">
            <div class="thumbnail">
                <img src="assets/images/service/class.jpg" alt="Corporate Template">
            </div>
            <div class="content">

                <h6 class="subtitle theme-gradient"> <b>Mess & Hostel</b></h6>
                <span class="team-form">
                 
                    <span class="location">

                    Mess and Hostel Facilities for All the students.
                    </span>
                </span>
            </div>
        </div>
    </div>
</div>



</div>

            <div class="about-btn mt--40 text-center">
                <a class="rbt-btn btn-gradient hover-icon-reverse" href="#">
                    <span class="icon-reverse-wrapper">
                        <span class="btn-text">View All</span>
                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                    </span>
                </a>
            </div>
        </div>
    </div>


    <!-- end facility  -->


    <?php include 'footer.php' ?>



    <!-- JS
    ============================================ -->
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr.min.js"></script>
    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.min.js"></script>
    <!-- sal.js -->
    <script src="assets/js/vendor/sal.js"></script>
    <!-- Dark Mode Switcher -->
    <script src="assets/js/vendor/js.cookie.js"></script>
    <script src="assets/js/vendor/jquery.style.switcher.js"></script>
    <script src="assets/js/vendor/swiper.js"></script>
    <script src="assets/js/vendor/jquery-appear.js"></script>
    <script src="assets/js/vendor/odometer.js"></script>
    <script src="assets/js/vendor/backtotop.js"></script>
    <script src="assets/js/vendor/isotop.js"></script>
    <script src="assets/js/vendor/imageloaded.js"></script>

    <script src="assets/js/vendor/wow.js"></script>
    <script src="assets/js/vendor/waypoint.min.js"></script>
    <script src="assets/js/vendor/easypie.js"></script>
    <script src="assets/js/vendor/text-type.js"></script>
    <script src="assets/js/vendor/jquery-one-page-nav.js"></script>
    <script src="assets/js/vendor/bootstrap-select.min.js"></script>
    <script src="assets/js/vendor/jquery-ui.js"></script>
    <script src="assets/js/vendor/magnify-popup.min.js"></script>
    <script src="assets/js/vendor/paralax-scroll.js"></script>
    <script src="assets/js/vendor/paralax.min.js"></script>
    <script src="assets/js/vendor/countdown.js"></script>
    <script src="assets/js/vendor/plyr.js"></script>
    <script src="assets/js/vendor/jodit.min.js"></script>
    <script src="assets/js/vendor/Sortable.min.js"></script>



    <!-- Main JS -->
    <script src="assets/js/main.js"></script>
</body>

</html>