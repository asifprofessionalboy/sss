
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Admission</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">

    <!-- CSS
    ============================================ -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/slick.css">
    <link rel="stylesheet" href="assets/css/vendor/slick-theme.css">
    <link rel="stylesheet" href="assets/css/plugins/sal.css">
    <link rel="stylesheet" href="assets/css/plugins/feather.css">
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/plugins/euclid-circulara.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper.css">
    <link rel="stylesheet" href="assets/css/plugins/odometer.css">
    <link rel="stylesheet" href="assets/css/plugins/animation.css">
    <link rel="stylesheet" href="assets/css/plugins/bootstrap-select.min.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/plugins/magnigy-popup.min.css">
    <link rel="stylesheet" href="assets/css/plugins/plyr.css">
    <link rel="stylesheet" href="assets/css/plugins/jodit.min.css" />

    <link rel="stylesheet" href="assets/css/styles.css">
    <style>

.frm-contain {
    background-color: white;
    padding: 20px;
    border: 1px solid #ccc;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
}

.headings {
    background-color: #f7f8f9;
    color: white;
    padding: 10px;
    text-align: center;
}


label {
  
    margin-bottom:5px;
}




</style>
</head>
<body class="rbt-header-sticky active-light-mode">



  <?php include 'header.php' ?>



  <div class="container mt--30">
<div class="row g-5">
                <div class="col-lg-12 mb--60">
                    <div class="section-title text-center">

                        <h1 class="title">Admission</h1>
                        <p class="description mt--20">

                        Admission Open, Limited Seats.
                        </p>
                    </div>
                </div>
            </div>
</div>



<div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-7 col-12">
                <div class="tab-pane">
                    <div class="rbt-my-account-inner">
                        <div class="header-container mb-4 headings">
                            <img src="assets/images/logo/logo.png" class="logo" alt="logo">

                            <h6 class="text-grey">An ISO 9001:2015 Certified Training Institute</h6><h6>
                            </h6>
                        </div>
                        <div class="text-center">
                            <h4 class="text-grey">Admission Form</h4>

                        </div>

                        <div class="account-details-form">
                            <form action="#">
                                <div class="row g-5">

                                    <div class="col-lg-12 col-12">

                                        <label>Student's Name  : </label> <input id="name" name="name" placeholder="Student's Name :" type="text" required>
                                    </div>

                                    <div class="col-lg-6 col-12">
                                        <label>Father's Name  : </label>   <input id="fname" name="fname" placeholder="Father's Name:" type="text" required>
                                    </div>

                                    <div class="col-lg-6 col-12">
                                        <label>Mother's Name  : </label>     <input id="mname" name="mname" placeholder="Mother's Name" type="text" required>
                                    </div>


                                    <div class="col-lg-12 col-12">
                                        <label>Select Course : </label>
                                        <select name="course" required>
                                            <option disabled="" selected="">Select Course</option>
                                            <option value="Volvo Training">Volvo Training</option>
                                            <option value="Haulpak Training">Haulpak Training</option>
                                            <option value="Mobile Crane Course">Mobile Crane Course</option>
                                            <option value="Forklift Training">Forklift Training</option>
                                            <option value="Excavator Training">Excavator Training</option>
                                            <option value="Dozer Course">Dozer Course</option>
                                            <option value="Grader Training">Grader Training</option>
                                            <option value="Loader Training">Loader Training</option>
                                            <option value="Hydraulic Crane Course">Hydraulic Crane Course</option>
                                            <option value="
				Crawler Crane Course">
                                                Crawler Crane Course
                                            </option>
                                            <option value="Tower Crane Course">Tower Crane Course</option>
                                            <option value="Overhead Crane Course">Overhead Crane Course</option>
                                            <option value="Hydra Crane Course">Hydra Crane Course</option>
                                            <option value="JCB Course Training">JCB Course Training</option>
                                            <option value="Shovel Training">Shovel Training</option>
                                            <option value="Calmark Crane Training">Calmark Crane Training</option>
                                            <option value="Farana Crane Training">Farana Crane Training</option>
                                            <option value="RTG Crane Training">RTG Crane Training</option>
                                        </select>
                                    </div>

                                    <div class="col-lg-6 col-12">
                                        <label>Date of Birth : </label>     <input id="dob" name="dob" placeholder="DOB" type="date" required>
                                    </div>

                                    <div class="col-lg-6 col-12">
                                        <label>Gender :</label>
                                        <select name="status">
                                            <option disabled="" selected="">Select Gender</option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                        </select>
                                    </div>

                                    <div class="col-lg-12 col-12">
                                        <label>Present Address  : </label>     <input id="photo" name="photo" placeholder="Present Address " type="text" required>
                                    </div>


                                    <div class="col-lg-12 col-12">
                                        <label>
                                            Permanent Address :
                                        </label>     <input id="photo" placeholder="Permanent Address" name="paddress" type="text" required>
                                    </div>


                                    <div class="col-lg-6 col-12">
                                        <label>Phone No : </label>     <input id="mob" name="mob" placeholder="Phone No" type="text" required>
                                    </div>



                                    <div class="col-lg-6 col-12">
                                        <label>
                                            Email :
                                        </label>     <input id="email" name="email" placeholder="Email" type="text" required>
                                    </div>



                                   


                                    <div class="col-lg-6 col-12">
                                        <label>
                                            Blood Group :
                                        </label>     <input id="blood" name="blood" placeholder="Blood Group" type="text" required>
                                    </div>



                                    <div class="col-lg-6 col-12">
                                        <label>
                                            Occupation :
                                        </label>     <input id="occupation" name="occupation" placeholder="Occupation" type="text" required>
                                    </div>



                                    <div class="col-lg-6 col-12">
                                        <label>Status :</label>
                                        <select name="status" required>
                                            <option disabled="" selected="">Select Course</option>
                                            <option value="married">Married</option>
                                            <option value="unmarried">Unmarried</option>
                                        </select>
                                    </div>




                                    <div class="col-12">
                                        <button class="rbt-btn btn-gradient icon-hover w-100">
                                            <span class="btn-text">Submit</span>
                                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </button>
                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <br /><br />






    <br />
    <br />



    <?php include 'footer.php' ?>



    <!-- JS
    ============================================ -->
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr.min.js"></script>
    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.min.js"></script>
    <!-- sal.js -->
    <script src="assets/js/vendor/sal.js"></script>
    <!-- Dark Mode Switcher -->
    <script src="assets/js/vendor/js.cookie.js"></script>
    <script src="assets/js/vendor/jquery.style.switcher.js"></script>
    <script src="assets/js/vendor/swiper.js"></script>
    <script src="assets/js/vendor/jquery-appear.js"></script>
    <script src="assets/js/vendor/odometer.js"></script>
    <script src="assets/js/vendor/backtotop.js"></script>
    <script src="assets/js/vendor/isotop.js"></script>
    <script src="assets/js/vendor/imageloaded.js"></script>

    <script src="assets/js/vendor/wow.js"></script>
    <script src="assets/js/vendor/waypoint.min.js"></script>
    <script src="assets/js/vendor/easypie.js"></script>
    <script src="assets/js/vendor/text-type.js"></script>
    <script src="assets/js/vendor/jquery-one-page-nav.js"></script>
    <script src="assets/js/vendor/bootstrap-select.min.js"></script>
    <script src="assets/js/vendor/jquery-ui.js"></script>
    <script src="assets/js/vendor/magnify-popup.min.js"></script>
    <script src="assets/js/vendor/paralax-scroll.js"></script>
    <script src="assets/js/vendor/paralax.min.js"></script>
    <script src="assets/js/vendor/countdown.js"></script>
    <script src="assets/js/vendor/plyr.js"></script>
    <script src="assets/js/vendor/jodit.min.js"></script>
    <script src="assets/js/vendor/Sortable.min.js"></script>



    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>

</html>