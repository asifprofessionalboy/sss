
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
   
    <meta name="robots" content="noindex, follow" />
   <title>Gallery Rashtrita Technical Institute :: 09334617411:: Mobile crane operator Forklift Training in India</title>
    <meta name="description" content="Gallery for RTIJSR, Mobile crane Jcb Excavator Forklift HVAC, Electrician, Quantity surveyor, Mechanical course, Electrician course, Plant AC course, Quality controller course, Pipe fitter fabricator, Land surveyor, Milwright fitter, Material management course training center India" />
    <meta name="keywords" content="Gallery for RTIJSR, Rashtrita Technical Institute- Mobile crane operator Hydra crane operator Tower crane operator Jcb operator Jharkhand, Uttar Pradesh, Odisha, West Bangal, Madhya Pradesh, Excavator operator Forklift operator Grader operator course training center, Best Training Institute  or school for Job oriented Diploma certificate course in Technical Courses Quantity surveyor, Mechanical course, Electrician course, Plant AC course, Quality controller course, Pipe fitter fabricator, Land surveyor, Milwright fitter, Material management, Hvac ac technician, Instrument technician, Store management operator course training center, Best Training Institute  or school for Job oriented Diploma certificate courseIndia Bihar, Chattisgarh, Punjab, Haryana, Rajasthan, Uttarakhand, Assam, Maharashtra, Gujarat" />
  
    <link rel="canonical" href="https://rtijsr.in/student-gallery.php" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">

    <!-- CSS
    ============================================ -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/slick.css">
    <link rel="stylesheet" href="assets/css/vendor/slick-theme.css">
    <link rel="stylesheet" href="assets/css/plugins/sal.css">
    <link rel="stylesheet" href="assets/css/plugins/feather.css">
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/plugins/euclid-circulara.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper.css">
    <link rel="stylesheet" href="assets/css/plugins/odometer.css">
    <link rel="stylesheet" href="assets/css/plugins/animation.css">
    <link rel="stylesheet" href="assets/css/plugins/bootstrap-select.min.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/plugins/magnigy-popup.min.css">
    <link rel="stylesheet" href="assets/css/plugins/plyr.css">
    <link rel="stylesheet" href="assets/css/plugins/jodit.min.css" />

    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body class="rbt-header-sticky">


<?php include 'header.php' ?>





    <div class="rbt-gallery-area container">


    <div class="row">
                <div class="col-lg-12 mt--30">
                    <div class="section-title text-center">
                        <h1 class="title">Our Gallery</h1>
                        <p class="description mt--20 mb--30">View Our Institute Gallery and Students Activities</p>
                    </div>
                </div>
            </div>
    
        <div class="row parent-gallery-container">


        
        <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/1.jpg" alt="Gallery Images">
                </div>
            </a>
            <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/2.jpeg" alt="Gallery Images">
                </div>
            </a>
            <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/3.jpeg" alt="Gallery Images">
                </div>
            </a>
         <!-- #region -->
         <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/4.jfif" alt="Gallery Images">
                </div>
            </a>
            <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/5.jpg" alt="Gallery Images">
                </div>
            </a>
            <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/6.jpg" alt="Gallery Images">
                </div>
            </a>
            <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/7.jpg" alt="Gallery Images">
                </div>
            </a>
            <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/8.jpg" alt="Gallery Images">
                </div>
            </a>
            <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/9.jpg" alt="Gallery Images">
                </div>
            </a>
            <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/10.jpg" alt="Gallery Images">
                </div>
            </a>
            <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/11.jpg" alt="Gallery Images">
                </div>
            </a>
            <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/12.jpg" alt="Gallery Images">
                </div>
            </a>
            <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/13.jpg" alt="Gallery Images">
                </div>
            </a>
            <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/1.jpeg" alt="Gallery Images">
                </div>
            </a>
            <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/16.jpg" alt="Gallery Images">
                </div>
            </a>
            <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/17.jpg" alt="Gallery Images">
                </div>
            </a>
            <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/18.jpg" alt="Gallery Images">
                </div>
            </a>

            <a href="assets/images/gallery/8.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/14.jpg" alt="Gallery Images">
                </div>
            </a>



            
            <a href="assets/images/gallery/11.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/11.jpg" alt="Gallery Images">
                </div>
            </a>

            <a href="assets/images/gallery/15.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="rbt-gallery">
                    <img class="w-100" src="assets/images/gallery/15.jpg" alt="Gallery Images">
                </div>
            </a>


            </div>

        <br />


        </div>



        <?php include 'footer.php' ?>



    <!-- JS
    ============================================ -->
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr.min.js"></script>
    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.min.js"></script>
    <!-- sal.js -->
    <script src="assets/js/vendor/sal.js"></script>
    <!-- Dark Mode Switcher -->
    <script src="assets/js/vendor/js.cookie.js"></script>
    <script src="assets/js/vendor/jquery.style.switcher.js"></script>
    <script src="assets/js/vendor/swiper.js"></script>
    <script src="assets/js/vendor/jquery-appear.js"></script>
    <script src="assets/js/vendor/odometer.js"></script>
    <script src="assets/js/vendor/backtotop.js"></script>
    <script src="assets/js/vendor/isotop.js"></script>
    <script src="assets/js/vendor/imageloaded.js"></script>

    <script src="assets/js/vendor/wow.js"></script>
    <script src="assets/js/vendor/waypoint.min.js"></script>
    <script src="assets/js/vendor/easypie.js"></script>
    <script src="assets/js/vendor/text-type.js"></script>
    <script src="assets/js/vendor/jquery-one-page-nav.js"></script>
    <script src="assets/js/vendor/bootstrap-select.min.js"></script>
    <script src="assets/js/vendor/jquery-ui.js"></script>
    <script src="assets/js/vendor/magnify-popup.min.js"></script>
    <script src="assets/js/vendor/paralax-scroll.js"></script>
    <script src="assets/js/vendor/paralax.min.js"></script>
    <script src="assets/js/vendor/countdown.js"></script>
    <script src="assets/js/vendor/plyr.js"></script>
    <script src="assets/js/vendor/jodit.min.js"></script>
    <script src="assets/js/vendor/Sortable.min.js"></script>



    <!-- Main JS -->
    <script src="assets/js/main.js"></script>
</body>

</html>