
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>About Us</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">

    <!-- CSS
    ============================================ -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/slick.css">
    <link rel="stylesheet" href="assets/css/vendor/slick-theme.css">
    <link rel="stylesheet" href="assets/css/plugins/sal.css">
    <link rel="stylesheet" href="assets/css/plugins/feather.css">
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/plugins/euclid-circulara.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper.css">
    <link rel="stylesheet" href="assets/css/plugins/odometer.css">
    <link rel="stylesheet" href="assets/css/plugins/animation.css">
    <link rel="stylesheet" href="assets/css/plugins/bootstrap-select.min.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/plugins/magnigy-popup.min.css">
    <link rel="stylesheet" href="assets/css/plugins/plyr.css">
    <link rel="stylesheet" href="assets/css/plugins/jodit.min.css" />

    <link rel="stylesheet" href="assets/css/styles.css">

    <style>
        @media only screen and (max-width: 767px) {
    .rbt-section-gapTop {
        padding-top: 80px;
    }
}
    </style>
</head>
<body class="rbt-header-sticky active-light-mode">


    <?php include 'header.php' ?>

  
    <!-- Start About  -->


    <div class="rbt-about-area about-style-1  rbt-section-gapTop mt--60">
        <div class="container">
            <div class="row g-5 align-items-center">
                <div class="col-lg-6">
                    <div class="thumbnail-wrapper">
                        <div class="thumbnail image-1">
                            <img data-parallax="{&quot;x&quot;: 0, &quot;y&quot;: -20}" src="assets/images/about/about.jpg" alt="Education Images" style="transform:translate3d(0px, -20px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); -webkit-transform:translate3d(0px, -20px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); transform:translate3d(0px, -20px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); -webkit-transform:translate3d(0px, -20px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); ">
                        </div>
                        <div class="thumbnail image-2 d-none d-xl-block">
                            <img data-parallax="{&quot;x&quot;: 0, &quot;y&quot;: 60}" src="assets/images/about/about-3.png" alt="Education Images" style="transform:translate3d(0px, 60px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); -webkit-transform:translate3d(0px, 60px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); transform:translate3d(0px, 60px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); -webkit-transform:translate3d(0px, 60px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); ">
                        </div>
                        <div class="thumbnail image-3 d-none d-md-block">
                            <img data-parallax="{&quot;x&quot;: 0, &quot;y&quot;: 80}" src="assets/images/about/about-1.jpg" alt="Education Images" style="transform:translate3d(0px, 80px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); -webkit-transform:translate3d(0px, 80px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); transform:translate3d(0px, 47.778px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); -webkit-transform:translate3d(0px, 47.778px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); ">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="inner pl--50 pl_sm--0 pl_md--0">
                        <div class="section-title text-start">

                            <h2 class="title">Rashtriya Technical Institute</h2>
                        </div>
                        <p class="description mt--30">
                            Rashtriya Technical Institute (RTI) has taken up the challenge for the development of the skilled workforce in an era of rapid economic and technological changes by imparting the intensive training in various branches of technical courses.
                            RTI has designed various job oriented short-term courses keeping in mind the qualification and ability of students. So that they can consume the opportunity in the industrializing global market.
                        </p>
                        <p>
                            You are co-orderly invited to get Admission, All Courses are Job Oriented with placement assistance.<br> देश और विदेश में नौकरी पाने के लिए काम सीखे RTI has designed various job oriented short-term courses keeping in mind the qualification and ability of students.
                        </p>
                        <!-- Start Feature List  -->
                        <div class="rbt-feature-wrapper ">

                            <div class="rbt-feature feature-style-1">
                                <div class="icon bg-pink-opacity">
                                    <i class="feather-heart"></i>
                                </div>
                                <div class="feature-content">
                                    <h6 class="feature-title">Flexible Classes</h6>
                                    <p class="feature-description">
                                        It is a long established fact that a reader will
                                        be distracted by this on readable content of when looking at its layout.
                                    </p>
                                </div>
                            </div>

                            <div class="rbt-feature feature-style-1">
                                <div class="icon bg-primary-opacity">
                                    <i class="feather-book"></i>
                                </div>
                                <div class="feature-content">
                                    <h6 class="feature-title">Learn From Anywhere</h6>
                                    <p class="feature-description">Sed distinctio repudiandae eos recusandae laborum eaque non eius iure suscipit laborum eaque non eius iure suscipit.</p>
                                </div>
                            </div>

                            <div class="rbt-feature feature-style-1">
                                <div class="icon bg-coral-opacity">
                                    <i class="feather-monitor"></i>
                                </div>
                                <div class="feature-content">
                                    <h6 class="feature-title">Experienced Teacher's service.</h6>
                                    <p class="feature-description">Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia, aliquid mollitia Officia, aliquid mollitia.</p>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- End About  -->

    <br />
    <br />


 

       <!-- Start why choose  -->

       <div class="rbt-counterup-area rbt-section-gapBottom bg-color-extra2">
        <div class="container">
            <div class="row mb--60">
                <div class="col-lg-12">
                    <div class="section-title text-center">
                        <br />
                        <h2 class="title">Why Choose Us</h2>

                    </div>
                </div>
            </div>
            <div class="row g-5 hanger-line">
                <!-- Start Single Counter  -->
                <div class="col-lg-3 col-xl-2 col-md-6 col-sm-6 col-12">
                    <div class="rbt-counterup rbt-hover-03 border-bottom-gradient">
                        <div class="top-circle-shape"></div>
                        <div class="inner">
                            <div class="rbt-round-icon">
                                <img src="assets/images/icons/counter-01.png" alt="Icons Images">
                            </div>
                            <div class="content">

                                <span class="subtitle">18 Years of Excellence</span>
                         
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Counter  -->
                <!-- Start Single Counter  -->
                <div class="col-lg-3  col-xl-2 col-md-6 col-sm-6 col-12 mt--60 mt_md--30 mt_sm--30 mt_mobile--60">
                    <div class="rbt-counterup rbt-hover-03 border-bottom-gradient">
                        <div class="top-circle-shape"></div>
                        <div class="inner">
                            <div class="rbt-round-icon">
                                <img src="assets/images/icons/counter-02.png" alt="Icons Images">
                            </div>
                            <div class="content">
                                <span class="subtitle">Career Growth 	</span>
                                <span class="subtitle"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Counter  -->
                <!-- Start Single Counter  -->
                <div class="col-lg-3 col-xl-2 col-md-6 col-sm-6 col-12 mt_md--60 mt_sm--60">
                    <div class="rbt-counterup rbt-hover-03 border-bottom-gradient">
                        <div class="top-circle-shape"></div>
                        <div class="inner">
                            <div class="rbt-round-icon">
                                <img src="assets/images/icons/counter-03.png" alt="Icons Images">
                            </div>
                            <div class="content">
                                <span class="subtitle">	Placement Assistance</span>
                              

                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Counter  -->
                <!-- Start Single Counter  -->
                <div class="col-lg-3 col-xl-2 col-md-6 col-sm-6 col-12 mt--60 mt_md--30 mt_sm--30 mt_mobile--60">
                    <div class="rbt-counterup rbt-hover-03 border-bottom-gradient">
                        <div class="top-circle-shape"></div>
                        <div class="inner">
                            <div class="rbt-round-icon">
                                <img src="assets/images/icons/counter-04.png" alt="Icons Images">
                            </div>
                            <div class="content">
                                <span class="subtitle"> 100% Practical	</span>
                                <span class="subtitle"> </span>
                                <span class="subtitle"> </span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Counter  -->



                <div class="col-lg-3 col-xl-2 col-md-6 col-sm-6 col-12">
                    <div class="rbt-counterup rbt-hover-03 border-bottom-gradient">
                        <div class="top-circle-shape"></div>
                        <div class="inner">
                            <div class="rbt-round-icon">
                                <img src="assets/images/icons/counter-01.png" alt="Icons Images">
                            </div>
                            <div class="content">

                                <span class="subtitle">Experienced Teachers</span>
                         
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Counter  -->
                <!-- Start Single Counter  -->
                <div class="col-lg-3 col-xl-2 col-md-6 col-sm-6 col-12 mt--60 mt_md--30 mt_sm--30 mt_mobile--60">
                    <div class="rbt-counterup rbt-hover-03 border-bottom-gradient">
                        <div class="top-circle-shape"></div>
                        <div class="inner">
                            <div class="rbt-round-icon">
                                <img src="assets/images/icons/counter-02.png" alt="Icons Images">
                            </div>
                            <div class="content">
                                <span class="subtitle">Govt Registered	</span>
                                <span class="subtitle"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Start why choose  -->


    <!-- Start why choose  -->

    <br />




    <!-- Vision Mission  -->
    <div class="rbt-become-area rbt-section-gap">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="title text-center">
                        Read Our
                        <span class="header-caption">
                            <span class="cd-headline clip is-full-width">
                                <span class="cd-words-wrapper" style="width: 232px;">
                                    <b class="theme-gradient is-hidden">Mission.</b>
                                    <b class="theme-gradient is-visible">Vission.</b>
                                    <b class="theme-gradient is-hidden">Planning.</b>
                                </span>
                            </span>
                        </span>
                    </h2>
                </div>
            </div>

            <div class="row row row--30">

                <div class="col-lg-12 mt_md--40 mt_sm--40 order-2 order-lg-1">
                    <div class="advance-tab-button">
                        <ul class="nav nav-tabs tab-button-style-2" id="myTab-4" role="tablist">
                            <li role="presentation">
                                <a href="#" class="tab-button" id="home-tab-4" data-bs-toggle="tab" data-bs-target="#home-4" role="tab" aria-controls="home-4" aria-selected="false">
                                    <span class="title">Our Mission</span>
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="#" class="tab-button" id="profile-tab-4" data-bs-toggle="tab" data-bs-target="#profile-4" role="tab" aria-controls="profile-4" aria-selected="false">
                                    <span class="title">Our Vision</span>
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="#" class="tab-button active" id="contact-tab-4" data-bs-toggle="tab" data-bs-target="#contact-4" role="tab" aria-controls="contact-4" aria-selected="true">
                                    <span class="title">Our Planning</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content advance-tab-content-style-2">
                        <div class="tab-pane fade" id="home-4" role="tabpanel" aria-labelledby="home-tab-4">

                            <div class="content">
                                <p>
                                    A socially responsible institute that provide skills to meet the need of the public, private,
                                    community and individuals in the country through quality education and training of recognized programme.
                            </div>

                        </div>


                        <div class="tab-pane fade" id="profile-4" role="tabpanel" aria-labelledby="profile-tab-4">
                            <div class="content">
                                <p>
                                    Towards Quality skilled work force. And Excellence in Technical Education through Innovation and Teamwork. Be a premier institution in technical training and education to create the most sought after trainees.
                                </p>
                            </div>
                        </div>
                        <div class="tab-pane fade active show" id="contact-4" role="tabpanel" aria-labelledby="contact-tab-4">
                            <div class="content">
                                <p>
                                    Experiencing music ipsum dolor sit amet consectetur, adipisicing elit.
                                    Experiencing music ipsum dolor sit amet consectetur, adipisicing elit.
                                    Tempora sequi doloremque dicta quia unde odio nam minus reiciendis ullam aliquam, dolorum ab quisquam cum numquam nemo iure cumque iste. Accusamus necessitatibus.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>









    <br /><br />

    <?php include 'footer.php' ?>
    <!-- JS
    ============================================ -->
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr.min.js"></script>
    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.min.js"></script>
    <!-- sal.js -->
    <script src="assets/js/vendor/sal.js"></script>
    <!-- Dark Mode Switcher -->
    <script src="assets/js/vendor/js.cookie.js"></script>
    <script src="assets/js/vendor/jquery.style.switcher.js"></script>
    <script src="assets/js/vendor/swiper.js"></script>
    <script src="assets/js/vendor/jquery-appear.js"></script>
    <script src="assets/js/vendor/odometer.js"></script>
    <script src="assets/js/vendor/backtotop.js"></script>
    <script src="assets/js/vendor/isotop.js"></script>
    <script src="assets/js/vendor/imageloaded.js"></script>

    <script src="assets/js/vendor/wow.js"></script>
    <script src="assets/js/vendor/waypoint.min.js"></script>
    <script src="assets/js/vendor/easypie.js"></script>
    <script src="assets/js/vendor/text-type.js"></script>
    <script src="assets/js/vendor/jquery-one-page-nav.js"></script>
    <script src="assets/js/vendor/bootstrap-select.min.js"></script>
    <script src="assets/js/vendor/jquery-ui.js"></script>
    <script src="assets/js/vendor/magnify-popup.min.js"></script>
    <script src="assets/js/vendor/paralax-scroll.js"></script>
    <script src="assets/js/vendor/paralax.min.js"></script>
    <script src="assets/js/vendor/countdown.js"></script>
    <script src="assets/js/vendor/plyr.js"></script>
    <script src="assets/js/vendor/jodit.min.js"></script>
    <script src="assets/js/vendor/Sortable.min.js"></script>



    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>

</html>