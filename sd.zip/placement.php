
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="robots" content="noindex, follow" />
     <title>Placement | Rashtrita Technical Institute | Mobile crane operator Forklift Training in India</title>
        <meta name="description"
            content="Placement records of RTIJSR for Mobile crane Jcb Excavator Forklift HVAC, Electrician, Quantity surveyor, Mechanical course, Electrician course, Plant AC course, Quality controller course, Pipe fitter fabricator, Land surveyor, Milwright fitter, Material management course training center India" />
        <meta name="keywords"
            content="Placement records of Rashtrita Technical Institute- Mobile crane operator Hydra crane operator Tower crane operator Jcb operator Jharkhand, Uttar Pradesh, Odisha, West Bangal, Madhya Pradesh, Excavator operator Forklift operator Grader operator course training center, Best Training Institute  or school for Job oriented Diploma certificate course in Technical Courses Quantity surveyor, Mechanical course, Electrician course, Plant AC course, Quality controller course, Pipe fitter fabricator, Land surveyor, Milwright fitter, Material management, Hvac ac technician, Instrument technician, Store management operator course training center, Best Training Institute  or school for Job oriented Diploma certificate courseIndia Bihar, Chattisgarh, Punjab, Haryana, Rajasthan, Uttarakhand, Assam, Maharashtra, Gujarat" />
      
        <link rel="canonical" href="https://rtijsr.in/placements.php" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">

    <!-- CSS
	============================================ -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/slick.css">
    <link rel="stylesheet" href="assets/css/vendor/slick-theme.css">
    <link rel="stylesheet" href="assets/css/plugins/sal.css">
    <link rel="stylesheet" href="assets/css/plugins/feather.css">
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/plugins/euclid-circulara.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper.css">
    <link rel="stylesheet" href="assets/css/plugins/odometer.css">
    <link rel="stylesheet" href="assets/css/plugins/animation.css">
    <link rel="stylesheet" href="assets/css/plugins/bootstrap-select.min.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/plugins/magnigy-popup.min.css">
    <link rel="stylesheet" href="assets/css/plugins/plyr.css">
    <link rel="stylesheet" href="assets/css/plugins/jodit.min.css" />

    <link rel="stylesheet" href="assets/css/styles.css">

    <style>

        .body-wrap{
     padding: 1rem 1rem;
    background-color: #ffffff;
    border-radius: 10px;
    width: 100%;
    position: relative;
    margin-bottom: 20px;
        }
    </style>
</head>
<body class="rbt-header-sticky active-light-mode" style="background-color:#f7f8f9">


<?php include 'header.php' ?>

<div class="rbt-become-area rbt-section-gap bg-color-extra2 ">
        <div class="container">
            <div class="row">
            <div class="col-lg-12 mt--30">
                    <div class="section-title text-center">
                        <h1 class="title">Our Placements</h1>
                        <p class="description mt--20 mb--30">RTI is providing Placement for all the students, If You want to get Job after completion of course, you can join RTI.</p>
                    </div>
                </div>
            </div>

            <div class="row row row--30">

                <div class="col-lg-12 mt_md--40 mt_sm--40 order-2 order-lg-1">
                    <div class="advance-tab-button">
                        <ul class="nav nav-tabs tab-button-style-2" id="myTab-4" role="tablist">
                            <li role="presentation">
                                <a href="#" class="tab-button" id="home-tab-4" data-bs-toggle="tab"
                                    data-bs-target="#home-4" role="tab" aria-controls="home-4" aria-selected="false">
                                    <span class="title">Operator</span>
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="#" class="tab-button" id="profile-tab-4" data-bs-toggle="tab"
                                    data-bs-target="#profile-4" role="tab" aria-controls="profile-4"
                                    aria-selected="false">
                                    <span class="title">Technical</span>
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="#" class="tab-button active" id="contact-tab-4" data-bs-toggle="tab"
                                    data-bs-target="#contact-4" role="tab" aria-controls="contact-4"
                                    aria-selected="true">
                                    <span class="title">Welding</span>
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="#" class="tab-button" id="contact-tab-5" data-bs-toggle="tab"
                                    data-bs-target="#contact-5" role="tab" aria-controls="contact54"
                                    aria-selected="true">
                                    <span class="title">Safety</span>
                                </a>
                            </li>

                        </ul>
                    </div>
                    <div class="tab-content advance-tab-content-style-2">
                        <div class="tab-pane fade" id="home-4" role="tabpanel" aria-labelledby="home-tab-4">

                        <div class="row">

<div class="col-lg-12">
    <!-- Start Enrole Course  -->
   
        <div class="content">
       




       

            <div class="rbt-dashboard-table table-responsive mobile-table-750">
                <table class="rbt-table table table-borderless">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Name</th>
                            <th>Company</th>
                            <th>Trade</th>
                            <th>Place</th>


                        </tr>
                    </thead>
                    <tbody>
                        <tr>

                            <td>
                                <img src="assets/images/placement/ArbazKhan.png" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Arbaz Khan</p>
                            </td>
                            <td>
                                <p class="b3">Y.P Crane Services pvt ltd</p>
                            </td>
                            <td>
                                <p class="b3">Mobile Crane Operator</p>
                            </td>
                            <td>
                                <p class="b3"> Chennai</p>
                            </td>
                        </tr>

                        <tr>

                            <td>
                                <img src="assets/images/placement/yaseenShah.png" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Yaseen Shah</p>
                            </td>
                            <td>
                                <p class="b3">Y.P Crane Services pvt ltd</p>
                            </td>
                            <td>
                                <p class="b3">Mobile Crane Operator</p>
                            </td>
                            <td>
                                <p class="b3"> Chennai</p>
                            </td>
                        </tr>
                        <tr>

                            <td>
                                <img src="assets/images/placement/adarsh.jpg" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Adarsh Tiwari</p>
                            </td>
                            <td>
                                <p class="b3">KRISHNA CRANE SERVICE</p>
                            </td>
                            <td>
                                <p class="b3">Mobile Crane Operator</p>
                            </td>
                            <td>
                                <p class="b3"> Ahmadabad</p>
                            </td>
                        </tr>
                        <tr>

                            <td>
                                <img src="assets/images/placement/venkath.jpg" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Venkath Rao</p>
                            </td>
                            <td>
                                <p class="b3">SRP ENTERPRISES</p>
                            </td>
                            <td>
                                <p class="b3">Mobile Crane Operator</p>
                            </td>
                            <td>
                                <p class="b3"> Chennai</p>
                            </td>
                        </tr>
                        <tr>

                            <td>
                                <img src="assets/images/placement/ak.jpg" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Ak Prasad</p>
                            </td>
                            <td>
                                <p class="b3">MAHINDRA LTD.	</p>
                            </td>
                            <td>
                                <p class="b3">Forklift Operator</p>
                            </td>
                            <td>
                                <p class="b3">Pune</p>
                            </td>
                        </tr>
                        <tr>

                            <td>
                                <img src="assets/images/placement/javed.jpg" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Javed Alam</p>
                            </td>
                            <td>
                                <p class="b3">EARTH MOVER LTD.</p>
                            </td>
                            <td>
                                <p class="b3">Excavator Operator</p>
                            </td>
                            <td>
                                <p class="b3"> Bardawan</p>
                            </td>
                        </tr>
                    </tbody>

                </table>
            </div>

     
      </div>
    <!-- End Enrole Course  -->
</div>
</div>

                        </div>


                        <div class="tab-pane fade" id="profile-4" role="tabpanel" aria-labelledby="profile-tab-4">
                        <div class="row body-wrap">

<div class="col-lg-12">
    <!-- Start Enrole Course  -->
   
        <div class="content">
       




       

            <div class="rbt-dashboard-table table-responsive mobile-table-750">
                <table class="rbt-table table table-borderless">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Name</th>
                            <th>Company</th>
                            <th>Trade</th>
                            <th>Place</th>


                        </tr>
                    </thead>
                    <tbody>
                        <tr>

                            <td>
                                <img src="assets/images/placement/MdShaqueb.png" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Md Shaqueb</p>
                            </td>
                            <td>
                                <p class="b3">Steel Trip pvt ltd</p>
                            </td>
                            <td>
                                <p class="b3">Mechanical Technician</p>
                            </td>
                            <td>
                                <p class="b3"> Tata Nagar</p>
                            </td>
                        </tr>

                        <tr>

                            <td>
                                <img src="assets/images/placement/aftab.jpg" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Aftab Khan</p>
                            </td>
                            <td>
                                <p class="b3">VEE4 TECHNOLOGIES PVT LTD</p>
                            </td>
                            <td>
                                <p class="b3"> Instrumentation</p>
                            </td>
                            <td>
                                <p class="b3"> Faridabad</p>
                            </td>
                        </tr>
                        <tr>

                            <td>
                                <img src="assets/images/placement/nitesh.jpg" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Nitesh Kumar</p>
                            </td>
                            <td>
                                <p class="b3">GHAI CONSTRUCTION LTD.</p>
                            </td>
                            <td>
                                <p class="b3"> Instrumentation</p>
                            </td>
                            <td>
                                <p class="b3"> Mumbai</p>
                            </td>
                        </tr>
                        <tr>

                            <td>
                                <img src="assets/images/placement/taufeeque.jpg" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Taufeeque Ahmad</p>
                            </td>
                            <td>
                                <p class="b3">KHARAMA AIRPORT PROJECT</p>
                            </td>
                            <td>
                                <p class="b3"> B.M.S</p>
                            </td>
                            <td>
                                <p class="b3"> UAE</p>
                            </td>
                        </tr>
                        <tr>

                            <td>
                                <img src="assets/images/placement/abhimannu.jpg" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Abhimnnu</p>
                            </td>
                            <td>
                                <p class="b3">GULF ENGINEERING</p>
                            </td>
                            <td>
                                <p class="b3"> HVAC</p>
                            </td>
                            <td>
                                <p class="b3"> Kuwait</p>
                            </td>
                        </tr>
                        <tr>

                            <td>
                                <img src="assets/images/placement/faizan.jpg" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Faizan Ahmad</p>
                            </td>
                            <td>
                                <p class="b3">KHARAMA AIRPORT PROJECT</p>
                            </td>
                            <td>
                                <p class="b3"> B.M.S</p>
                            </td>
                            <td>
                                <p class="b3"> Abudhabi</p>
                            </td>
                        </tr>
                        <tr>

                            <td>
                                <img src="assets/images/placement/nawaz.jpg" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Md Nawaz</p>
                            </td>
                            <td>
                                <p class="b3">AL MAJAL CONTRACTING CO.</p>
                            </td>
                            <td>
                                <p class="b3"> B.M.S</p>
                            </td>
                            <td>
                                <p class="b3"> Saudi Arab</p>
                            </td>
                        </tr>
                        <tr>

                            <td>
                                <img src="assets/images/placement/rashid.jpg" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Md Rashid</p>
                            </td>
                            <td>
                                <p class="b3">AL MAJAL CONTRACTING CO.</p>
                            </td>
                            <td>
                                <p class="b3"> B.M.S</p>
                            </td>
                            <td>
                                <p class="b3"> Saudi Arab</p>
                            </td>
                        </tr>
                    </tbody>

                </table>
            </div>

     
      </div>
    <!-- End Enrole Course  -->
</div>
</div>
                        </div>
                        <div class="tab-pane fade active show" id="contact-4" role="tabpanel"
                            aria-labelledby="contact-tab-4">
                            <div class="row body-wrap">

<div class="col-lg-12">
    <!-- Start Enrole Course  -->
   
        <div class="content">
       




       

            <div class="rbt-dashboard-table table-responsive mobile-table-750">
                <table class="rbt-table table table-borderless">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Name</th>
                            <th>Company</th>
                            <th>Trade</th>
                            <th>Place</th>


                        </tr>
                    </thead>
                    <tbody>
                        <tr>

                            <td>
                                <img src="assets/images/placement/pappu.jpg" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Pappu Kumar</p>
                            </td>
                            <td>
                                <p class="b3">KULDEEP WELDING</p>
                            </td>
                            <td>
                                <p class="b3"> Welder</p>
                            </td>
                            <td>
                                <p class="b3"> Chandigarh</p>
                            </td>
                        </tr>

                        <tr>

                            <td>
                                <img src="assets/images/placement/mohamadirfan.jpg" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Mohamad Irfan</p>
                            </td>
                            <td>
                                <p class="b3">NRVS COMPANY LTD.	</p>
                            </td>
                            <td>
                                <p class="b3"> Welder</p>
                            </td>
                            <td>
                                <p class="b3"> Chathisgar</p>
                            </td>
                        </tr>
                        <tr>

                            <td>
                                <img src="assets/images/placement/ansuman.jpg" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Ansuman</p>
                            </td>
                            <td>
                                <p class="b3">RAJHISTAAN STEEL PVT LTD	</p>
                            </td>
                            <td>
                                <p class="b3"> Welder</p>
                            </td>
                            <td>
                                <p class="b3"> Rajasthan</p>
                            </td>
                        </tr>
                        <tr>

<td>
    <img src="assets/images/placement/mehfooz.jpg" class="" alt="Product" style="height:80px;width:80px">
</td>
<td class="pro-title">
    <p class="b3">Mehfooz</p>
</td>
<td>
    <p class="b3">EARTYH MOVER LTD	</p>
</td>
<td>
    <p class="b3"> Welder</p>
</td>
<td>
    <p class="b3"> Mumbai</p>
</td>
</tr>
                    </tbody>

                </table>
            </div>

     
      </div>
    <!-- End Enrole Course  -->
</div>
</div>
                        </div>
                        <div class="tab-pane fade show" id="contact-5" role="tabpanel"
                            aria-labelledby="contact-tab-5">
                            <div class="row body-wrap">

<div class="col-lg-12">
    <!-- Start Enrole Course  -->
   
        <div class="content">
       




       

            <div class="rbt-dashboard-table table-responsive mobile-table-750">
                <table class="rbt-table table table-borderless">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Name</th>
                            <th>Company</th>
                            <th>Trade</th>
                            <th>Place</th>


                        </tr>
                    </thead>
                    <tbody>
                        <tr>

                            <td>
                                <img src="assets/images/placement/shubhum.png" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Shubham</p>
                            </td>
                            <td>
                                <p class="b3">Daga Power Group pvt ltd</p>
                            </td>
                            <td>
                                <p class="b3">Safety</p>
                            </td>
                            <td>
                                <p class="b3"> Indore</p>
                            </td>
                        </tr>

                        <tr>

                            <td>
                                <img src="assets/images/placement/shahnwazAlam.png" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Shahnwaz Alam</p>
                            </td>
                            <td>
                                <p class="b3">Hajee A.P Bava & Const.</p>
                            </td>
                            <td>
                                <p class="b3">Safety</p>
                            </td>
                            <td>
                                <p class="b3"> Hydrabad</p>
                            </td>
                        </tr>
                        <tr>

                            <td>
                                <img src="assets/images/placement/AzadAnsari.png" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Azad Ansari</p>
                            </td>
                            <td>
                                <p class="b3">Ibraheem & Construction</p>
                            </td>
                            <td>
                                <p class="b3">Safety</p>
                            </td>
                            <td>
                                <p class="b3"> Jamshedpur</p>
                            </td>
                        </tr>
                        <tr>

                            <td>
                                <img src="assets/images/placement/farhadAlam.png" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Farhad Alam</p>
                            </td>
                            <td>
                                <p class="b3">Ibraheem & Construction</p>
                            </td>
                            <td>
                                <p class="b3">Safety</p>
                            </td>
                            <td>
                                <p class="b3"> Jamshedpur</p>
                            </td>
                        </tr>
                        <tr>

                            <td>
                                <img src="assets/images/placement/SagarSoni.png" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Sagar Soni</p>
                            </td>
                            <td>
                                <p class="b3">Solvay Specialities pvt ltd</p>
                            </td>
                            <td>
                                <p class="b3">Safety</p>
                            </td>
                            <td>
                                <p class="b3"> Gujarat</p>
                            </td>
                        </tr>
                        <tr>

                            <td>
                                <img src="assets/images/placement/masoom.jpg" class="" alt="Product" style="height:80px;width:80px">
                            </td>
                            <td class="pro-title">
                                <p class="b3">Masoom</p>
                            </td>
                            <td>
                                <p class="b3">RELIANCE LTD.</p>
                            </td>
                            <td>
                                <p class="b3">Safety</p>
                            </td>
                            <td>
                                <p class="b3"> Gujarat</p>
                            </td>
                        </tr>
                    </tbody>

                </table>
            </div>

     
      </div>
    <!-- End Enrole Course  -->
</div>
</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="about-btn mt--40 text-center">
                                <a class="rbt-btn btn-gradient hover-icon-reverse" href="video-gallery.php">
                                    <span class="icon-reverse-wrapper">
                                        <span class="btn-text">View Video</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>

        </div>
        <br />
    </div>







    <br />
   
    <div class="container">

   

      
   </div>
   
        <!--<div class="wishlist_area rbt-section-gap">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <form action="#">
                            <div class="cart-table table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th class="pro-thumbnail">Image</th>
                                            <th class="pro-title">Name</th>
                                            <th class="pro-price">Company</th>
                                            <th class="pro-quantity">Trade</th>
                                            <th class="pro-subtotal">Place</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="pro-thumbnail"><a href="#"><img src="assets/images/product/1.jpg" alt="Product"></a></td>
                                            <td class="pro-title"><a href="#">Sardar Khan</a></td>
                                            <td class="pro-price"><span>Anacorporation</span></td>
                                            <td class="pro-price"><span>Forklift Operator</span></td>
                                            <td class="pro-price"><span>Dubai</span></td>

                                        </tr>

                                    </tbody>
                                </table>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>-->
<br>




        <?php include 'footer.php' ?>

        <!-- JS
        ============================================ -->
        <!-- Modernizer JS -->
        <script src="assets/js/vendor/modernizr.min.js"></script>
        <!-- jQuery JS -->
        <script src="assets/js/vendor/jquery.js"></script>
        <!-- Bootstrap JS -->
        <script src="assets/js/vendor/bootstrap.min.js"></script>
        <!-- sal.js -->
        <script src="assets/js/vendor/sal.js"></script>
        <!-- Dark Mode Switcher -->
        <script src="assets/js/vendor/js.cookie.js"></script>
        <script src="assets/js/vendor/jquery.style.switcher.js"></script>
        <script src="assets/js/vendor/swiper.js"></script>
        <script src="assets/js/vendor/jquery-appear.js"></script>
        <script src="assets/js/vendor/odometer.js"></script>
        <script src="assets/js/vendor/backtotop.js"></script>
        <script src="assets/js/vendor/isotop.js"></script>
        <script src="assets/js/vendor/imageloaded.js"></script>

        <script src="assets/js/vendor/wow.js"></script>
        <script src="assets/js/vendor/waypoint.min.js"></script>
        <script src="assets/js/vendor/easypie.js"></script>
        <script src="assets/js/vendor/text-type.js"></script>
        <script src="assets/js/vendor/jquery-one-page-nav.js"></script>
        <script src="assets/js/vendor/bootstrap-select.min.js"></script>
        <script src="assets/js/vendor/jquery-ui.js"></script>
        <script src="assets/js/vendor/magnify-popup.min.js"></script>
        <script src="assets/js/vendor/paralax-scroll.js"></script>
        <script src="assets/js/vendor/paralax.min.js"></script>
        <script src="assets/js/vendor/countdown.js"></script>
        <script src="assets/js/vendor/plyr.js"></script>
        <script src="assets/js/vendor/jodit.min.js"></script>
        <script src="assets/js/vendor/Sortable.min.js"></script>



        <!-- Main JS -->
        <script src="assets/js/main.js"></script>


</body>

</html>