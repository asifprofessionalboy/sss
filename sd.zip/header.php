<!-- Start Header Area -->
<header class="rbt-header rbt-header-10">
    <div class="rbt-sticky-placeholder" style="height: 0px;"></div>

    <!-- Start Header Top  -->
    <div
        class="rbt-header-top rbt-header-top-1 header-space-betwween bg-not-transparent bg-color-darker top-expended-activation">
        <div class="container-fluid">
            <div class="top-expended-wrapper">
                <div class="top-expended-inner rbt-header-sec align-items-center ">
                    <div class="rbt-header-sec-col rbt-header-left">
                        <div class="rbt-header-content">
                            <!-- Start Header Information List  -->
                            <div class="header-info">
                                <ul class="rbt-information-list">

                                    <li>
                                        <a href="#"><i class="feather-mail"></i>rtijsr@gmail.com </a>
                                    </li>
                                    <li>
                                        <a href="tel:+919334617411"><i class="feather-phone"></i>+91-9334617411</a>
                                    </li>
                                </ul>
                            </div>
                            <!-- End Header Information List  -->
                        </div>
                    </div>
                    <div class="rbt-header-sec-col rbt-header-center  d-none d-xl-block">
                        <div class="rbt-header-content justify-content-start justify-content-xl-center">
                            <div class="header-info">
                                <div class="rbt-header-top-news">
                                    <div class="inner">
                                        <div class="content">
                                            <span
                                                class="rbt-badge variation-02 bg-color-primary color-white radius-round">Hurry
                                                Up!</span>
                                            <span class="news-text"><img src="assets/images/icons/hand-emojji.svg"
                                                    alt="Hand Emojji Images"> Admission Open Get 10% Off.</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rbt-header-sec-col rbt-header-right mt_md--10 mt_sm--10">
                        <div class="rbt-header-content justify-content-start justify-content-lg-end">
                            <div class="header-info d-none d-xl-block">
                                <ul class="social-share-transparent">
                                    <li>
                                        <a href="https://www.instagram.com/rtijsr/" target="_blank"><i
                                                class="fab fa-instagram"></i></a>
                                    </li>
                                    <li>
                                        <a href="https://www.facebook.com/RashtriyaTechnicalInstitute"
                                            target="_blank"><i class="fab fa-facebook-f"></i></a>
                                    </li>
                                    <li>
                                        <a href="https://www.youtube.com/channel/UCYiMzP2RdpsVoarudkD35xA"
                                            target="_blank"><i class="fab fa-youtube"></i></a>
                                    </li>
                                    <li>
                                        <a href="https://www.linkedin.com/company/rtijsr/" target="_blank"><i
                                                class="fab fa-linkedin"></i></a>
                                    </li>
                                </ul>
                            </div>




                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End Header Top  -->
    <div class="rbt-header-wrapper header-space-betwween header-sticky">
        <div class="container-fluid">
            <div class="mainbar-row rbt-navigation-center align-items-center">
                <div class="header-left rbt-header-content">
                    <div class="header-info">
                        <div class="logo logo-dark">
                            <a href="index.php">
                                <img src="assets/images/logo/logo.png" alt="Logo">
                            </a>
                        </div>


                    </div>

                </div>



                <div class="rbt-main-navigation d-none d-xl-block">
                    <nav class="mainmenu-nav">
                        <ul class="mainmenu">
                            <li class="with-megamenu has-menu-child-item position-static">
                                <a href="index.php">Home</a>

                            </li>


                            <li class="has-dropdown has-menu-child-item">
                                <a href="about-us.php">
                                    About
                                    <i class="feather-chevron-down"></i>
                                </a>
                                <ul class="submenu">
                                    <li class="has-dropdown">
                                        <a href="about-us.php">About Institute</a>
                                        <a href="directors-desk.php">Director's Desk</a>

                                    </li>

                                </ul>
                            </li>



                            <li class="with-megamenu has-menu-child-item position-static menu-item-open">
                                <a href="#">Courses <i class="feather-chevron-down"></i></a>
                                <!-- Start Mega Menu  -->
                                <div class="rbt-megamenu grid-item-4">
                                    <div class="wrapper">
                                        <div class="row row--15">
                                            <div class="col-lg-12 col-xl-3 col-xxl-3 single-mega-item">
                                                <h3 class="rbt-short-title"><a href="operating-courses.php"> Operating
                                                        Courses </a></h3>
                                                <ul class="mega-menu-item">
                                                    <li><a href="mobile-crane-operator-course.php">Mobile Crane Operator Course</a></li>
                                                    <li><a href="excavator-operator-course.php">Excavator Operator Course</a></li>
                                                    <li><a href="forklift-operator-course.php">Forklift Operator Course</a></li>
                                                    <li><a href="jcb-operator-course.php">JCB Operator Course</a></li>
                                                    <li><a href="tower-crane-operator-course.php">Tower Crane Course</a></li>
                                                    <li><a href="hydra-crane-operator-course.php">Hydra Crane Operator Course</a></li>

                                                    <div class="rbt-card-bottom mt-2">

                                                        <a class="rbt-btn-link text-center"
                                                            href="operating-courses.php">
                                                            View
                                                            More<i class="feather-arrow-right"></i>
                                                        </a>
                                                    </div>


                                                </ul>
                                            </div>


                                            <div class="col-lg-12 col-xl-3 col-xxl-3 single-mega-item">
                                                <h3 class="rbt-short-title">
                                                    <a href="technical-courses.php">
                                                        Technical Courses
                                                    </a>
                                                </h3>
                                                <ul class="mega-menu-item">
                                                    <li><a href="hvac-technician-course.php">HVAC Technician Course</a></li>
                                                    <li><a href="instrument-technician-course.php">Instrument Technician Course</a></li>
                                                    <li><a href="electrician-course.php">Electrician Course</a></li>
                                                    <li><a href="quality-controller-course.php">Quality Controller Course</a></li>
                                                    <li><a href="ndt-level-2-course.php">NDT Level 2 Course</a></li>
                                                    <li><a href="building-management-system-course.php">Building Management System Course</a></li>
                                                    <li><a href="land-surveyor-course.php">Land Surveyor Course</a></li>
                                                    <li><a href="plc-scada-training.php">PLC and Scada Course</a></li>
                                                    <div class="rbt-card-bottom mt-2">

                                                        <a class="rbt-btn-link" href="technical-courses.php">
                                                            View
                                                            More<i class="feather-arrow-right"></i>
                                                        </a>
                                                    </div>
                                                </ul>
                                            </div>
                                            <div class="col-lg-12 col-xl-2 col-xxl-2 single-mega-item">
                                                <h3 class="rbt-short-title"> <a href="welding-courses.php">Welding
                                                        Courses</a></h3>
                                                <ul class="mega-menu-item">
                                                    <li><a href="arc-welding-course.php"> Arc Welding Course</a></li>
                                                    <li><a href="argon-welding-course.php"> Argon Welding Course</a>
                                                    </li>
                                                    <li><a href="arc-argon-welding-course.php"> Arc/Argon Welding
                                                            Course</a></li>
                                                    <li><a href="mig-welding-course.php"> Mig Welding Course</a></li>
                                                    <div class="rbt-card-bottom mt-2">

                                                        <a class="rbt-btn-link" href="welding-courses.php">
                                                            View
                                                            More<i class="feather-arrow-right"></i>
                                                        </a>
                                                    </div>
                                                </ul>
                                            </div>

                                            <div class="col-lg-12 col-xl-2 col-xxl-2 single-mega-item">
                                                <h3 class="rbt-short-title"><a href="safety-courses.php">Safety
                                                        Courses</a></h3>
                                                <ul class="mega-menu-item">
                                                    <li><a href="industrial-safety-training-course.php">Industrial Safety Course</a></li>
                                                    <div class="rbt-card-bottom mt-2">

                                                        <a class="rbt-btn-link" href="safety-courses.php">
                                                            View
                                                            More<i class="feather-arrow-right"></i>
                                                        </a>
                                                    </div>

                                                </ul>
                                            </div>

                                            <div class="col-lg-12 col-xl-2 col-xxl-2 single-mega-item">
                                                <h3 class="rbt-short-title"><a href="other-courses.php">Other
                                                        Courses</a></h3>
                                                <ul class="mega-menu-item">
                                                    <li><a href="pipe-fitter-fabricator-training-course.php"> Pipe Fitter Course</a></li>
                                                    <li><a href="millwright-fitter-training-course.php"> Millwright Fitter Course</a></li>
                                                    <li><a href="material-management-training-course.php"> Material Management Course</a></li>
                                                    <li><a href="mechanical-technician-training-course.php"> Mechanical Course</a></li>
                                                    <li><a href="quantity-surveyor-training-course.php">Quantity Surveyor Course</a></li>
                                                    <li><a href="auto-cad-training-course.php"> Auto Draftsman Course</a></li>
                                                    <li><a href="civil-qc-training-course.php"> Civil QC Course</a></li>

                                                    <div class="rbt-card-bottom mt-2 text-center">

                                                        <a class="rbt-btn-link" href="other-courses.php">
                                                            View
                                                            More<i class="feather-arrow-right"></i>
                                                        </a>
                                                    </div>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Mega Menu  -->
                            </li>


                            <li class="with-megamenu has-menu-child-item position-static">
                                <a href="admission.php">Admission</a>

                            </li>


                            <li class="has-dropdown has-menu-child-item">
                                <a href="placement.php">
                                Placements
                                    <i class="feather-chevron-down"></i>
                                </a>
                                <ul class="submenu">
                                    <li class="has-dropdown">
                                        <a href="placement.php">Student Placement</a>
                                        <a href="video-placement.php">Video Placement </a>

                                    </li>

                                </ul>
                            </li>

            
                            <li class="with-megamenu has-menu-child-item position-static">
                                <a href="facilities.php">Facilities</a>

                            </li>


                            <li class="has-dropdown has-menu-child-item">
                                <a href="#">
                                    Gallery
                                    <i class="feather-chevron-down"></i>
                                </a>
                                <ul class="submenu">
                                    <li class="has-dropdown">
                                        <a href="student-gallery.php">Student Gallery</a>
                                        <a href="video-gallery.php">Video Gallery</a>

                                    </li>

                                </ul>
                            </li>



                            <li class="has-dropdown has-menu-child-item">
                                <a href="testimonial.php">
                                Testimonial
                                    <i class="feather-chevron-down"></i>
                                </a>
                                <ul class="submenu">
                                    <li class="has-dropdown">
                                        <a href="testimonial.php">Student Testimonial</a>
                                        <a href="video-testimonial.php">Video Testimonial</a>

                                    </li>

                                </ul>
                            </li>

                        

                            <li class="with-megamenu has-menu-child-item position-static">
                                <a href="contact.php">Contact</a>

                            </li>


                        </ul>
                    </nav>
                </div>

                <div class="header-right">

                    <!-- Navbar Icons -->


                    <div class="rbt-btn-wrapper d-none d-xl-block">

                        <div class="rbt-button-group">
                            <a class="rbt-moderbt-btn" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                <span class="moderbt-btn-text">Enquire Now</span>
                                <i class=""></i>
                            </a>




                        </div>
                    </div>

                    <!-- Start Mobile-Menu-Bar -->
                    <div class="mobile-menu-bar d-block d-xl-none">
                        <div class="hamberger">
                            <button class="hamberger-button rbt-round-btn">
                                <i class="feather-menu"></i>
                            </button>
                        </div>
                    </div>
                    <!-- Start Mobile-Menu-Bar -->

                </div>
            </div>
        </div>

    </div>

    <a class="rbt-close_side_menu" href="javascript:void(0);"></a>

</header>

<!-- Mobile Menu Section -->
<div class="popup-mobile-menu">
    <div class="inner-wrapper">
        <div class="inner-top">
            <div class="content">
                <div class="logo">
                    <div class="logo logo-dark">
                        <a href="index.php">
                            <img src="assets/images/logo/logo.png" alt="Logo">
                        </a>
                    </div>


                </div>

            </div>

        </div>

        <nav class="mainmenu-nav">
            <ul class="mainmenu">
                <li class="">
                    <a href="index.php">Home</a>

                </li>

                <li class="has-dropdown has-menu-child-item">
                    <a href="about-us.php">
                        About

                    </a>
                    <ul class="submenu">
                        <li class="">
                            <a href="about-us.php">About Institute</a>
                            <a href="directors-desk.php">Director's Desk</a>

                        </li>

                    </ul>
                </li>



                <li class="with-megamenu has-menu-child-item position-static menu-item-open">
                    <a href="#">Courses <i class="feather-chevron-down"></i></a>
                    <!-- Start Mega Menu  -->
                    <div class="rbt-megamenu grid-item-4">
                        <div class="wrapper">
                            <div class="row row--15">
                                <div class="col-lg-12 col-xl-3 col-xxl-3 single-mega-item">
                                    <h3 class="rbt-short-title"><a href="operating-courses.php"> Operating Courses </a>
                                    </h3>
                                    <ul class="mega-menu-item">
                                        <li><a href="mobile-crane-operator-course.php">Mobile Crane Operator Course</a>
                                        </li>
                                        <li><a href="excavator-operator-course.php">Excavator Operator Course</a>
                                        </li>
                                        <li><a href="tower-crane-operator-course.php">Tower Crane Operator Course</a>
                                        </li>
                                        <li><a href="jcb-operator-course.php">JCB Operator Course</a></li>
                                        <li><a href="hydra-crane-operator-course.php">Hydra Crane Operator Course</a>
                                        </li>
                                        <li><a href="forklift-operator-course.php">Forklift Operator Course</a></li>

                                        <div class="rbt-card-bottom mt-2">

                                            <a class="rbt-btn-link" href="operating-courses.php">
                                                View
                                                More<i class="feather-arrow-right"></i>
                                            </a>
                                        </div>
                                    </ul>
                                </div>

                                <div class="col-lg-12 col-xl-3 col-xxl-3 single-mega-item">
                                    <h3 class="rbt-short-title">
                                        <a href="technical-courses.php">
                                            Technical Courses
                                        </a>
                                    </h3>
                                    <ul class="mega-menu-item">
                                        <li><a href="hvac-technician-course.php">HVAC Technician Course</a></li>
                                        <li><a href="instrument-technician-course.php">Instrument Technician Course</a>
                                        </li>
                                        <li><a href="electrician-course.php">Electrician Course</a></li>
                                        <li><a href="quality-controller-course.php">Quality Controller Course</a></li>
                                        <li><a href="ndt-level-2-course.php">NDT Level 2 Course</a></li>
                                        <li><a href="building-management-system-course.php">Building Management System
                                                Course</a></li>
                                        <li><a href="land-surveyor-course.php">Land Surveyor Course</a></li>
                                        <li><a href="plc-scada-training.php">PLC and Scada Course</a></li>
                                        <div class="rbt-card-bottom mt-2">

                                            <a class="rbt-btn-link" href="technical-courses.php">
                                                View
                                                More<i class="feather-arrow-right"></i>
                                            </a>
                                        </div>
                                    </ul>
                                </div>
                                <div class="col-lg-12 col-xl-3 col-xxl-3 single-mega-item">
                                    <h3 class="rbt-short-title"> <a href="welding-courses.php">Welding Courses</a></h3>
                                    <ul class="mega-menu-item">
                                        <li><a href="arc-welding-course.php"> Arc Welding Course</a></li>
                                        <li><a href="argon-welding-course.php"> Argon Welding Course</a></li>
                                        <li><a href="arc-argon-welding-course.php"> Arc & Argon Welding Course</a></li>
                                        <li><a href="mig-welding-course.php"> Mig Welding Course</a></li>

                                        <div class="rbt-card-bottom mt-2">

                                            <a class="rbt-btn-link" href="welding-courses.php">
                                                View
                                                More<i class="feather-arrow-right"></i>
                                            </a>
                                        </div>
                                    </ul>
                                </div>

                                <div class="col-lg-12 col-xl-3 col-xxl-3 single-mega-item">
                                    <h3 class="rbt-short-title"><a href="safety-courses.php">Safety Courses</a></h3>
                                    <ul class="mega-menu-item">

                                        <li><a href="industrial-safety-training-course.php"> Industrial Safety
                                                Course</a></li>

                                        <div class="rbt-card-bottom mt-2">

                                            <a class="rbt-btn-link" href="safety-courses.php">
                                                View
                                                More<i class="feather-arrow-right"></i>
                                            </a>
                                        </div>
                                    </ul>
                                </div>



                                <div class="col-lg-12 col-xl-3 col-xxl-3 single-mega-item">
                                    <h3 class="rbt-short-title"><a href="other-courses.php">Other Courses</a></h3>
                                    <ul class="mega-menu-item">
                                        <li><a href="pipe-fitter-fabricator-training-course.php"> Pipe Fitter Course</a>
                                        </li>
                                        <li><a href="millwright-fitter-training-course.php"> Millwright Fitter
                                                Course</a></li>
                                        <li><a href="material-management-training-course.php"> Material Management
                                                Course</a></li>
                                        <li><a href="mechanical-technician-training-course.php"> Mechanical Technician
                                                Course</a></li>
                                        <li><a href="quantity-surveyor-training-course.php"> Quantity Surveyor
                                                Course</a></li>
                                        <li><a href="auto-cad-training-course.php"> Auto Draftsman Course</a></li>
                                        <li><a href="civil-qc-training-course.php"> Civil QC Course</a></li>

                                        <div class="rbt-card-bottom mt-2">

                                            <a class="rbt-btn-link" href="other-courses.php">
                                                View
                                                More<i class="feather-arrow-right"></i>
                                            </a>
                                        </div>
                                    </ul>
                                </div>





                            </div>
                        </div>
                    </div>
                    <!-- End Mega Menu  -->
                </li>

                <li class="">
                    <a href="admission.php">Admission</a>

                </li>


                <li class="has-dropdown has-menu-child-item">
                                <a href="placement.php">
                                Placements
                               
                                </a>
                                <ul class="submenu">
                                    <li class="">
                                        <a href="placement.php">Student Placement</a>
                                        <a href="video-placement.php">Video Placement </a>

                                    </li>

                                </ul>
                            </li>


                <li class="">
                    <a href="facilities.php">Facilities</a>

                </li>
                <li class="has-dropdown has-menu-child-item">
                    <a href="#">
                        Gallery

                    </a>
                    <ul class="submenu">
                        <li class="">
                            <a href="student-gallery.php">Student Gallery</a>
                            <a href="video-gallery.php">Video Gallery</a>

                        </li>

                    </ul>
                </li>


                <li class="has-dropdown has-menu-child-item">
                                <a href="testimonial.php">
                                Testimonial
                                 
                                </a>
                                <ul class="submenu">
                                    <li class="">
                                        <a href="testimonial.php">Student Testimonial</a>
                                        <a href="video-testimonial.php">Video Testimonial</a>

                                    </li>

                                </ul>
                            </li>

                <li class="">
                    <a href="contact.php">Contact Us</a>

                </li>


            </ul>
        </nav>

        <div class="mobile-menu-bottom">
            <div class="rbt-btn-wrapper mb--20">
                <div class="rbt-button-group">

                    <a class="rbt-btn" href="tel:+919334617411">Call Now +91-9334617411</a>
                </div>
            </div>

            <div class="social-share-wrapper">
                <span class="rbt-short-title d-block text-center">Follow Us on Social Media</span>
                <ul class="social-icon social-default transparent-with-border justify-content-start mt--20">
                    <li>
                        <a href="https://www.instagram.com/rtijsr/" target="_blank"> <i
                                class="feather-instagram"></i></a>
                    </li>
                    <li>
                        <a href="https://www.facebook.com/RashtriyaTechnicalInstitute" target="_blank"><i
                                class="feather-facebook"></i></a>
                    </li>
                    <li>
                        <a href="https://www.youtube.com/channel/UCYiMzP2RdpsVoarudkD35xA" target="_blank"><i
                                class="feather-youtube"></i></a>
                    </li>
                    <li>
                        <a href="https://www.linkedin.com/company/rtijsr/" target="_blank"><i
                                class="feather-linkedin"></i></a>
                    </li>
                </ul>
            </div>
        </div>

    </div>
</div>



<a class="close_side_menu" href="javascript:void(0);"></a>