<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Home</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">

    <!-- CSS
    ============================================ -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/slick.css">
    <link rel="stylesheet" href="assets/css/vendor/slick-theme.css">
    <link rel="stylesheet" href="assets/css/plugins/sal.css">
    <link rel="stylesheet" href="assets/css/plugins/feather.css">
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/plugins/euclid-circulara.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper.css">
    <link rel="stylesheet" href="assets/css/plugins/odometer.css">
    <link rel="stylesheet" href="assets/css/plugins/animation.css">
    <link rel="stylesheet" href="assets/css/plugins/bootstrap-select.min.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/plugins/magnigy-popup.min.css">
    <link rel="stylesheet" href="assets/css/plugins/plyr.css">
    <link rel="stylesheet" href="assets/css/plugins/jodit.min.css" />

    <link rel="stylesheet" href="assets/css/styles.css">

    <style>


.plan-offer-list li {
    font-size: 15px;
    margin: 5px;
    text-align: justify;
}


ul.testimonial-thumb-wrapper li{
        padding-left: 15px;
    padding-right: 15px;
    flex-basis: 20.33%;
    margin-bottom: 30px;
    outline: none;
    cursor: pointer;
    margin-top: 0;
}


@media only screen and (max-width: 767px) {
    ul.testimonial-thumb-wrapper li {
        flex-basis: 47.33%;
        margin-bottom: 14px;
        padding-left: 7px;
        padding-right: 7px;
    }
}
    </style>
</head>


<body class="rbt-header-sticky">


    <?php include 'header.php' ?>







    <div class="rbt-slider-main-wrapper position-relative">
        <!-- Start Banner Area  -->
        <div class="swiper rbt-banner-activation rbt-slider-animation rbt-arrow-between">
            <div class="swiper-wrapper">
                <!-- Start Single Banner  -->
                <div class="swiper-slide">
                    <div class="rbt-banner-area rbt-banner-6 variation-03 bg_image bg_image--17" data-black-overlay="5">
                        <div class="wrapper w-100">
                            <div class="container">
                                <div class="row align-items-center">
                                    <div class="col-lg-12">
                                        <div class="inner text-center">
                                            <div class="section-title">
                                               
                                            </div>
                                            <h1 class="title w-700">
                                            
                                            </h1>
                                            <div class="button-group mt--30">
                                              
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Banner  -->



                <div class="swiper-slide">
                    <div class="rbt-banner-area rbt-banner-6 variation-03 bg_image bg_image--2" data-black-overlay="5">
                        <div class="wrapper w-100">
                            <div class="container">
                                <div class="row align-items-center">
                                    <div class="col-lg-12">
                                        <div class="inner text-center">
                                            <div class="section-title">
                                               
                                            </div>
                                            <h1 class="title w-700">
                                            
                                            </h1>
                                            <div class="button-group mt--30">
                                              
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



                <div class="swiper-slide">
                    <div class="rbt-banner-area rbt-banner-6 variation-03 bg_image bg_image--3" data-black-overlay="5">
                        <div class="wrapper w-100">
                            <div class="container">
                                <div class="row align-items-center">
                                    <div class="col-lg-12">
                                        <div class="inner text-center">
                                            <div class="section-title">
                                               
                                            </div>
                                            <h1 class="title w-700">
                                            
                                            </h1>
                                            <div class="button-group mt--30">
                                              
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Start Single Banner  -->
                <div class="swiper-slide">
                    <div class="rbt-banner-area rbt-banner-6 variation-03 bg_image bg_image--21" data-black-overlay="5">
                        <div class="wrapper w-100">
                            <div class="container">
                                <div class="row align-items-center">
                                    <div class="col-lg-12">
                                        <div class="inner text-center">
                                            <div class="section-title">
                                               
                                            </div>
                                            <h1 class="title w-700">
                                            
                                            </h1>
                                            <div class="button-group mt--30">
                                              
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Banner  -->
             

            </div>

            <div class="rbt-swiper-arrow rbt-arrow-left" tabindex="0" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-ce3ad5e43510a10650" aria-disabled="false">
                <div class="custom-overfolow">
                    <i class="rbt-icon feather-arrow-left"></i>
                    <i class="rbt-icon-top feather-arrow-left"></i>
                </div>
            </div>

            <div class="rbt-swiper-arrow rbt-arrow-right">
                <div class="custom-overfolow">
                    <i class="rbt-icon feather-arrow-right"></i>
                    <i class="rbt-icon-top feather-arrow-right"></i>
                </div>
            </div>

        </div>

        <div class="swiper rbt-swiper-thumb rbtmySwiperThumb">
            <div class="swiper-wrapper">

            </div>
        </div>
        <!-- End Banner Area  -->
    </div>





    <!-- Start About  -->

    <div class="rbt-about-area about-style-1  rbt-section-gapTop">
        <div class="container">
            <div class="row g-5 align-items-center">
                <div class="col-lg-5">
                    <div class="thumbnail-wrapper">
                        <div class="thumbnail image-1">
                            <img data-parallax="{&quot;x&quot;: 0, &quot;y&quot;: -20}"
                                src="assets/images/about/about.jpg" alt="Education Images"
                                style="transform:translate3d(0px, -20px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); -webkit-transform:translate3d(0px, -20px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); transform:translate3d(0px, -20px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); -webkit-transform:translate3d(0px, -20px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); ">
                        </div>
                        <div class="thumbnail image-2 d-none d-xl-block">
                            <img data-parallax="{&quot;x&quot;: 0, &quot;y&quot;: 60}"
                                src="assets/images/about/about-3.png" alt="Education Images"
                                style="transform:translate3d(0px, 60px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); -webkit-transform:translate3d(0px, 60px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); transform:translate3d(0px, 60px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); -webkit-transform:translate3d(0px, 60px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); ">
                        </div>
                        <div class="thumbnail image-3 d-none d-md-block">
                            <img data-parallax="{&quot;x&quot;: 0, &quot;y&quot;: 80}"
                                src="assets/images/about/about-1.jpg" alt="Education Images"
                                style="transform:translate3d(0px, 80px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); -webkit-transform:translate3d(0px, 80px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); transform:translate3d(0px, 47.778px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); -webkit-transform:translate3d(0px, 47.778px, 0px) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scaleX(1) scaleY(1) scaleZ(1); ">
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="inner pl--50 pl_sm--0 pl_md--0">
                        <div class="section-title text-start mt-4">

                            <h2 class="title">Rashtriya Technical Institute</h2>
                        </div>





                        <p class="description mt--30">
                            Rashtriya Technical Institute (RTI) has taken up the challenge for the development of the
                            skilled workforce in an era of rapid economic and technological changes by imparting the
                            intensive training in various branches of technical courses.
                            RTI has designed various job oriented short-term courses keeping in mind the qualification
                            and ability of students. So that they can consume the opportunity in the industrializing
                            global market.
                        </p>
                        <p>
                            You are co-orderly invited to get Admission, All Courses are Job Oriented with placement
                            assistance.<br> देश और विदेश में नौकरी पाने के लिए काम सीखे RTI has designed various job
                            oriented short-term courses keeping in mind the qualification and ability of students.
                        </p>
                        <!-- Start Feature List  -->
                        <div class="rbt-feature-wrapper mt--40">

                            <div class="rbt-feature feature-style-1">
                                <div class="icon bg-pink-opacity">
                                    <i class="feather-heart"></i>
                                </div>
                                <div class="feature-content">
                                    <h6 class="feature-title">Established 2006</h6>
                                    <p class="feature-description">
                                    We are the best Technical Institute
                                    </p>
                                </div>
                            </div>

                            <div class="rbt-feature feature-style-1">
                                <div class="icon bg-primary-opacity">
                                    <i class="feather-book"></i>
                                </div>
                                <div class="feature-content">
                                    <h6 class="feature-title">100% Practical Training</h6>
                                    <p class="feature-description">We focus on skill development</p>
                                </div>
                            </div>

                            <div class="rbt-feature feature-style-1">
                                <div class="icon bg-coral-opacity">
                                    <i class="feather-monitor"></i>
                                </div>
                                <div class="feature-content">
                                    <h6 class="feature-title">Experienced  Trainer</h6>
                                    <p class="feature-description"> We have highly professional trainers</p>
                                </div>
                            </div>
                        </div>

                        <!-- End Feature List  -->
                        <div class="about-btn mt--40">
                            <a class="rbt-btn btn-gradient hover-icon-reverse" href="about-us.php">
                                <span class="icon-reverse-wrapper">
                                    <span class="btn-text">More About Us</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- End About  -->

    <br />




    <!-- Vision Mission  -->
    <div class="rbt-become-area rbt-section-gap bg-color-extra2 ">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="title text-center">
                        Read Our
                        <span class="header-caption">
                            <span class="cd-headline clip is-full-width">
                                <span class="cd-words-wrapper" style="width: 232px;">
                                    <b class="theme-gradient is-hidden">Mission.</b>
                                    <b class="theme-gradient is-visible">Vission.</b>
                                    <b class="theme-gradient is-hidden">Planning.</b>
                                </span>
                            </span>
                        </span>
                    </h2>
                </div>
            </div>

            <div class="row row row--30">

                <div class="col-lg-12 mt_md--40 mt_sm--40 order-2 order-lg-1">
                    <div class="advance-tab-button">
                        <ul class="nav nav-tabs tab-button-style-2" id="myTab-4" role="tablist">
                            <li role="presentation">
                                <a href="#" class="tab-button" id="home-tab-4" data-bs-toggle="tab"
                                    data-bs-target="#home-4" role="tab" aria-controls="home-4" aria-selected="false">
                                    <span class="title">Our Mission</span>
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="#" class="tab-button" id="profile-tab-4" data-bs-toggle="tab"
                                    data-bs-target="#profile-4" role="tab" aria-controls="profile-4"
                                    aria-selected="false">
                                    <span class="title">Our Vision</span>
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="#" class="tab-button active" id="contact-tab-4" data-bs-toggle="tab"
                                    data-bs-target="#contact-4" role="tab" aria-controls="contact-4"
                                    aria-selected="true">
                                    <span class="title">Our Planning</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content advance-tab-content-style-2">
                        <div class="tab-pane fade" id="home-4" role="tabpanel" aria-labelledby="home-tab-4">

                            <div class="content">
                                <p>
                                To become a premier institution recognized for cultivating technical expertise, fostering innovation, and inspiring lifelong learning, making a positive impact on individuals, industries, and communities.
                                </p>
                            </div>

                        </div>


                        <div class="tab-pane fade" id="profile-4" role="tabpanel" aria-labelledby="profile-tab-4">
                            <div class="content">
                                <p>
                                Our mission is to deliver high-quality technical education that bridges the gap between academic knowledge and real-world application. By fostering a culture of excellence and inclusion, we strive to prepare students to meet the demands of an ever-evolving workforce and to thrive in diverse career paths.
                                </p>
                            </div>
                        </div>
                        <div class="tab-pane fade active show" id="contact-4" role="tabpanel"
                            aria-labelledby="contact-tab-4">
                            <div class="content">
                                <p>
                                As we grow, our goals include expanding partnerships with industry and academia, enhancing research and innovation opportunities, and incorporating advanced technology and teaching methods to further elevate the learning experience. Through these initiatives, we aspire to shape a future where our graduates are not only job-ready but also future-ready
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <br />
    </div>







    <br />

    <!-- Start course  -->


    <div class="rbt-course-area rbt-section-gap">
        <div class="container">
            <div class="row mb--60 g-5 align-items-end">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="section-title text-start text-center">
                        <h2 class="title">Our Courses</h2>
                        <p class="description mt--20">

                        Rashtriya Institute is providing career oriented courses for all the students, After completion of course You can get Job in India and Abroad.
</p>
                    </div>
                </div>

            </div>
            <!-- Start Card Area -->
            <div class="row g-5 justify-content-center">
                <!-- Start Single Card  -->
                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="operating-courses.php">
                                <img src="assets/images/course/mobile-crane.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="operating-courses.php">Operating Courses</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> 12 Courses</li>
                                <li><i class="feather-users"></i>60 Seats</li>

                            </ul>
                            <p class="rbt-card-text">
                            Our Operating Courses equip students with essential skills in managing, troubleshooting, and securing.
                            </p>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="operating-courses.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Card  -->
                <!-- Start Single Card  -->
                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="welding-courses.php">
                                <img src="assets/images/course/welding.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="welding-courses.php">Welding Courses</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> 4 Courses</li>
                                <li><i class="feather-users"></i>60 Seats</li>

                            </ul>
                            <p class="rbt-card-text">
                            Our Welding Courses equip students with essential hands-on skills in various welding techniques, including MIG, TIG, and arc welding
                            </p>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="welding-courses.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Card  -->
                <!-- Start Single Card  -->
                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="technical-courses.php">
                                <img src="assets/images/course/technical.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="technical-courses.php">Technical Courses</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> 16 Courses</li>
                                <li><i class="feather-users"></i>60 Seats</li>
                            </ul>
                            <p class="rbt-card-text">
                            Knowledge with practical, hands-on training, ensuring students gain the expertise to innovate, troubleshoot, and excel in technical roles
                            </p>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="technical-courses.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Card  -->
                <!-- Start Single Card  -->
                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="safety-courses.php">
                                <img src="assets/images/course/safety.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="safety-courses.php">Safety Courses</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> 2 Courses</li>
                                <li><i class="feather-users"></i>60 Seats</li>
                            </ul>
                            <p class="rbt-card-text">
                            Safety Courses provide students with the essential knowledge and skills required to maintain safe work environments across diverse industries.
                            </p>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="safety-courses.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="other-courses.php">
                                <img src="assets/images/course/other.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="other-courses.php">Other Courses</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> 6 Courses</li>
                                <li><i class="feather-users"></i>40 Students</li>
                            </ul>
                            <p class="rbt-card-text">
                            Our Other Courses offer specialized training in areas that support a well-rounded skillset, enhancing employability and personal growth
                            </p>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="other-courses.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Card  -->


            </div>
            <!-- End Card Area -->
        </div>
    </div>


    <!-- end course  -->

    <br />




    <!-- Start why choose  -->

    <div class="rbt-counterup-area rbt-section-gapBottom bg-color-extra2">
        <div class="container">
            <div class="row mb--60">
                <div class="col-lg-12">
                    <div class="section-title text-center">
                        <br />
                        <h2 class="title">Why Choose Us</h2>

                    </div>
                </div>
            </div>
            <div class="row g-5 hanger-line">
                <!-- Start Single Counter  -->
                <div class="col-lg-3 col-xl-2 col-md-6 col-sm-6 col-12">
                    <div class="rbt-counterup rbt-hover-03 border-bottom-gradient">
                        <div class="top-circle-shape"></div>
                        <div class="inner">
                            <div class="rbt-round-icon">
                                <img src="assets/images/icons/counter-01.png" alt="Icons Images">
                            </div>
                            <div class="content">

                                <span class="subtitle">18 Years of Excellence</span>
                         
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Counter  -->
                <!-- Start Single Counter  -->
                <div class="col-lg-3  col-xl-2 col-md-6 col-sm-6 col-12 mt--60 mt_md--30 mt_sm--30 mt_mobile--60">
                    <div class="rbt-counterup rbt-hover-03 border-bottom-gradient">
                        <div class="top-circle-shape"></div>
                        <div class="inner">
                            <div class="rbt-round-icon">
                                <img src="assets/images/icons/counter-02.png" alt="Icons Images">
                            </div>
                            <div class="content">
                                <span class="subtitle">Career Growth 	</span>
                                <span class="subtitle"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Counter  -->
                <!-- Start Single Counter  -->
                <div class="col-lg-3 col-xl-2 col-md-6 col-sm-6 col-12 mt_md--60 mt_sm--60">
                    <div class="rbt-counterup rbt-hover-03 border-bottom-gradient">
                        <div class="top-circle-shape"></div>
                        <div class="inner">
                            <div class="rbt-round-icon">
                                <img src="assets/images/icons/counter-03.png" alt="Icons Images">
                            </div>
                            <div class="content">
                                <span class="subtitle">	Placement Assistance</span>
                              

                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Counter  -->
                <!-- Start Single Counter  -->
                <div class="col-lg-3 col-xl-2 col-md-6 col-sm-6 col-12 mt--60 mt_md--30 mt_sm--30 mt_mobile--60">
                    <div class="rbt-counterup rbt-hover-03 border-bottom-gradient">
                        <div class="top-circle-shape"></div>
                        <div class="inner">
                            <div class="rbt-round-icon">
                                <img src="assets/images/icons/counter-04.png" alt="Icons Images">
                            </div>
                            <div class="content">
                                <span class="subtitle"> 100% Practical	</span>
                                <span class="subtitle"> </span>
                                <span class="subtitle"> </span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Counter  -->



                <div class="col-lg-3 col-xl-2 col-md-6 col-sm-6 col-12">
                    <div class="rbt-counterup rbt-hover-03 border-bottom-gradient">
                        <div class="top-circle-shape"></div>
                        <div class="inner">
                            <div class="rbt-round-icon">
                                <img src="assets/images/icons/counter-01.png" alt="Icons Images">
                            </div>
                            <div class="content">

                                <span class="subtitle">Experienced Teachers</span>
                         
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Counter  -->
                <!-- Start Single Counter  -->
                <div class="col-lg-3 col-xl-2 col-md-6 col-sm-6 col-12 mt--60 mt_md--30 mt_sm--30 mt_mobile--60">
                    <div class="rbt-counterup rbt-hover-03 border-bottom-gradient">
                        <div class="top-circle-shape"></div>
                        <div class="inner">
                            <div class="rbt-round-icon">
                                <img src="assets/images/icons/counter-02.png" alt="Icons Images">
                            </div>
                            <div class="content">
                                <span class="subtitle">Govt Registered	</span>
                                <span class="subtitle"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Start why choose  -->

    <br />

    <!-- Start facility  -->

    <div class="rbt-team-area rbt-section-gapBottom">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-12 mb--60">
                    <div class="section-title text-center">

                        <h2 class="title">Our Facilities</h2>
                        <p class="description mt--20">

                            Rashtriya Technical Institute provides a lot of facilities for all, also provide Mess and
                            Hostel facilities for all the students.
                        </p>
                    </div>
                </div>
            </div>
            <div class="row g-5 justify-content-center">


<div class="col-lg-3 col-12">
    <div class="rbt-team team-style-default style-three rbt-hover">
        <div class="inner">
            <div class="thumbnail">
                <img src="assets/images/service/lab.jpg" alt="Corporate Template">
            </div>
            <div class="content">

                <h6 class="subtitle theme-gradient"><b>Practical Lab</b> </h6>
                <span class="team-form">

                    <span class="location">

                      <ul class="plan-offer-list rbt-list-primary-opacity">
                        <li><i class="feather-check"></i>HVAC& AC Lab</li>
                        <li><i class="feather-check"></i> Instrument Lab</li>
                        <li><i class="feather-check"></i> 	Welding Lab</li>
                        <li><i class="feather-check"></i> NDT Lab</li>
                        <li><i class="feather-check"></i> 	CAD Lab</li>
                        <li><i class="feather-check"></i> Mechanical Lab</li>
                        <li><i class="feather-check"></i> Electrical Lab</li>
                        <li><i class="feather-check"></i> QC & QA Lab</li>
                        <li><i class="feather-check"></i> PLC & SCADA Lab</li>
                      </ul>
                    </span>
                </span>
            </div>
        </div>
    </div>
</div>


<div class="col-lg-3 col-12">
    <div class="rbt-team team-style-default style-three rbt-hover">
        <div class="inner">
            <div class="thumbnail">
                <img src="assets/images/service/hostel.jpg" alt="Corporate Template">
            </div>
            <div class="content">

                <h6 class="subtitle theme-gradient"><b>Well Infrastructure</b></h6>
                <span class="team-form">

                    <span class="location">
                    <ul class="plan-offer-list rbt-list-primary-opacity">
                        <li><i class="feather-check"></i>	AC Classroom</li>
                        <li><i class="feather-check"></i> Digital Classroom</li>
                        <li><i class="feather-check"></i> 	Own Vehicle</li>
                        <li><i class="feather-check"></i> All Equipment</li>
                        <li><i class="feather-check"></i> 	CAD Lab</li>
                        <li><i class="feather-check"></i> Own Transportation</li>
                        <li><i class="feather-check"></i> Medicals</li>
                     
                      </ul>
                    </span>
                </span>
            </div>
        </div>
    </div>
</div>



<div class="col-lg-3 col-12">
    <div class="rbt-team team-style-default style-three rbt-hover">
        <div class="inner">
            <div class="thumbnail">
                <img src="assets/images/service/career.jpg" alt="Corporate Template">
            </div>
            <div class="content">

                <h6 class="subtitle theme-gradient"><b>Career Development</b></h6>
                <span class="team-form">

                    <span class="location">

                    <ul class="plan-offer-list rbt-list-primary-opacity">
                        <li><i class="feather-check"></i>	Personality Development</li>
                        <li><i class="feather-check"></i> 	Group Discussion
                             </li>
                        <li><i class="feather-check"></i> Interview	Preparation</li>
                        <li><i class="feather-check"></i> Spoken English</li>
                        <li><i class="feather-check"></i> 	Sports functions</li>
                        <li><i class="feather-check"></i> Educational Games</li>
                        <li><i class="feather-check"></i> Industrial Visits</li>
                     
                      </ul>
                    </span>
                </span>
            </div>
        </div>
    </div>
</div>




<div class="col-lg-3 col-12">
    <div class="rbt-team team-style-default style-three rbt-hover">
        <div class="inner">
            <div class="thumbnail">
                <img src="assets/images/service/class.jpg" alt="Corporate Template">
            </div>
            <div class="content">

                <h6 class="subtitle theme-gradient"> <b>Mess & Hostel</b></h6>
                <span class="team-form">
                 
                    <span class="location">

                    Mess and Hostel Facilities for All the students.
                    </span>
                </span>
            </div>
        </div>
    </div>
</div>



</div>


            <div class="about-btn mt--40 text-center">
                <a class="rbt-btn btn-gradient hover-icon-reverse" href="facilities.php">
                    <span class="icon-reverse-wrapper">
                        <span class="btn-text">View All</span>
                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                    </span>
                </a>
            </div>
        </div>
    </div>


    <!-- end facility  -->


    <!-- start image  -->

    <div class="rbt-gallery-area bg-color-extra2">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-12 mb--60">
                    <div class="section-title text-center">

                        <h2 class="title">Our Gallery</h2>
                        <p class="description mt--20">

                            Rashtriya Technical Institute provides a lot of facilities for all, also provide Mess and
                            Hostel facilities for all the students.
                        </p>
                    </div>
                </div>
            </div>

            <div class="row parent-gallery-container">






                <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="assets/images/gallery/13.jpg" alt="Gallery Images">
                    </div>
                </a>

                <a href="assets/images/gallery/8.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="assets/images/gallery/8.jpg" alt="Gallery Images">
                    </div>
                </a>




                <a href="assets/images/gallery/11.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="assets/images/gallery/11.jpg" alt="Gallery Images">
                    </div>
                </a>

                <a href="assets/images/gallery/15.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="assets/images/gallery/15.jpg" alt="Gallery Images">
                    </div>
                </a>


            </div>

            <div class="about-btn mt--40 text-center">
                <a class="rbt-btn btn-gradient hover-icon-reverse" href="student-gallery.php">
                    <span class="icon-reverse-wrapper">
                        <span class="btn-text">View All</span>
                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                    </span>
                </a>
            </div>


            <br />


        </div>
    </div>
    <!-- end image  -->

<br>

    <!-- start video  -->
    <div class="rbt-gallery-area">

<div class="container">
        <div class="row g-5">
            <div class="col-lg-12 mb--60">
                <div class="section-title text-center">

                    <h2 class="title">Our Videos</h2>
                    <p class="description mt--20">

                    Explore our videos to see how our specialized training programs can transform your career
                    </p>
                </div>
            </div>
        </div>


        <div class="row parent-gallery-container">

        <a href="https://www.youtube.com/embed/2aWNkWLFsHI"
                class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
                <div class="rbt-gallery">
                    <iframe src="https://www.youtube.com/embed/2aWNkWLFsHI" title="YouTube video player"
                        style="width:100%!important; height:270px!important"></iframe>
                </div>
            </a>

            <a href="https://www.youtube.com/embed/zgHBdrBiRRQ"
                class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
                <div class="rbt-gallery">
                    <iframe src="https://www.youtube.com/embed/zgHBdrBiRRQ" title="YouTube video player"
                        style="width:100%!important; height:270px!important"></iframe>
                </div>
            </a>
           

            <a href="https://www.youtube.com/embed/NGygOSdaJI4"
                class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
                <div class="rbt-gallery">
                    <iframe src="https://www.youtube.com/embed/NGygOSdaJI4" title="YouTube video player"
                        style="width:100%!important; height:270px!important"></iframe>
                </div>
            </a>
            <a href="https://www.youtube.com/embed/FxOc_HwrAAg"
                class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
                <div class="rbt-gallery">
                    <iframe src="https://www.youtube.com/embed/FxOc_HwrAAg" title="YouTube video player"
                        style="width:100%!important; height:270px!important"></iframe>
                </div>
            </a>
        

        </div>
        <div class="row parent-gallery-container">

<a href="https://www.youtube.com/embed/a4CwohmQy6Q?si=hbrdrzzv2ay8_BLg"
        class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
        <div class="rbt-gallery">
            <iframe src="https://www.youtube.com/embed/a4CwohmQy6Q?si=hbrdrzzv2ay8_BLg" title="YouTube video player"
                style="width:100%!important; height:270px!important"></iframe>
        </div>
    </a>

    <a href="https://www.youtube.com/embed/0pqxz-meUfA?si=FjLTpQ70Ub9fAvL-"
        class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
        <div class="rbt-gallery">
            <iframe src="https://www.youtube.com/embed/0pqxz-meUfA?si=FjLTpQ70Ub9fAvL-" title="YouTube video player"
                style="width:100%!important; height:270px!important"></iframe>
        </div>
    </a>
   

    <a href="https://www.youtube.com/embed/-pFaG7y5lw8?si=ox8MWwqQTi53rk7l"
        class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
        <div class="rbt-gallery">
            <iframe src="https://www.youtube.com/embed/-pFaG7y5lw8?si=ox8MWwqQTi53rk7l" title="YouTube video player"
                style="width:100%!important; height:270px!important"></iframe>
        </div>
    </a>
    <a href="https://www.youtube.com/embed/K-zi2fX1UNA?si=FXIY2X5VVrl8zxZh"
        class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
        <div class="rbt-gallery">
            <iframe src="https://www.youtube.com/embed/K-zi2fX1UNA?si=FXIY2X5VVrl8zxZh" title="YouTube video player"
                style="width:100%!important; height:270px!important"></iframe>
        </div>
    </a>


        </div>

        <div class="about-btn mt--40 text-center">
                <a class="rbt-btn btn-gradient hover-icon-reverse" href="video-gallery.php">
                    <span class="icon-reverse-wrapper">
                        <span class="btn-text">View All</span>
                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                    </span>
                </a>
            </div>



        <br />


    </div>
    </div>
    <!-- end video  -->



 

   
    <!-- Start testimonial  -->
    <div class="rbt-testimonial-area bg-color-white  rbt-section-gap">

    <div class="testimonial-embed">
    <iframe src="https://7a0696201ffb4d9b84b1f020b4bda4d8.elf.site/" width="100%" height="600" style="border: none;"></iframe>
</div>
     
        <br />
    </div>

    <!-- End testimonial  -->




    <!--FAQ-->
    <div class="rbt-accordion-area accordion-style-1 rbt-section-gap">
        <div class="container">
            <div class="row mb--60">
                <div class="col-lg-12">
                    <div class="section-title text-center">

                        <h2 class="title">
                            Frequently Asked Questions?

                        </h2>
                    </div>
                </div>
            </div>
            <div class="row g-5 align-items-center">



                <div class="col-lg-7">
                    <div class="rbt-accordion-style rbt-accordion-01  accordion">
                        <div class="accordion" id="accordionExamplea1">

                            <div class="accordion-item card">
                                <h2 class="accordion-header card-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        Is Rashtriya Register By Govt ?

                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show"
                                    aria-labelledby="headingOne" data-bs-parent="#accordionExamplea1" style="">
                                    <div class="accordion-body card-body">
                                        Yes Rashtriya Technical Institute is Registered By Govt. of Jharkhand.
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item card">
                                <h2 class="accordion-header card-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        Is There Any Facilities For Mess And Hostel

                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                    data-bs-parent="#accordionExamplea1">
                                    <div class="accordion-body card-body">
                                        Yes, We are providing Mess and Hostel facilities for all the students.
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item card">
                                <h2 class="accordion-header card-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseThree" aria-expanded="false"
                                        aria-controls="collapseThree">
                                        Can I Get Job After Completion of Course ?

                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse"
                                    aria-labelledby="headingThree" data-bs-parent="#accordionExamplea1">
                                    <div class="accordion-body card-body">
                                        Yes, More Than 90% students have placed already, Some Reputed Companies Come For
                                        Campus Selection
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item card">
                                <h2 class="accordion-header card-header" id="headingFour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseFour" aria-expanded="false"
                                        aria-controls="collapseFour">
                                        Can I Get Practical Classes For This Course ?

                                    </button>
                                </h2>
                                <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                    data-bs-parent="#accordionExamplea1" style="">
                                    <div class="accordion-body card-body">
                                        Yes, 2 Month Theory And 1 Month Practical Classes. Students Get 100% Practical
                                        Training for all trade.
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-lg-5">
                    <div class="rbt-contact-form contact-form-style-1 max-width-auto">

                        <h4 class="title">Feel Free to Contact Us!</h4>
                        <form id="contact-form" method="POST" action="mail.php"
                            class="rainbow-dynamic-form max-width-auto">
                            <div class="form-group">
                                <input name="name" id="contact-name" type="text">
                                <label>Name</label>
                                <span class="focus-border"></span>
                            </div>
                            <div class="form-group">
                                <input name="mob" type="text">
                                <label>Mobile No</label>
                                <span class="focus-border"></span>
                            </div>

                            <div class="form-group">
                                <input name="course" type="text">
                                <label>Course Name</label>
                                <span class="focus-border"></span>
                            </div>




                            <div class="form-group">
                                <textarea name="msg" id="contact-message"></textarea>
                                <label>Message</label>
                                <span class="focus-border"></span>
                            </div>




                            <div class="form-submit-group">
                                <button name="submit" type="submit" id="submit"
                                    class="rbt-btn btn-md btn-gradient hover-icon-reverse w-100">
                                    <span class="icon-reverse-wrapper">
                                        <span class="btn-text">Submit</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!--End FAQ-->
    <!--Partners-->


    <div class="rbt-brand-area bg-color-white rbt-section-gap">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-12">
                    <div class="section-title text-center">

                        <h2 class="title">Our Recruiters </h2>
                        <p class="description mt--20 mb--20">

Rashtriya Technical Institute provides a lot of facilities for all, also provide Mess and
Hostel facilities for all the students.
</p>
                    </div>
                </div>
            </div>


    <!-- Start recruit  -->

             <div class="col-lg-12 mt--30">
                    <!-- Start Tab Nav  -->
                    <ul class="testimonial-thumb-wrapper nav nav-tabs" id="myTab" role="tablist">
                        <li>
                            <a id="testimonial-tab1-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab1" role="tab" aria-controls="testimonial-tab1" aria-selected="false" class="active">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/partners/aditya.png" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>





                        <li>
                            <a id="testimonial-tab2-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab2" role="tab" aria-controls="testimonial-tab2" aria-selected="false" class="active">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/partners/tata.jpg" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>

                        <li>
                            <a id="testimonial-tab3-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab3" role="tab" aria-controls="testimonial-tab3" aria-selected="false" class="active">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/partners/lt.png" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a id="testimonial-tab4-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab4" role="tab" aria-controls="testimonial-tab4" aria-selected="true" class="active">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/partners/voltas.png" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>

                        <li>
                            <a id="testimonial-tab5-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab5" role="tab" aria-controls="testimonial-tab5" aria-selected="false" class="active">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/partners/qatar.png" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>

                        <li>
                            <a id="testimonial-tab6-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab6" role="tab" aria-controls="testimonial-tab6" aria-selected="false" class="active">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/partners/tata2.jpg" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>

                        <li>
                            <a id="testimonial-tab7-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab7" role="tab" aria-controls="testimonial-tab7" aria-selected="false" class="active">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/partners/usha.jpg" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>

                        <li>
                            <a id="testimonial-tab8-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab8" role="tab" aria-controls="testimonial-tab8" aria-selected="false" class="active">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/partners/laf.png" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>


                        <li>
                            <a id="testimonial-tab8-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab8" role="tab" aria-controls="testimonial-tab8" aria-selected="false" class="active">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/partners/iic.jpg" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>


                        <li>
                            <a id="testimonial-tab8-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab8" role="tab" aria-controls="testimonial-tab8" aria-selected="false" class="active">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/partners/kk.jpg" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>


                        <li>
                            <a id="testimonial-tab8-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab8" role="tab" aria-controls="testimonial-tab8" aria-selected="false" class="active">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/partners/redis.png" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>


                        <li>
                            <a id="testimonial-tab8-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab8" role="tab" aria-controls="testimonial-tab8" aria-selected="false" class="active">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/partners/simplex.png" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>
                    </ul>
                    <!-- End Tab Content  -->
                </div>
                        
                  
                        <!-- End recruit -->





        </div>
        <br>
    </div>



    <!--End Partners-->



   




    <?php include 'footer.php' ?>




    <!-- JS
    ============================================ -->
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr.min.js"></script>
    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.min.js"></script>
    <!-- sal.js -->
    <script src="assets/js/vendor/sal.js"></script>
    <!-- Dark Mode Switcher -->
    <script src="assets/js/vendor/js.cookie.js"></script>
    <script src="assets/js/vendor/jquery.style.switcher.js"></script>
    <script src="assets/js/vendor/swiper.js"></script>
    <script src="assets/js/vendor/jquery-appear.js"></script>
    <script src="assets/js/vendor/odometer.js"></script>
    <script src="assets/js/vendor/backtotop.js"></script>
    <script src="assets/js/vendor/isotop.js"></script>
    <script src="assets/js/vendor/imageloaded.js"></script>

    <script src="assets/js/vendor/wow.js"></script>
    <script src="assets/js/vendor/waypoint.min.js"></script>
    <script src="assets/js/vendor/easypie.js"></script>
    <script src="assets/js/vendor/text-type.js"></script>
    <script src="assets/js/vendor/jquery-one-page-nav.js"></script>
    <script src="assets/js/vendor/bootstrap-select.min.js"></script>
    <script src="assets/js/vendor/jquery-ui.js"></script>
    <script src="assets/js/vendor/magnify-popup.min.js"></script>
    <script src="assets/js/vendor/paralax-scroll.js"></script>
    <script src="assets/js/vendor/paralax.min.js"></script>
    <script src="assets/js/vendor/countdown.js"></script>
    <script src="assets/js/vendor/plyr.js"></script>
    <script src="assets/js/vendor/jodit.min.js"></script>
    <script src="assets/js/vendor/Sortable.min.js"></script>



    <!-- Main JS -->
    <script src="assets/js/main.js"></script>
</body>

</html>