<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Other Courses</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">

    <!-- CSS
    ============================================ -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/slick.css">
    <link rel="stylesheet" href="assets/css/vendor/slick-theme.css">
    <link rel="stylesheet" href="assets/css/plugins/sal.css">
    <link rel="stylesheet" href="assets/css/plugins/feather.css">
    <link rel="stylesheet" href="assets/css/plugins/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/plugins/euclid-circulara.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper.css">
    <link rel="stylesheet" href="assets/css/plugins/odometer.css">
    <link rel="stylesheet" href="assets/css/plugins/animation.css">
    <link rel="stylesheet" href="assets/css/plugins/bootstrap-select.min.css">
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/plugins/magnigy-popup.min.css">
    <link rel="stylesheet" href="assets/css/plugins/plyr.css">
    <link rel="stylesheet" href="assets/css/plugins/jodit.min.css" />

    <link rel="stylesheet" href="assets/css/styles.css">

    <style>
        ul.testimonial-thumb-wrapper li {
            padding-left: 15px;
            padding-right: 15px;
            flex-basis: 20.33%;
            margin-bottom: 30px;
            outline: none;
            cursor: pointer;
            margin-top: 0;
        }


        @media only screen and (max-width: 767px) {
            ul.testimonial-thumb-wrapper li {
                flex-basis: 47.33%;
                margin-bottom: 14px;
                padding-left: 7px;
                padding-right: 7px;
            }
        }
    </style>
</head>

<body class="rbt-header-sticky active-light-mode">


    <?php include 'header.php' ?>

    <div class="rbt-page-banner-wrapper">
        <!-- Start Banner BG Image  -->
        <div class="rbt-banner-image"></div>
        <!-- End Banner BG Image  -->
        <div class="rbt-banner-content">

            <!-- Start Banner Content Top  -->
            <div class="rbt-banner-content-top">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-6 col-12">

                            <div class="content">

                                <h2 class="title">Other Courses!</h2>
                                <p class="description">
                                नंबर 1 ट्रेनिंग सेंटर और ISO प्रमाणित।
                                </p>





                             



                                <ul class="plan-offer-list rbt-list-primary-opacity grid-list">
                                    <li>
                                        <i class="feather-check"></i> <a href="pipe-fitter-fabricator-training-course.php">Pipe Fitter
                                            Training</a>
                                    </li>
                                    <li>
                                        <i class="feather-check"></i> <a href="millwright-fitter-training-course.php">Millwright
                                            Training</a>
                                    </li></a>
                                    <li> <i class="feather-check"></i> <a href="material-management-training-course.php">Material
                                            Management Training</a></li>

                                    <li> <i class="feather-check"></i> <a href="mechanical-technician-training-course.php"> Mechanical
                                            Technician training</a></li>
                                    <li> <i class="feather-check"></i> <a href="quantity-surveyor-training-course.php"> Quantity
                                            Surveyor Training</a></li>
                                    <li> <i class="feather-check"></i> <a href="auto-cad-training-course.php"> Auto Draftsman
                                            Training</a></li>


                                </ul>

                                <h5 class="mt-4">
                                    Admission Open, Limited Seats
                                    <br />
                                    नौकरी पाने के लिए काम सीखे
                                </h5>



                            </div>

                            <div class="row">
                                <div class="col-lg-7">


                                    <button name="submit" type="submit" id="submit"
                                        class="rbt-btn btn-md btn-gradient hover-icon-reverse w-100">
                                        <span class="icon-reverse-wrapper">
                                            <a class="btn-text text-white" href="tel:+919334617411">Call Us +91-9334617411
                                            </a>
                                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </button>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- End Banner Content Top  -->

            </div>
        </div>
    </div>






    <!-- Start course  -->


    <div class="rbt-course-area rbt-section-gap">
        <div class="container">
            <div class="row mb--60 g-5 align-items-end">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="section-title text-start text-center">
                        <h4 class="title">Other Training Courses</h4>

                    </div>
                </div>

            </div>
            <!-- Start Card Area -->
            <div class="row g-5">
                <!-- Start Single Card  -->
                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="course-details.php">
                                <img src="assets/images/course/pipe.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="pipe-fitter-fabricator-training-course.php">Pipe Fitter Course</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> <b>Duration</b> : 3 Months</li>
                                <li><i class="feather-award"></i> <b>Certified</b> : Yes</li>

                            </ul>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="pipe-fitter-fabricator-training-course.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>



                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="millwright-fitter-training-course.php">
                                <img src="assets/images/course/mill.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="millwright-fitter-training-course.php">Millwright Course</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> <b>Duration</b> : 3 Months</li>
                                <li><i class="feather-award"></i> <b>Certified</b> : Yes</li>

                            </ul>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="millwright-fitter-training-course.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>



                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="material-management-training-course.php">
                                <img src="assets/images/course/material.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="material-management-training-course.php"> Material
                                Management Course</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> <b>Duration</b> : 3 Months</li>
                                <li><i class="feather-award"></i> <b>Certified</b> : Yes</li>

                            </ul>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="material-management-training-course.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>





                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="mechanical-technician-training-course.php">
                                <img src="assets/images/course/mechanical.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="mechanical-technician-training-course.php">Mechanical
                                Technician Course</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> <b>Duration</b> : 3 Months</li>
                                <li><i class="feather-award"></i> <b>Certified</b> : Yes</li>

                            </ul>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="mechanical-technician-training-course.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>





                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="quantity-surveyor-training-course">
                                <img src="assets/images/course/quantity.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="quantity-surveyor-training-course"> Quantity
                                Surveyor Course</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> <b>Duration</b> : 3 Months</li>
                                <li><i class="feather-award"></i> <b>Certified</b> : Yes</li>

                            </ul>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="quantity-surveyor-training-course">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>




                <div class="col-lg-3 col-md-3 col-sm-3 col-12 sal-animate" data-sal-delay="150" data-sal="slide-up"
                    data-sal-duration="800">
                    <div class="rbt-card variation-01 rbt-hover">
                        <div class="rbt-card-img">
                            <a href="auto-cad-training-course.php">
                                <img src="assets/images/course/auto-cad.jpg" alt="Card image">

                            </a>
                        </div>
                        <div class="rbt-card-body">

                            <h4 class="rbt-card-title">
                                <a href="auto-cad-training-course.php">Auto Draftsman Course</a>
                            </h4>
                            <ul class="rbt-meta">
                                <li><i class="feather-book"></i> <b>Duration</b> : 3 Months</li>
                                <li><i class="feather-award"></i> <b>Certified</b> : Yes</li>

                            </ul>

                            <div class="rbt-card-bottom">

                                <a class="rbt-btn-link" href="auto-cad-training-course.php">
                                    View
                                    More<i class="feather-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>





                <!-- End Card Area -->
            </div>
        </div>

    </div>
    <!-- end course  -->



    <!-- Start testimonial  -->
  <div class="rbt-testimonial-area bg-color-white  rbt-section-gap">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 mb--60">
                    <div class="section-title text-center">
                        <h2 class="title">Student's Feedback</h2>
                        <p class="description mt--20">Some Valuable Reviews from our Students.</p>
                    </div>
                </div>
            </div>
            <div
                class="testimonial-item-3-activation swiper rbt-arrow-between gutter-swiper-30 swiper-initialized swiper-horizontal swiper-pointer-events swiper-backface-hidden">
                <div class="swiper-wrapper" id="swiper-wrapper-10a33b3de5a5d6958" aria-live="polite"
                    style="transform: translate3d(0px, 0px, 0px); transition-duration: 0ms;">









                    <!-- Start Single Testimonial  -->
                    <div class="swiper-slide swiper-slide-active" style="width: 445px;" role="group" aria-label="1 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Syed S. Alam </h5>
                                            <span class="subtitle">Student</span>
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                 
                                        The Quantity Surveyor Course at Rashtriya Institute has been a game-changer for me. The instructors are incredibly knowledgeable and bring real-world experience to the classroom, making the learning process engaging and practical. The hands-on training helped me apply the concepts I learned, and I now feel confident in my ability to take on projects in the construction industry.
                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->


                    <!-- Start Single Testimonial  -->
                    <div class="swiper-slide swiper-slide-active" style="width: 445px;" role="group" aria-label="1 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Aslam Ansari </h5>
                                            <span class="subtitle">Student</span>
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                 
                                 

                    Rashtriya Institute provided everything I needed to excel in the pipe fitting trade. The blend of theory and practical training gave me a solid foundation, and the instructors shared valuable insights from their industry experience. This course has opened doors to more job opportunities for me, and I highly recommend it to anyone serious about a career in pipe fitting.
                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->


                    
                    <!-- Start Single Testimonial  -->
                    <div class="swiper-slide swiper-slide-active" style="width: 445px;" role="group" aria-label="1 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Rohit Mehta </h5>
                                            <span class="subtitle">Student</span>
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                 
                                        I highly recommend the Millwright Fitter Training Course at Rashtriya Institute. The instructors made even complex topics easy to understand. The hands-on practice helped me develop critical skills, such as precision alignment and machinery assembly, which are essential in my field. This course not only boosted my confidence but also enhanced my job prospects.

                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->



                    
                    <!-- Start Single Testimonial  -->
                    <div class="swiper-slide swiper-slide-active" style="width: 445px;" role="group" aria-label="1 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Kapil Sharma </h5>
                                            <span class="subtitle">Student</span>
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                 
                                        The Material Management Course at Rashtriya Institute was a game-changer for my career. The hands-on training and real-world case studies gave me practical skills that I could apply immediately at my job. The instructors were incredibly knowledgeable and supportive, making the learning experience both engaging and valuable. I feel much more confident in my abilities to manage materials and inventory effectively!
                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->



                    
                    <!-- Start Single Testimonial  -->
                    <div class="swiper-slide swiper-slide-active" style="width: 445px;" role="group" aria-label="1 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Arjun Verma
                                            </h5>
                                            <span class="subtitle">Student</span>
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                 
                                 

The Mechanical Course at Rashtriya Institute was instrumental in shaping my career. The course covered essential topics, from thermodynamics to fluid mechanics, in a way that was both engaging and comprehensible. The hands-on projects allowed me to apply what I learned in real-world scenarios, which significantly boosted my confidence in my technical skills. I highly recommend this course to anyone looking to deepen their mechanical engineering knowledge!
                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->




                    
                    <!-- Start Single Testimonial  -->
                    <div class="swiper-slide swiper-slide-active" style="width: 445px;" role="group" aria-label="1 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Afjal </h5>
                                            <span class="subtitle">Student</span>
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                 
                                  

    
    Completing the Draftsman Course has greatly enhanced my work as an interior designer. The training provided me with the tools and techniques necessary to create precise and detailed designs. The instructors were supportive and offered constructive feedback, which helped me improve my skills significantly.
                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->














                    <!-- Start Single Testimonial  -->
                    <div class="swiper-slide swiper-slide-active" style="width: 445px;" role="group" aria-label="1 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Neha Singh </h5>
                                            <span class="subtitle">Student</span>
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                 
                                        Yaa ofcourse that's best Institute in jsr. And I Like ro study with M.A khan sir . He has best experience About Q.c &amp; i love a lot.
                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="swiper-slide swiper-slide-next" style="width: 445px;" role="group" aria-label="2 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Kamran Akmal </h5>
                                            <span> <i> Student</i></span>
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                                        best techinical institute i have come across so far....  over all perfection in training , highly qualified trainer and well built infrastructure... proud student of rti...
                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->
                    <!-- Start Single Testimonial  -->
                    <div class="swiper-slide" style="width: 445px;" role="group" aria-label="3 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Manish Kumar</h5>
                                            <span>Student</span>
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                                        best techinical institute for Auto Draftsman and over all perfection in training , highly qualified trainer and well built infrastructure... proud student of rti.
                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->
                    <!-- Start Single Testimonial  -->
                    <div class="swiper-slide" style="width: 445px;" role="group" aria-label="4 / 5">
                        <div class="single-slide">
                            <div class="rbt-testimonial-box">
                                <div class="inner bg-no-shadow">
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="assets/images/testimonial/user.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Nadeem Khan</h5>
                                            <span> Student</span>
                                        </div>
                                    </div>
                                    <div class="description">
                                        <p class="subtitle-3">
                                        I took the Material Management Training course at Rashtriya Technical Institute, and it was a Fabulous learning experience
                                        </p>
                                        <div class="rating mt--20">
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                            <a href="#"><i class="fa fa-star"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->
                  
                </div>

                <div class="rbt-swiper-arrow rbt-arrow-left" tabindex="0" role="button" aria-label="Next slide"
                    aria-controls="swiper-wrapper-10a33b3de5a5d6958" aria-disabled="false">
                    <div class="custom-overfolow">
                        <i class="rbt-icon feather-arrow-left"></i>
                        <i class="rbt-icon-top feather-arrow-left"></i>
                    </div>
                </div>

                <div class="rbt-swiper-arrow rbt-arrow-right swiper-button-disabled" tabindex="-1" role="button"
                    aria-label="Previous slide" aria-controls="swiper-wrapper-10a33b3de5a5d6958" aria-disabled="true">
                    <div class="custom-overfolow">
                        <i class="rbt-icon feather-arrow-right"></i>
                        <i class="rbt-icon-top feather-arrow-right"></i>
                    </div>
                </div>
                <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
            </div>
        </div>
        <br />
    </div>

    <!-- End testimonial  -->



    <!-- Start Accordion Area  -->
    <div class="rbt-accordion-area accordion-style-1 rbt-section-gap">
        <div class="container">
            <div class="row mb--60">
                <div class="col-lg-12">
                    <div class="section-title text-center">

                        <h2 class="title">
                            Frequently Asked Questions?

                        </h2>
                    </div>
                </div>
            </div>
            <div class="row g-5 align-items-center">



                <div class="col-lg-7">
                    <div class="rbt-accordion-style rbt-accordion-01  accordion">
                        <div class="accordion" id="accordionExamplea1">

                            <div class="accordion-item card">
                                <h2 class="accordion-header card-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        Is Rashtriya Register By Govt ?

                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show"
                                    aria-labelledby="headingOne" data-bs-parent="#accordionExamplea1" style="">
                                    <div class="accordion-body card-body">
                                        Yes Rashtriya Technical Institute is Registered By Govt. of Jharkhand.
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item card">
                                <h2 class="accordion-header card-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        Is There Any Facilities For Mess And Hostel

                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                    data-bs-parent="#accordionExamplea1">
                                    <div class="accordion-body card-body">
                                        Yes, We are providing Mess and Hostel facilities for all the students.
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item card">
                                <h2 class="accordion-header card-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseThree" aria-expanded="false"
                                        aria-controls="collapseThree">
                                        Can I Get Job After Completion of Course ?

                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse"
                                    aria-labelledby="headingThree" data-bs-parent="#accordionExamplea1">
                                    <div class="accordion-body card-body">
                                        Yes, More Than 90% students have placed already, Some Reputed Companies Come For
                                        Campus Selection
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item card">
                                <h2 class="accordion-header card-header" id="headingFour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseFour" aria-expanded="false"
                                        aria-controls="collapseFour">
                                        Can I Get Practical Classes For This Course ?

                                    </button>
                                </h2>
                                <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                    data-bs-parent="#accordionExamplea1" style="">
                                    <div class="accordion-body card-body">
                                        Yes, 2 Month Theory And 1 Month Practical Classes. Students Get 100% Practical
                                        Training for all trade.
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-lg-5">
                    <div class="rbt-contact-form contact-form-style-1 max-width-auto">

                        <h4 class="title">Enquire Now</h4>
                        <form id="contact-form" method="POST" action="mail.php"
                            class="rainbow-dynamic-form max-width-auto">
                            <div class="form-group">
                                <input name="name" id="contact-name" type="text">
                                <label>Name</label>
                                <span class="focus-border"></span>
                            </div>
                            <div class="form-group">
                                <input name="mob" type="text">
                                <label>Mobile No</label>
                                <span class="focus-border"></span>
                            </div>

                            <div class="form-group">
                                <input name="course" type="text">
                                <label>Course Name</label>
                                <span class="focus-border"></span>
                            </div>




                            <div class="form-group">
                                <textarea name="msg" id="contact-message"></textarea>
                                <label>Message</label>
                                <span class="focus-border"></span>
                            </div>




                            <div class="form-submit-group">
                                <button name="submit" type="submit" id="submit"
                                    class="rbt-btn btn-md btn-gradient hover-icon-reverse w-100">
                                    <span class="icon-reverse-wrapper">
                                        <span class="btn-text">Submit</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- End Accordion Area  -->


    <div class="rbt-brand-area bg-color-white rbt-section-gap">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-12">
                    <div class="section-title text-center">

                        <h2 class="title">Our Recruiters </h2>
                        <p class="description mt--20 mb--20">

                            Rashtriya Technical Institute provides a lot of facilities for all, also provide Mess and
                            Hostel facilities for all the students.
                        </p>
                    </div>
                </div>
            </div>


            <!-- Start recruit  -->

            <div class="col-lg-12 mt--30">
                <!-- Start Tab Nav  -->
                <ul class="testimonial-thumb-wrapper nav nav-tabs" id="myTab" role="tablist">
                    <li>
                        <a id="testimonial-tab1-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab1" role="tab"
                            aria-controls="testimonial-tab1" aria-selected="false" class="active">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="assets/images/partners/aditya.png" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>





                    <li>
                        <a id="testimonial-tab2-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab2" role="tab"
                            aria-controls="testimonial-tab2" aria-selected="false" class="active">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="assets/images/partners/tata.jpg" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a id="testimonial-tab3-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab3" role="tab"
                            aria-controls="testimonial-tab3" aria-selected="false" class="active">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="assets/images/partners/lt.png" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a id="testimonial-tab4-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab4" role="tab"
                            aria-controls="testimonial-tab4" aria-selected="true" class="active">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="assets/images/partners/voltas.png" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a id="testimonial-tab5-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab5" role="tab"
                            aria-controls="testimonial-tab5" aria-selected="false" class="active">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="assets/images/partners/qatar.png" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a id="testimonial-tab6-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab6" role="tab"
                            aria-controls="testimonial-tab6" aria-selected="false" class="active">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="assets/images/partners/tata2.jpg" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a id="testimonial-tab7-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab7" role="tab"
                            aria-controls="testimonial-tab7" aria-selected="false" class="active">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="assets/images/partners/usha.jpg" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a id="testimonial-tab8-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab8" role="tab"
                            aria-controls="testimonial-tab8" aria-selected="false" class="active">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="assets/images/partners/laf.png" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>


                    <li>
                        <a id="testimonial-tab8-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab8" role="tab"
                            aria-controls="testimonial-tab8" aria-selected="false" class="active">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="assets/images/partners/iic.jpg" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>


                    <li>
                        <a id="testimonial-tab8-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab8" role="tab"
                            aria-controls="testimonial-tab8" aria-selected="false" class="active">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="assets/images/partners/kk.jpg" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>


                    <li>
                        <a id="testimonial-tab8-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab8" role="tab"
                            aria-controls="testimonial-tab8" aria-selected="false" class="active">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="assets/images/partners/redis.png" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>


                    <li>
                        <a id="testimonial-tab8-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab8" role="tab"
                            aria-controls="testimonial-tab8" aria-selected="false" class="active">
                            <div class="testimonial-thumbnai">
                                <div class="thumb">
                                    <img src="assets/images/partners/simplex.png" alt="Testimonial Images">
                                </div>
                            </div>
                        </a>
                    </li>
                </ul>
                <!-- End Tab Content  -->
            </div>


            <!-- End recruit -->





        </div>
        <br>
    </div>


    <br>

    <!-- start image  -->

    <div class="rbt-gallery-area">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-12 mb--60">
                    <div class="section-title text-center">

                        <h2 class="title">Our Gallery</h2>
                        <p class="description mt--20">

                            Rashtriya Technical Institute provides a lot of facilities for all, also provide Mess and
                            Hostel facilities for all the students.
                        </p>
                    </div>
                </div>
            </div>

            <div class="row parent-gallery-container">






                <a href="assets/images/gallery/13.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="assets/images/gallery/13.jpg" alt="Gallery Images">
                    </div>
                </a>

                <a href="assets/images/gallery/8.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="assets/images/gallery/8.jpg" alt="Gallery Images">
                    </div>
                </a>




                <a href="assets/images/gallery/11.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="assets/images/gallery/11.jpg" alt="Gallery Images">
                    </div>
                </a>

                <a href="assets/images/gallery/15.jpg" class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="assets/images/gallery/15.jpg" alt="Gallery Images">
                    </div>
                </a>


            </div>

            <div class="about-btn mt--40 text-center">
                <a class="rbt-btn btn-gradient hover-icon-reverse" href="student-gallery.php">
                    <span class="icon-reverse-wrapper">
                        <span class="btn-text">View All</span>
                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                    </span>
                </a>
            </div>


            <br />


        </div>
    </div>
    <!-- end image  -->

    <br>

    <!-- start video  -->
    <div class="rbt-gallery-area bg-color-white">

        <div class="container">
            <div class="row g-5">
                <div class="col-lg-12 mb--60">
                    <div class="section-title text-center">

                        <h2 class="title">Our Videos</h2>
                        <p class="description mt--20">

                        Explore our videos to see how our specialized training programs can transform your career
                        </p>
                    </div>
                </div>
            </div>


            <div class="row parent-gallery-container">

        <a href="https://www.youtube.com/embed/EjubHZAYocI?si=5BMU_omA9DY3xDtQ"
                class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
                <div class="rbt-gallery">
                    <iframe src="https://www.youtube.com/embed/EjubHZAYocI?si=5BMU_omA9DY3xDtQ" title="YouTube video player"
                        style="width:100%!important; height:270px!important"></iframe>
                </div>
            </a>

            <a href="https://www.youtube.com/embed/lnf5VUVWuhc?si=CF1pDWgHnMjXvUfx"
                class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
                <div class="rbt-gallery">
                    <iframe src="https://www.youtube.com/embed/lnf5VUVWuhc?si=CF1pDWgHnMjXvUfx" title="YouTube video player"
                        style="width:100%!important; height:270px!important"></iframe>
                </div>
            </a>
           

            <a href="https://www.youtube.com/embed/UgrxVMhnwh8?si=tTEF51z8vVLZ1Jn9"
                class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
                <div class="rbt-gallery">
                    <iframe src="https://www.youtube.com/embed/UgrxVMhnwh8?si=tTEF51z8vVLZ1Jn9" title="YouTube video player"
                        style="width:100%!important; height:270px!important"></iframe>
                </div>
            </a>
            <a href="https://www.youtube.com/embed/U5XH60ZWBmU?si=QEmsM7toeJJcdSWP"
                class="child-gallery-single col-lg-3 col-md-3 col-sm-6 col-12">
                <div class="rbt-gallery">
                    <iframe src="https://www.youtube.com/embed/U5XH60ZWBmU?si=QEmsM7toeJJcdSWP" title="YouTube video player"
                        style="width:100%!important; height:270px!important"></iframe>
                </div>
            </a>
        

        </div>
     



            <div class="about-btn mt--40 text-center">
                <a class="rbt-btn btn-gradient hover-icon-reverse" href="video-gallery.php">
                    <span class="icon-reverse-wrapper">
                        <span class="btn-text">View All</span>
                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                    </span>
                </a>
            </div>



            <br />


        </div>
    </div>
    <!-- end video  -->








    <?php include 'footer.php' ?>


    <!-- JS
    ============================================ -->
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr.min.js"></script>
    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.min.js"></script>
    <!-- sal.js -->
    <script src="assets/js/vendor/sal.js"></script>
    <!-- Dark Mode Switcher -->
    <script src="assets/js/vendor/js.cookie.js"></script>
    <script src="assets/js/vendor/jquery.style.switcher.js"></script>
    <script src="assets/js/vendor/swiper.js"></script>
    <script src="assets/js/vendor/jquery-appear.js"></script>
    <script src="assets/js/vendor/odometer.js"></script>
    <script src="assets/js/vendor/backtotop.js"></script>
    <script src="assets/js/vendor/isotop.js"></script>
    <script src="assets/js/vendor/imageloaded.js"></script>

    <script src="assets/js/vendor/wow.js"></script>
    <script src="assets/js/vendor/waypoint.min.js"></script>
    <script src="assets/js/vendor/easypie.js"></script>
    <script src="assets/js/vendor/text-type.js"></script>
    <script src="assets/js/vendor/jquery-one-page-nav.js"></script>
    <script src="assets/js/vendor/bootstrap-select.min.js"></script>
    <script src="assets/js/vendor/jquery-ui.js"></script>
    <script src="assets/js/vendor/magnify-popup.min.js"></script>
    <script src="assets/js/vendor/paralax-scroll.js"></script>
    <script src="assets/js/vendor/paralax.min.js"></script>
    <script src="assets/js/vendor/countdown.js"></script>
    <script src="assets/js/vendor/plyr.js"></script>
    <script src="assets/js/vendor/jodit.min.js"></script>
    <script src="assets/js/vendor/Sortable.min.js"></script>



    <!-- Main JS -->
    <script src="assets/js/main.js"></script>


</body>


</html>