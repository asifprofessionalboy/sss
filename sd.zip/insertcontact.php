

<?php
      $conn = mysqli_connect("localhost","root","", "rti");
          
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. " 
                . mysqli_connect_error());
        }
          
       
if (isset($_POST['submit'])) {
    if ($_POST['name'] == "" || $_POST['mob'] == ""  || $_POST['course'] == ""  || $_POST['msg'] == "") {
        echo '<script>alert("Error: All fields are required."); window.location.href="index.php"</script>';
    } else {
        // Sanitize inputs to prevent SQL injection
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $mob = mysqli_real_escape_string($conn, $_POST['mob']);
        $course = mysqli_real_escape_string($conn, $_POST['course']);
        $msg = mysqli_real_escape_string($conn, $_POST['msg']);

        // Check if the mobile number is already registered
        $query = "SELECT * FROM enquiry WHERE mob='$mob'";
        $result = mysqli_query($conn, $query);
        if (mysqli_num_rows($result) > 0) {
            echo '<script>alert("Error: Mobile number already registered."); window.location.href="index.php"</script>';
        } else {
            // Insert the data into the database
            $sql = "INSERT INTO enquiry(name, mob, course, msg) VALUES ('$name','$mob',  '$course','$msg')";
            if (mysqli_query($conn, $sql)) {
                echo '<script>window.location.href="thankyou.php"</script>';
            } else {
                echo '<script>alert("Unable to submit form."); window.location.href="index.php"</script>';
            }
        }
    }
}
        // Close connection
        mysqli_close($conn);
       

    

        ?>

